<?php include("dataconnection.php"); 
	session_start();
   if(!isset($_SESSION['id']) || !isset($_SESSION['name']) || !isset($_SESSION['email']) || !isset($_SESSION['vemail'])){
      echo "<script>alert('Sorry, you must login first before adding product(s) into the shopping cart.'); window.location.href='clogin.php';</script>";
   }else if(isset($_SESSION['id']) &&  isset($_SESSION['name']) && isset($_SESSION['email']) && isset($_SESSION['vemail'])){
         $vemail = $_SESSION['vemail'];
         if($vemail == false){
            echo "<script>window.location.href='sentOTP.php';</script>";
            exit();
         }
         // else{
         // 	header("Location:./index.php");
         // 	exit();
         // }
   }
    if(isset($_POST["add-to-cart"]))
    {  $count=0;
       $customer_id=$_SESSION["id"];
       $detectcart_sql="SELECT * FROM cart WHERE customer_id=$customer_id";
       $run_detectcart_sql=mysqli_query($connect, $detectcart_sql);
       $cart_num_rows=mysqli_num_rows($run_detectcart_sql);
       $product_id=$_POST["product_id"];
       if($cart_num_rows==1)
       { $cart_rows=mysqli_fetch_assoc($run_detectcart_sql);
         $cart_id=$cart_rows["cart_id"];
         $detect_cartitem_sql="SELECT * FROM cart_item WHERE cart_id=$cart_id";
         $run_detect_cartitem_sql=mysqli_query($connect, $detect_cartitem_sql);
         while($cartitem_rows=mysqli_fetch_assoc($run_detect_cartitem_sql))
         {
            if($product_id==$cartitem_rows["product_id"])
            {
               $stock_sql="SELECT * FROM stock WHERE product_id='$product_id'";
               $run_stock_sql=mysqli_query($connect, $stock_sql);
               $stock_rows=mysqli_fetch_assoc($run_stock_sql);
               $stock_level=$stock_rows['stock_level'];
               $citem_qty=$cartitem_rows["item_quantity"];
               if(!isset($_POST["cart_qty"]))
               {
                  if($citem_qty+1>$stock_level)
                 {
                   echo "<script>alert('Sorry, the product quantity you added had met its available stock in your shopping cart.')</script>";
                 }
                 else
                 { $citem_qty++;
                   $update_citem_sql="UPDATE cart_item SET item_quantity=$citem_qty WHERE cart_id=$cart_id AND product_id='$product_id'";
                   $run_update_citem_sql=mysqli_query($connect, $update_citem_sql);
                   if($run_update_citem_sql)
                   {
                     echo "<script>alert('Product added to cart!')</script>"; 
                   }
                 }
               }
               else if(isset($_POST["cart_qty"]))
               {
                  $add_qty=$_POST["cart_qty"];
                  if($citem_qty+$add_qty>$stock_level)
                 {
                   echo "<script>alert('Sorry, the product quantity you added had met its available stock in your shopping cart.')</script>";
                 }
                 else
                 { $citem_qty+=$add_qty;
                   $update_citem_sql="UPDATE cart_item SET item_quantity=$citem_qty WHERE cart_id=$cart_id AND product_id='$product_id'";
                   $run_update_citem_sql=mysqli_query($connect, $update_citem_sql);
                   if($run_update_citem_sql)
                   {
                     echo "<script>alert('Product added to cart!')</script>"; 
                   }
                 }
               }
               $count++;
            }
         }
         if($count==0)
         {  if(!isset($_POST["cart_qty"]))
            {
               $add_citem_sql="INSERT INTO cart_item (product_id, cart_id, item_quantity) VALUES ('$product_id', $cart_id, 1)";
               $run_add_citem_sql=mysqli_query($connect, $add_citem_sql);
               if($run_add_citem_sql)
               {
                   echo "<script>alert('Product added to cart!')</script>"; 
               }
            }
            else if(isset($_POST["cart_qty"]))
            {
               $add_qty=$_POST["cart_qty"];
               $add_citem_sql="INSERT INTO cart_item (product_id, cart_id, item_quantity) VALUES ('$product_id', $cart_id, $add_qty)";
               $run_add_citem_sql=mysqli_query($connect, $add_citem_sql);
               if($run_add_citem_sql)
               {
                   echo "<script>alert('Product added to cart!')</script>"; 
               }
            }
         }
       }
       else
       {
        $add_cart_sql="INSERT INTO cart (customer_id) VALUES ($customer_id)";
        $run_add_cart_sql=mysqli_query($connect, $add_cart_sql);
        if($run_add_cart_sql)
        {   $detectcart_sql2="SELECT * FROM cart WHERE customer_id=$customer_id";
            $run_detectcart_sql2=mysqli_query($connect, $detectcart_sql2);
            $cart_rows2=mysqli_fetch_assoc($run_detectcart_sql2);
            $new_cart_id=$cart_rows2["cart_id"];
            if(!isset($_POST["cart_qty"]))
            {
               $add_citem_sql="INSERT INTO cart_item (product_id, cart_id, item_quantity) VALUES ('$product_id', $new_cart_id, 1)";
               $run_add_citem_sql=mysqli_query($connect, $add_citem_sql);
               if($run_add_citem_sql)
               {
                   echo "<script>alert('Product added to cart!')</script>"; 
               }
            }
            else if(isset($_POST["cart_qty"]))
            {  $add_qty=$_POST["cart_qty"];
               $add_citem_sql="INSERT INTO cart_item (product_id, cart_id, item_quantity) VALUES ('$product_id', $new_cart_id, $add_qty)";
               $run_add_citem_sql=mysqli_query($connect, $add_citem_sql);
               if($run_add_citem_sql)
               {
                   echo "<script>alert('Product added to cart!')</script>"; 
               }
            }
        }
       }
       echo "<script>history.back();</script>";
    }
?>
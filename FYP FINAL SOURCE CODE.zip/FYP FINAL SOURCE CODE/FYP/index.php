<!DOCTYPE html>
    <?php include("dataconnection.php");
	session_start();
/*if(isset($_SESSION["pf"]))
    {
      unset($_SESSION["pf"]);
    }*/
	if(isset($_SESSION["del"]))
	 {
		unset($_SESSION["del"]);
	 }
	if(isset($_SESSION["rname"]))
    {
      unset($_SESSION["rname"]);
    }
    if(isset($_SESSION["remail"]))
    {
      unset($_SESSION["remail"]);
    }
    if(isset($_SESSION["rhp"]))
    {
      unset($_SESSION["rhp"]);
    }
	if(isset($_SESSION["padd1"]))
    {
      unset($_SESSION["padd1"]);
    }
    if(isset($_SESSION["padd2"]))
    {
      unset($_SESSION["padd2"]);
    }
    if(isset($_SESSION["pst"]))
    {
      unset($_SESSION["pst"]);
    }
    if(isset($_SESSION["ppc"]))
    {
      unset($_SESSION["ppc"]);
    }
    if(isset($_SESSION["pct"]))
    {
      unset($_SESSION["pct"]);
    }
    if(isset($_SESSION["ptype"]))
    {
      unset($_SESSION["ptype"]);
    }
    /*if(isset($_SESSION["payment_method"]))
    {
      unset($_SESSION["payment_method"]);
    }*/
    if(isset($_SESSION["cardtype"]))
    {
      unset($_SESSION["cardtype"]);
    }
    if(isset($_SESSION["holder_name"]))
    {
      unset($_SESSION["holder_name"]);
    }
    if(isset($_SESSION["cardnum"]))
    {
      unset($_SESSION["cardnum"]);
    }
    if(isset($_SESSION["cardvv"]))
    {
      unset($_SESSION["cardvv"]);
    }
    if(isset($_SESSION["carddate"]))
    {
      unset($_SESSION["carddate"]);
    }
    /*if(isset($_SESSION["ewallet_types"]))
    {
      unset($_SESSION["ewallet_types"]);
    }
    if(isset($_SESSION["transaction_no"]))
    {
      unset($_SESSION["transaction_no"]);
    }*/
    if(isset($_SESSION["address1"]))
    {
      unset($_SESSION["address1"]);
    }
    if(isset($_SESSION["address2"]))
    {
      unset($_SESSION["address2"]);
    }
    if(isset($_SESSION["city"]))
    {
      unset($_SESSION["city"]);
    }
    if(isset($_SESSION["state"]))
    {
      unset($_SESSION["state"]);
    }
    if(isset($_SESSION["postcode"]))
    {
      unset($_SESSION["postcode"]);
    }
    ?>
	<html lang="en">
	<head>
		<title>Book Store</title>
		<meta charset="utf-8">
	    <meta http-equiv="X-UA-Compatible" content="IE=edge">
	    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	    <meta name="format-detection" content="telephone=no">
	    <meta name="apple-mobile-web-app-capable" content="yes">
	    <meta name="author" content="">
	    <meta name="keywords" content="">
	    <meta name="description" content="">

	    <link rel="stylesheet" type="text/css" href="css/normalize.css">
	    <link rel="stylesheet" type="text/css" href="icomoon/icomoon.css">
	    <link rel="stylesheet" type="text/css" href="css/vendor.css">
	    <link rel="stylesheet" type="text/css" href="style.css">
		<style>
			#billboard .main-slider{
				overflow: hidden;
			}
			.main-slider .slider-item{
				opacity: 0;
                transition: opacity 1s ease-in-out;
			}
			.main-slider .slider-item.active {
               opacity: 1;
            }
            @keyframes slideAnimation {
				0% {
                  opacity: 0;
                }
                33.33% {
                 opacity: 1;
                }
                66.66% {
                 opacity: 1;
                }
                100% {
                 opacity: 0;
                }
            }
		</style>
		<!-- script
		================================================== -->
		<script src="http://translate.google.com/translate_a/element.js?cb=loadGoogleTranslate"></script>
		<script src="js/modernizr.js">
			function handle_keyup(event){
				if (event.keyCode === 13) {
                   document.getElementById('search_btn').click();
                }
			}
		</script>
		<script style="text/javascript">
		  let intervalID;
          function myFunction() {
             const nextbtn = document.getElementById("nextbtn");
             nextbtn.click();
          }
          function startInterval() {
             intervalID = setInterval(myFunction, 5000);
          }
          function pauseInterval() {
             clearInterval(intervalID);
          }
          function resumeInterval() {
             startInterval();
          }
          startInterval();
		  function loadGoogleTranslate() {
    const defaultLanguage = "en";

    const translateElement = new google.translate.TranslateElement({
      pageLanguage: defaultLanguage,
      includedLanguages: "en,ms,zh-CN",
      layout: google.translate.TranslateElement.InlineLayout.SIMPLE
    }, "google_element");

    // Get the language select dropdown element
    const languageSelect = document.getElementById("languageSelect");

    // Function to set a cookie
    function setCookie(name, value, days) {
      const expires = new Date();
      expires.setTime(expires.getTime() + days * 24 * 60 * 60 * 1000);
      document.cookie = `${name}=${value};expires=${expires.toUTCString()};path=/`;
    }

    // Function to get a cookie value
    function getCookie(name) {
      const cookieName = `${name}=`;
      const cookies = document.cookie.split(';');
      for (let i = 0; i < cookies.length; i++) {
        let cookie = cookies[i];
        while (cookie.charAt(0) === ' ') {
          cookie = cookie.substring(1);
        }
        if (cookie.indexOf(cookieName) === 0) {
          return cookie.substring(cookieName.length, cookie.length);
        }
      }
      return null;
    }

    // Set the initial language selection
    const storedLanguage = getCookie("selectedLanguage");
    if (storedLanguage) {
      languageSelect.value = storedLanguage;
      translateElement.update({
        includedLanguages: storedLanguage
      });
    }

    // Add event listener for change event
    languageSelect.addEventListener("change", function() {
      const selectedLanguage = this.value;
      translateElement.update({
        includedLanguages: selectedLanguage
      });
      setCookie("selectedLanguage", selectedLanguage, 30); // Set the cookie for 30 days
    });
  }
		</script>

	</head>

<body>

<div id="header-wrap">

	<div class="top-content">
		<div class="container">
			<div class="row">
			<div class="col-md-6" style="width: 25%;">

				</div>
				<div class="col-md-6" style="width: 75%;">
					<div class="right-element">

						<?php
						if(isset($_SESSION['id']) &&  isset($_SESSION['name']) && isset($_SESSION['email']) && isset($_SESSION['vemail'])){
							$vemail = $_SESSION['vemail'];
							if($vemail == false){
								echo "<script>window.location.href='sentOTP.php';</script>";
								exit();
							}
							// else{
							// 	header("Location:./index.php");
							// 	exit();
							// }
						}
						if(isset($_SESSION['id']))
						{   $cust_id=$_SESSION['id'];
							$cartsql="SELECT * FROM cart WHERE customer_id=$cust_id";
							$run_cartsql=mysqli_query($connect, $cartsql);
							$num_rows_cartsql=mysqli_num_rows($run_cartsql);
							$rows_cartsql=mysqli_fetch_assoc($run_cartsql);
							if($num_rows_cartsql==0)
							{
								$cartitem_rows=0;
							}
							else
							{   $cartid=$rows_cartsql["cart_id"];
								$cartitemsql="SELECT * FROM cart_item WHERE cart_id=$cartid";
							    $run_cartitemsql=mysqli_query($connect, $cartitemsql);
							    $cartitem_rows=mysqli_num_rows($run_cartitemsql);
								$del_val=0;
								while($rows_cartitemsql=mysqli_fetch_assoc($run_cartitemsql))
								{
                                  $prodid=$rows_cartitemsql["product_id"];
								  $itemqty=$rows_cartitemsql["item_quantity"];
								  $stocksql="SELECT * FROM stock WHERE product_id='$prodid'";
                                  $run_stocksql=mysqli_query($connect, $stocksql);
                                  $stockrows=mysqli_fetch_assoc($run_stocksql);
                                  $stocklevel=$stockrows['stock_level'];
								  $prodsql="SELECT * FROM product WHERE product_id='$prodid' AND availability=0";
                                  $run_prodsql=mysqli_query($connect, $prodsql);
                                  $prodrows=mysqli_num_rows($run_prodsql);
								  if($prodrows==0)
								  {
									$del_cartitem="DELETE FROM cart_item WHERE cart_id=$cartid AND product_id='$prodid'";
									$run_del_cartitem=mysqli_query($connect, $del_cartitem);
									if($run_del_cartitem)
                                      $del_val++;
								  }
								  else if($stocklevel==0)
								  {
									$del_cartitem="DELETE FROM cart_item WHERE cart_id=$cartid AND product_id='$prodid'";
									$run_del_cartitem=mysqli_query($connect, $del_cartitem);
									if($run_del_cartitem)
                                      $del_val++;
								  }
								  else if($itemqty>$stocklevel)
								  {
									$update_cartitem="UPDATE cart_item SET item_quantity=$stocklevel WHERE cart_id=$cartid AND product_id='$prodid'";
									$run_update_cartitem=mysqli_query($connect, $update_cartitem);
								  }
								}
								if($del_val==$cartitem_rows)
								{
									$del_cart="DELETE FROM cart WHERE cart_id=$cartid";
									$run_del_cart=mysqli_query($connect, $del_cart);
								}
								$cartitem_rows-=$del_val;
							}
							$select_cust="SELECT * FROM customer WHERE customer_id=$cust_id";
							$run_select_cust=mysqli_query($connect, $select_cust);
							$row_select_cust=mysqli_fetch_assoc($run_select_cust);
							$user_profile=$row_select_cust["customer_profile_picture"];
							?>
							<a href="cart.php" class="cart for-buy"><img src="images/icon/carts.png" style="width: 50px; height: 50px; opacity: 70%; margin-bottom: 5px;"><span>Cart: <?php echo $cartitem_rows; ?> item(s)</span></a>
							<a href="order_history.php" class="cart for-buy"><i class="icon icon-clipboard"></i> <span>Order History</span></a>
						<nav id="navbar" style="display: inline-block; margin-left: -40px; position: relative; z-index: 3;">
						<div class="main-menu stellarnav">
						<ul class="menu-list">
						<li class="menu-item has-sub">
							<a href="./user_profile.php" class="nav-link" data-effect="Pages"><img src="images/cus_profile/<?php echo $user_profile; ?>" style="width: 40px; height: 40px; border-radius: 50%; margin-right: 10px;" alt="user_profile" title="user_profile">Account</a>
							<ul style="font-size: 16px;">
								<li><a href="./user_profile.php">My Profile</a></li>
								<li><a href="./logoutaction.php">Logout</a></li>
							 </ul>
						</li>
						</ul>
						</div>
						</nav>
                        <?php
						}
						else
						{?><i class="icon icon-user"></i> <span>
						   <a href="./clogin.php">Login</a> | <a href="./cregister.php">Register</a>
						</span>
                        <?php
						}?>

						<div class="action-menu" style="margin-left: 10px;">

							<div class="search-bar">
								<a href="#" class="search-button search-toggle" data-selector="#header-wrap">
									<i class="icon icon-search"></i>
								</a>
								<form role="search" method="get" class="search-box" action="search_products.php">
									<input class="search-field text search-input" placeholder="Search products" type="text" name="search_keyword" onkeyup="handle_keyup(event)">
									<input type="submit" id="search_btn" style="display: none;">
								</form>
							</div>
						</div>
                        <div id="google_element" style="display: inline-block;"></div>
					</div><!--top-right-->
				</div>

			</div>
		</div>
	</div><!--top-content-->

	<header id="header" style="background-color: #f3e7be;">
		<div class="container">
			<div class="row">

				<div class="col-md-2">
					<!--<div class="main-logo">-->
						<a href="index.php"><img src="images/icon/logo.png" alt="logo" style="height: 140px; margin:-60px 0px -30px 0px;"></a>
					<!--</div>-->
				</div>

				<div class="col-md-10">

					<nav id="navbar" style="position: relative; z-index: 1;">
						<div class="main-menu stellarnav">
							<ul class="menu-list">
								<li class="menu-item active"><a href="index.php" data-effect="Home" style="font-size: 17px;">Home</a></li>
								<li class="menu-item"><a href="about_us.php" class="nav-link" data-effect="About" style="font-size: 17px;">About</a></li>
								<!--<li class="menu-item has-sub">
									<a href="#pages" class="nav-link" data-effect="Pages">Pages</a>

									<ul>
								        <li><a href="styles.html">Styles</a></li>
								        <li><a href="blog.html">Blog</a></li>
								        <li><a href="single-post.html">Post Single</a></li>
								        <li><a href="shop.php">Products</a></li>
								        <li><a href="thank-you.html">Thank You</a></li>
								     </ul>

								</li>-->
								<li class="menu-item"><a href="shop.php" class="nav-link" data-effect="Shop" style="font-size: 17px;">Shop</a></li>
								<li class="menu-item"><a href="contact.php" class="nav-link" data-effect="Contact" style="font-size: 17px;">Contact Us</a></li>
							</ul>

							<div class="hamburger">
				                <span class="bar"></span>
				                <span class="bar"></span>
				                <span class="bar"></span>
				            </div>

						</div>
					</nav>

				</div>

			</div>
		</div>
	</header>

</div><!--header-wrap-->
<?php
	$newprod="SELECT * FROM product LEFT JOIN stock ON product.product_id=stock.product_id WHERE product.availability=0 AND NOT stock.stock_level=0 ORDER BY product.publisher_date DESC;";
	$run_newprod=mysqli_query($connect, $newprod);
	$num_newprod=mysqli_num_rows($run_newprod);
	if($num_newprod!=0)
	{?>
	<section id="billboard">

<div class="container">
	<div class="row">

		<div class="col-md-12">

			<button class="prev slick-arrow" onclick="setTimeout(pauseInterval, 0); setTimeout(resumeInterval, 10000);">
				<i class="icon icon-arrow-left"></i>
			</button>

			<div class="main-slider pattern-overlay">
				<?php $i=0;
				while($row_newprod=mysqli_fetch_assoc($run_newprod))
				{ $publisher_date[$i]=$row_newprod["publisher_date"];
				  if($i>1 && $publisher_date[$i]!=$publisher_date[$i-1])
				  {
					break;
				  }
				  else
				  {?><div class="slider-item">
					<div class="banner-content">
						<h2 class="banner-title"><?php echo $row_newprod["product_name"]; ?></h2>
						<p><?php echo $row_newprod["product_description"]; ?></p>
						<div class="btn-wrap">
							<a href="single-product.php?hview&id=<?php echo $row_newprod['product_id']; ?>" class="btn btn-outline-accent btn-accent-arrow">Read More<i class="icon icon-ns-arrow-right"></i></a>
						</div>
					</div><!--banner-content-->
					<img src="staff/product_image/<?php echo $row_newprod["product_image"]; ?>" alt="banner" class="banner-image" style="width: 400px; height: 600px;">
				</div><!--slider-it
                  <?php
				  }
				?>
				  em-->
                 <?php $i++;
				}?>

			</div><!--slider-->

			<button id="nextbtn" class="next slick-arrow">
				<i class="icon icon-arrow-right"></i>
			</button>

		</div>
	</div>
</div>

</section>
	<?php
	}
?>
<!--
<section id="client-holder" data-aos="fade-up">
	<div class="container">
		<div class="row">
			<div class="inner-content">
				<div class="logo-wrap">
					<div class="grid">
						<a href="#"><img src="images/client-image1.png" alt="client"></a>
						<a href="#"><img src="images/client-image2.png" alt="client"></a>
						<a href="#"><img src="images/client-image3.png" alt="client"></a>
						<a href="#"><img src="images/client-image4.png" alt="client"></a>
						<a href="#"><img src="images/client-image5.png" alt="client"></a>
					</div>
				</div><!--image-holder--><!--
			</div>
		</div>
	</div>
</section>-->
<!--
<section id="featured-books">
	<div class="container">
		<div class="row">
			<div class="col-md-12">

			<div class="section-header align-center">
				<div class="title">
					<span>Some quality items</span>
				</div>
				<h2 class="section-title">Featured Books</h2>
			</div>

			<div class="product-list" data-aos="fade-up">
				<div class="row">

					<div class="col-md-3">
						<figure class="product-style">
							<img src="images/product-item1.jpg" alt="Books" class="product-item">
								<button type="button" class="add-to-cart" data-product-tile="add-to-cart">Add to Cart</button>
							<figcaption>
								<h3>Simple way of piece life</h3>
								<p>Armor Ramsey</p>
								<div class="item-price">$ 40.00</div>
							</figcaption>
						</figure>
					</div>

					<div class="col-md-3">
						<figure class="product-style">
							<img src="images/product-item2.jpg" alt="Books" class="product-item">
								<button type="button" class="add-to-cart" data-product-tile="add-to-cart">Add to Cart</button>
							<figcaption>
								<h3>Great travel at desert</h3>
								<p>Sanchit Howdy</p>
								<div class="item-price">$ 38.00</div>
							</figcaption>
						</figure>
					</div>

					<div class="col-md-3">
						<figure class="product-style">
							<img src="images/product-item3.jpg" alt="Books" class="product-item">
								<button type="button" class="add-to-cart" data-product-tile="add-to-cart">Add to Cart</button>
							<figcaption>
								<h3>The lady beauty Scarlett</h3>
								<p>Arthur Doyle</p>
								<div class="item-price">$ 45.00</div>
							</figcaption>
						</figure>
					</div>

					<div class="col-md-3">
						<figure class="product-style">
							<img src="images/product-item4.jpg" alt="Books" class="product-item">
								<button type="button" class="add-to-cart" data-product-tile="add-to-cart">Add to Cart</button>
							<figcaption>
								<h3>Once upon a time</h3>
								<p>Klien Marry</p>
								<div class="item-price">$ 35.00</div>
							</figcaption>
						</figure>
					</div>

			    </div><!--ft-books-slider--><!--
			</div><!--grid-->

<!--
			</div><!--inner-content--><!--
		</div>

		<div class="row">
			<div class="col-md-12">

				<div class="btn-wrap align-right">
					<a href="#" class="btn-accent-arrow">View all products <i class="icon icon-ns-arrow-right"></i></a>
				</div>

			</div>
		</div>
	</div>
</section>
-->
<?php
  $bestselling="SELECT product.*, non_cancelled_orders.record_count, rating.avg_rating, stock.stock_level FROM product LEFT JOIN ( SELECT order_details.product_id, COUNT(orders.order_id) AS record_count FROM order_details JOIN orders ON orders.order_id = order_details.order_id WHERE orders.order_status != 'cancelled' GROUP BY order_details.product_id ) AS non_cancelled_orders ON non_cancelled_orders.product_id = product.product_id LEFT JOIN ( SELECT product_id, AVG(rating_rate) AS avg_rating FROM rating GROUP BY product_id ) AS rating ON product.product_id = rating.product_id LEFT JOIN stock ON product.product_id=stock.product_id WHERE product.availability = 0 AND NOT stock.stock_level=0 GROUP BY product.product_id ORDER BY non_cancelled_orders.record_count DESC, rating.avg_rating DESC LIMIT 1";
  $run_bestselling=mysqli_query($connect, $bestselling);
  $num_bestselling=mysqli_num_rows($run_bestselling);
  if($num_bestselling!=0)
  {?>
  <section id="best-selling" class="leaf-pattern-overlay">
	<div class="corner-pattern-overlay"></div>
	<div class="container">
		<div class="row">

			<div class="col-md-8 col-md-offset-2">

				<div class="row">
                    <?php
					while($row_bestselling=mysqli_fetch_assoc($run_bestselling))
					{ $author_id=$row_bestselling["author_id"];
					  $bestauthor="SELECT * FROM author WHERE author_id=$author_id";
					  $run_bestauthor=mysqli_query($connect, $bestauthor);
					  $row_bestauthor=mysqli_fetch_assoc($run_bestauthor);
					  $author_name=$row_bestauthor["author_name"];
					  $prodprice=$row_bestselling["product_price"];
					  $proddprice=$row_bestselling["discount_price"];
					  $discount=$row_bestselling["discount"];
					?>
					<div class="col-md-6">
						<figure class="products-thumb">
							<img src="staff/product_image/<?php echo $row_bestselling["product_image"]; ?>" alt="book" class="single-image" style="width: 100%; height: 100%;">
						</figure>
					</div>

					<div class="col-md-6">
						<div class="product-entry" style="margin-top:0px;">
							<h2 class="section-title divider">Best Selling Book</h2>

							 <div class="products-content">
								<h3 class="item-title"><?php echo $row_bestselling["product_name"]; ?></h3>
								<div class="author-name">By <?php echo $author_name; ?></div><br>
								<p><?php echo $row_bestselling["product_description"]; ?></p>
								<?php
								if($discount!=0)
								{
                                  ?>
								  <div class="item-price" style="font-size: 18px;"><del>RM <?php echo number_format($prodprice, 2); ?></del></div>
						          <div class="item-price" style="font-weight: bold;">RM <?php echo number_format($proddprice, 2); ?></div>
						          <div class="item-price" style="color: blue; font-weight: bold; border: 2px solid blue; width: 180px; text-align: center;">Discount <?php echo number_format($discount, 0); ?>%</div><br>
								<?php
						        }
								else
								{?><div class="item-price">RM <?php echo number_format($prodprice, 2); ?></div>
								<?php
								}?>
								<div class="btn-wrap">
									<a href="single-product.php?hview&id=<?php echo $row_bestselling['product_id']; ?>" class="btn-accent-arrow">shop it now <i class="icon icon-ns-arrow-right"></i></a>
								</div>
							</div>
							 <?php
							 }?>

						</div>
					</div>

				</div>
				<!-- / row -->

			</div>

		</div>
	</div>
</section>
  <?php
  }?>

<?php
	$bestcategory="SELECT product.*, AVG(rating.rating_rate) AS avg, COUNT(DISTINCT category.category_id) AS total_category, category.category_name, stock.stock_level FROM product LEFT JOIN rating ON product.product_id = rating.product_id LEFT JOIN category ON product.category_id = category.category_id LEFT JOIN stock ON product.product_id=stock.product_id WHERE product.availability = 0 AND NOT stock.stock_level=0 GROUP BY category.category_id HAVING avg IS NOT NULL ORDER BY `avg` DESC";
	$run_bestcategory=mysqli_query($connect, $bestcategory);
	$num_bestcategory=mysqli_num_rows($run_bestcategory);
	if($num_bestcategory!=0)
	{?>
	<section id="popular-books" class="bookshelf">
	<div class="container">
	<div class="row">
		<div class="col-md-12">

			<div class="section-header align-center">
				<div class="title">
					<span>Some quality items</span>
				</div>
				<h2 class="section-title">Popular Books</h2>
			</div>

			<ul class="tabs">
			  <li class="tab"><a href="index.php?br&cid=0" style="text-decoration: none; color: black; height: auto; border-bottom: 2px solid #9A884C; padding-bottom: 7px; <?php if(isset($_GET["br"]) && $_GET["cid"]!=0) { echo "border-bottom: 0px solid #9A884C;";}?>">All Genre</a></li>
			  <?php
			  while($row_category=mysqli_fetch_assoc($run_bestcategory))
			  { $category_id=$row_category["category_id"]; $category_name=$row_category["category_name"];
				?><li class="tab">
					<a href="index.php?br&cid=<?php echo $category_id; ?>" style="text-decoration: none; color: black; height: 0; <?php if(isset($_GET["br"]) && $_GET["cid"]==$category_id) { echo "border-bottom: 2px solid #9A884C; padding-bottom: 7px;";}?>"><?php echo $category_name; ?></a></li>
				<?php
			  }
			  ?>
			</ul>

			<div class="tab-content">
			  <div id="all-genre" data-tab-content class="active">
			  	<div class="row">
                    <?php
					if(isset($_GET["br"]))
					{
						$catid=$_GET["cid"];
						if($catid==0)
						{
							$bestprod="SELECT product.*, AVG(rating.rating_rate) AS avg, stock.stock_level FROM product LEFT JOIN rating ON product.product_id = rating.product_id LEFT JOIN stock ON product.product_id=stock.product_id WHERE product.availability = 0 AND NOT stock.stock_level=0 GROUP BY product.product_id HAVING avg IS NOT NULL ORDER BY `avg` DESC LIMIT 8";
	                        $run_bestprod=mysqli_query($connect, $bestprod);
	                        $num_bestprod=mysqli_num_rows($run_bestprod);
						}
						else
						{
							$bestprod="SELECT product.*, AVG(rating.rating_rate) AS avg, stock.stock_level FROM product LEFT JOIN rating ON product.product_id = rating.product_id LEFT JOIN stock ON product.product_id=stock.product_id WHERE product.availability = 0 AND product.category_id = $catid AND NOT stock.stock_level=0 GROUP BY product.product_id HAVING avg IS NOT NULL ORDER BY `avg` DESC";
	                        $run_bestprod=mysqli_query($connect, $bestprod);
	                        $num_bestprod=mysqli_num_rows($run_bestprod);
						}
					}
					else
					{
						$bestprod="SELECT product.*, AVG(rating.rating_rate) AS avg, stock.stock_level FROM product LEFT JOIN rating ON product.product_id = rating.product_id LEFT JOIN stock ON product.product_id=stock.product_id WHERE product.availability = 0 AND NOT stock.stock_level=0 GROUP BY product.product_id HAVING avg IS NOT NULL ORDER BY `avg` DESC LIMIT 8";
	                    $run_bestprod=mysqli_query($connect, $bestprod);
	                    $num_bestprod=mysqli_num_rows($run_bestprod);
					}
					while($row_bestprod=mysqli_fetch_assoc($run_bestprod))
					{   $product_id=$row_bestprod["product_id"];
						$prodname=$row_bestprod["product_name"];
						$authorid=$row_bestprod["author_id"];
						$authorsql="SELECT * FROM author WHERE author_id = $authorid";
	                    $run_authorsql=mysqli_query($connect, $authorsql);
						$row_authorsql=mysqli_fetch_assoc($run_authorsql);
						$authorname=$row_authorsql["author_name"];
						$prodprice=$row_bestprod["product_price"];
						$proddprice=$row_bestprod["discount_price"];
						$discount=$row_bestprod["discount"];
					?><div class="col-md-3">
					  	<figure class="product-style">
							<img src="staff/product_image/<?php echo $row_bestprod["product_image"]; ?>" alt="Books" class="product-item" style="width: 100%; height: 100%;">
							<form action="add-to-cart.php" method="POST">
					       <input type="hidden" id="product_id" name="product_id" value="<?php echo $product_id; ?>">
                           <button type="submit" name="add-to-cart" class="add-to-cart" data-product-tile="add-to-cart">Add to Cart</button>
					       </form>
							<figcaption>
								<h3><a href="single-product.php?hview&id=<?php echo $product_id; ?>"><?php echo $prodname; ?></a></h3>
								<p><?php echo $authorname; ?></p>
								<?php
								if($discount!=0)
								{
                                  ?>
								  <div class="item-price" style="font-size: 15px;"><del>RM <?php echo number_format($prodprice, 2); ?></del></div>
						          <div class="item-price">RM <?php echo number_format($proddprice, 2); ?></div>
						          <div class="item-price" style="color: blue; font-weight: bold; border: 2px solid blue; width: 160px; margin: auto;">Discount <?php echo number_format($discount, 0); ?>%</div>
								<?php
						        }
								else
								{?><div class="item-price">RM <?php echo number_format($prodprice, 2); ?></div><br><br><br>
								<?php
								}?>
							</figcaption>
						</figure>
					</div>
                     <?php
					}
					?>

		    	</div>

			  </div>

			</div>

		</div><!--inner-tabs-->

		</div>
	</div>
</section>
	<?php
	}
?>


<section id="quotation" class="align-center">
	<div class="inner-content">
		<h2 class="section-title divider">Quote of the day</h2>
		<blockquote data-aos="fade-up">
			<q>The more that you read, the more things you will know. The more that you learn, the more places you’ll go.</q>
			<div class="author-name">Dr. Seuss</div>
		</blockquote>
	</div>
</section>

<?php
$offerproduct="SELECT * FROM product LEFT JOIN stock ON product.product_id=stock.product_id WHERE product.availability = 0 AND NOT stock.stock_level=0 AND NOT product.discount = 0";
$run_offerproduct=mysqli_query($connect, $offerproduct);
$num_offerproduct=mysqli_num_rows($run_offerproduct);
if($num_offerproduct!=0)
{?>
<section id="special-offer" class="bookshelf" style="background: #EDEBE4;">

  <div class="section-header align-center" style="z-index: 0;">
	<div class="title">
		<span>Grab your opportunity</span>
	</div>
	<h2 class="section-title">Books with offer</h2>
  </div>

  <div class="container">
	<div class="row">
		<div class="inner-content">
			<div class="product-list" data-aos="fade-up">
				<div class="grid product-grid">
					<?php
					while($row_offerproduct=mysqli_fetch_assoc($run_offerproduct))
					{   $product_id=$row_offerproduct["product_id"];
						$prodname=$row_offerproduct["product_name"];
						$authorid=$row_offerproduct["author_id"];
						$authorsql="SELECT * FROM author WHERE author_id = $authorid";
	                    $run_authorsql=mysqli_query($connect, $authorsql);
						$row_authorsql=mysqli_fetch_assoc($run_authorsql);
						$authorname=$row_authorsql["author_name"];
						$prodprice=$row_offerproduct["product_price"];
						$proddprice=$row_offerproduct["discount_price"];
						$discount=$row_offerproduct["discount"];?>
						<figure class="product-style">
							<img src="staff/product_image/<?php echo $row_offerproduct["product_image"]; ?>" alt="Books" class="product-item" style="width: 350px; height: 450px;">
							<form action="add-to-cart.php" method="POST">
					       <input type="hidden" id="product_id" name="product_id" value="<?php echo $product_id; ?>">
                           <button type="submit" name="add-to-cart" class="add-to-cart" data-product-tile="add-to-cart" style="margin-left: 10px; margin-bottom: 80px;">Add to Cart</button>
					       </form>
							<figcaption>
								<h3><a href="single-product.php?hview&id=<?php echo $product_id; ?>"><?php echo $prodname; ?></a></h3>
								<p><?php echo $authorname; ?></p>
								<?php
								if($discount!=0)
								{
                                  ?>
								  <div class="item-price" style="font-size: 15px;"><del>RM <?php echo number_format($prodprice, 2); ?></del></div>
						          <div class="item-price">RM <?php echo number_format($proddprice, 2); ?></div>
						          <div class="item-price" style="color: blue; font-weight: bold; border: 2px solid blue; width: 160px; margin: auto;">Discount <?php echo number_format($discount, 0); ?>%</div>
								<?php
						        }
						        ?>
							</figcaption>
						</figure>
						<?php
					}
					?>
				</div><!--grid-->
			</div>
		</div><!--inner-content-->
	</div>
  </div><br><br>
</section>
<?php
}?>

<!--
<section id="subscribe">
	<div class="container">
		<div class="row">

			<div class="col-md-8 col-md-offset-2">
				<div class="row">

					<div class="col-md-6">

						<div class="title-element">
							<h2 class="section-title divider">Subscribe to our newsletter</h2>
						</div>

					</div>
					<div class="col-md-6">

						<div class="subscribe-content" data-aos="fade-up">
							<p>Sed eu feugiat amet, libero ipsum enim pharetra hac dolor sit amet, consectetur. Elit adipiscing enim pharetra hac.</p>
							<form id="form">
								<input type="text" name="email" placeholder="Enter your email addresss here">
								<button class="btn-subscribe">
									<span>send</span>
									<i class="icon icon-send"></i>
								</button>
							</form>
						</div>

					</div>

				</div>
			</div>

		</div>
	</div>
</section>

<section id="latest-blog">
	<div class="container">
		<div class="row">
			<div class="col-md-12">

				<div class="section-header align-center">
					<div class="title">
						<span>Read our articles</span>
					</div>
					<h2 class="section-title">Latest Articles</h2>
				</div>

				<div class="row">

					<div class="col-md-4">

						<article class="column" data-aos="fade-up">

							<figure>
								<a href="#" class="image-hvr-effect">
									<img src="images/post-img1.jpg" alt="post" class="post-image">
								</a>
							</figure>

							<div class="post-item">
								<div class="meta-date">Mar 30, 2021</div>
							    <h3><a href="#">Reading books always makes the moments happy</a></h3>

							    <div class="links-element">
								    <div class="categories">inspiration</div>
								    <div class="social-links">
										<ul>
											<li>
												<a href="#"><i class="icon icon-facebook"></i></a>
											</li>
											<li>
												<a href="#"><i class="icon icon-twitter"></i></a>
											</li>
											<li>
												<a href="#"><i class="icon icon-behance-square"></i></a>
											</li>
										</ul>
									</div>
								</div><!--links-element-->
<!--
							</div>
						</article>

					</div>
					<div class="col-md-4">

						<article class="column" data-aos="fade-down">
							<figure>
								<a href="#" class="image-hvr-effect">
									<img src="images/post-img2.jpg" alt="post" class="post-image">
								</a>
							</figure>
							<div class="post-item">
								<div class="meta-date">Mar 29, 2021</div>
							    <h3><a href="#">Reading books always makes the moments happy</a></h3>

							    <div class="links-element">
								    <div class="categories">inspiration</div>
								    <div class="social-links">
										<ul>
											<li>
												<a href="#"><i class="icon icon-facebook"></i></a>
											</li>
											<li>
												<a href="#"><i class="icon icon-twitter"></i></a>
											</li>
											<li>
												<a href="#"><i class="icon icon-behance-square"></i></a>
											</li>
										</ul>
									</div>
								</div><!--links-element-->
<!--
							</div>
						</article>

					</div>
					<div class="col-md-4">

						<article class="column" data-aos="fade-up">
							<figure>
								<a href="#" class="image-hvr-effect">
									<img src="images/post-img3.jpg" alt="post" class="post-image">
								</a>
							</figure>
							<div class="post-item">
								<div class="meta-date">Feb 27, 2021</div>
							    <h3><a href="#">Reading books always makes the moments happy</a></h3>

							    <div class="links-element">
								    <div class="categories">inspiration</div>
								    <div class="social-links">
										<ul>
											<li>
												<a href="#"><i class="icon icon-facebook"></i></a>
											</li>
											<li>
												<a href="#"><i class="icon icon-twitter"></i></a>
											</li>
											<li>
												<a href="#"><i class="icon icon-behance-square"></i></a>
											</li>
										</ul>
									</div>
								</div><!--links-element-->
<!--
							</div>
						</article>

					</div>

				</div>

				<div class="row">

					<div class="btn-wrap align-center">
						<a href="#" class="btn btn-outline-accent btn-accent-arrow" tabindex="0">Read All Articles<i class="icon icon-ns-arrow-right"></i></a>
					</div>
				</div>

			</div>
		</div>
	</div>
</section>

<section id="download-app" class="leaf-pattern-overlay">
	<div class="corner-pattern-overlay"></div>
		<div class="container">
			<div class="row">
				<div class="col-md-8 col-md-offset-2">
					<div class="row">

						<div class="col-md-5">
							<figure>
								<img src="images/device.png" alt="phone" class="single-image">
							</figure>
						</div>

						<div class="col-md-7">
							<div class="app-info">
								<h2 class="section-title divider">Download our app now !</h2>
								<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sagittis sed ptibus liberolectus nonet psryroin. Amet sed lorem posuere sit iaculis amet, ac urna. Adipiscing fames semper erat ac in suspendisse iaculis.</p>
								<div class="google-app">
									<img src="images/google-play.jpg" alt="google play">
									<img src="images/app-store.jpg" alt="app store">
								</div>
							</div>
						</div>

					</div>
				</div>
			</div>
		</div>
</section>-->

<footer id="footer" style="background-color: #f3e7be;">
	<div class="container">
		<div class="row">

			<div class="col-md-4" style="width: 40%;">

				<div class="footer-item">
					<div class="company-brand">
						<img src="images/icon/logo.png" alt="logo" class="footer-logo" style="height: 180px; width: 200px; margin-left: 70px;">
						<p>Welcome to Knowledge Bookstore, your gateway to a vast world of literary treasures, where words come alive and imagination knows no bounds.</p>
					</div>
				</div>

			</div>

			<div class="col-md-2" style="margin-top: 80px;">

				<div class="footer-menu">
					<h5><a href="about_us.php">About Us</a></h5>
					<ul class="menu-list">
						<li class="menu-item">
							Phone: 06 – 252 3253
						</li>
						<!--<li class="menu-item">
							<a href="#">articles </a>
						</li>
						<li class="menu-item">
							<a href="#">careers</a>
						</li>
						<li class="menu-item">
							<a href="#">service terms</a>
						</li>
						<li class="menu-item">
							<a href="#">donate</a>
						</li>-->
					</ul>
				</div>

			</div>
			<!--<div class="col-md-2">

				<div class="footer-menu">
					<h5>Discover</h5>
					<ul class="menu-list">
						<li class="menu-item">
							<a href="#">Home</a>
						</li>
						<li class="menu-item">
							<a href="#">Books</a>
						</li>
						<li class="menu-item">
							<a href="#">Authors</a>
						</li>
						<li class="menu-item">
							<a href="#">Subjects</a>
						</li>
						<li class="menu-item">
							<a href="#">Advanced Search</a>
						</li>
					</ul>
				</div>

			</div>-->
			<div class="col-md-2" style="padding-left: 30px; margin-top: 80px;">

				<div class="footer-menu">
					<h5>Quick Links</h5>
					<ul class="menu-list">
						<li class="menu-item">
							<a href="index.php">Home</a>
						</li>
						<li class="menu-item">
							<a href="shop.php">Shop</a>
						</li>
					</ul>
				</div>

			</div>
			<div class="col-md-2" style="padding-left: 100px; margin-top: 80px;">

				<div class="footer-menu">
					<h5>Services</h5>
					<ul class="menu-list">
						<!--<li class="menu-item">
							<a href="#">Help center</a>
						</li>
						<li class="menu-item">
							<a href="#">Report a problem</a>
						</li>
						<li class="menu-item">
							<a href="#">Suggesting edits</a>
						</li>-->
						<li class="menu-item">
							<a href="contact.php">Contact us</a>
						</li>
						<li class="menu-item">
							<a href="faq.php">FAQ</a>
						</li>
					</ul>
				</div>

			</div>

		</div>
		<!-- / row -->

	</div>
</footer>

<div id="footer-bottom">
	<div class="container">
		<div class="row">
			<div class="col-md-12">

				<div class="copyright">
					<div class="row">

						<div class="col-md-6">
							<p>© 2023 All rights reserved.</p>
						</div>

						<div class="col-md-6">

						</div>

					</div>
				</div><!--grid-->

			</div><!--footer-bottom-content-->
		</div>
	</div>
</div>

<script src="js/jquery-1.11.0.min.js"></script>
<script src="js/plugins.js"></script>
<script src="js/script.js"></script>
</body>
</html>

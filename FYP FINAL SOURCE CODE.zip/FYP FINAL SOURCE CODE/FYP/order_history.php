<!DOCTYPE html>
    <?php include("dataconnection.php");
	session_start();
	if(!isset($_SESSION['id']) || !isset($_SESSION['name']) || !isset($_SESSION['email']) || !isset($_SESSION['vemail'])){
		echo "<script>window.location.href='clogin.php';</script>";
	 }else if(isset($_SESSION['id']) &&  isset($_SESSION['name']) && isset($_SESSION['email']) && isset($_SESSION['vemail'])){
		   $vemail = $_SESSION['vemail'];
		   if($vemail == false){
			echo "<script>window.location.href='sentOTP.php';</script>";
			  exit();
		   }
		   // else{
		   // 	header("Location:./index.php");
		   // 	exit();
		   // }
	 }
/*if(isset($_SESSION["pf"]))
    {
      unset($_SESSION["pf"]);
    }*/
	if(isset($_SESSION["del"]))
	 {
		unset($_SESSION["del"]);
	 }
	 if(isset($_SESSION["rname"]))
    {
      unset($_SESSION["rname"]);
    }
    if(isset($_SESSION["remail"]))
    {
      unset($_SESSION["remail"]);
    }
    if(isset($_SESSION["rhp"]))
    {
      unset($_SESSION["rhp"]);
    }
	if(isset($_SESSION["padd1"]))
    {
      unset($_SESSION["padd1"]);
    }
    if(isset($_SESSION["padd2"]))
    {
      unset($_SESSION["padd2"]);
    }
    if(isset($_SESSION["pst"]))
    {
      unset($_SESSION["pst"]);
    }
    if(isset($_SESSION["ppc"]))
    {
      unset($_SESSION["ppc"]);
    }
    if(isset($_SESSION["pct"]))
    {
      unset($_SESSION["pct"]);
    }
    if(isset($_SESSION["ptype"]))
    {
      unset($_SESSION["ptype"]);
    }
    /*if(isset($_SESSION["payment_method"]))
    {
      unset($_SESSION["payment_method"]);
    }*/
    if(isset($_SESSION["cardtype"]))
    {
      unset($_SESSION["cardtype"]);
    }
    if(isset($_SESSION["holder_name"]))
    {
      unset($_SESSION["holder_name"]);
    }
    if(isset($_SESSION["cardnum"]))
    {
      unset($_SESSION["cardnum"]);
    }
    if(isset($_SESSION["cardvv"]))
    {
      unset($_SESSION["cardvv"]);
    }
    if(isset($_SESSION["carddate"]))
    {
      unset($_SESSION["carddate"]);
    }
    /*if(isset($_SESSION["ewallet_types"]))
    {
      unset($_SESSION["ewallet_types"]);
    }
    if(isset($_SESSION["transaction_no"]))
    {
      unset($_SESSION["transaction_no"]);
    }*/
    if(isset($_SESSION["address1"]))
    {
      unset($_SESSION["address1"]);
    }
    if(isset($_SESSION["address2"]))
    {
      unset($_SESSION["address2"]);
    }
    if(isset($_SESSION["city"]))
    {
      unset($_SESSION["city"]);
    }
    if(isset($_SESSION["state"]))
    {
      unset($_SESSION["state"]);
    }
    if(isset($_SESSION["postcode"]))
    {
      unset($_SESSION["postcode"]);
    }
    ?>
	<html lang="en">
	<head>
		<title>Book Store</title>
		<meta charset="utf-8">
	    <meta http-equiv="X-UA-Compatible" content="IE=edge">
	    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	    <meta name="format-detection" content="telephone=no">
	    <meta name="apple-mobile-web-app-capable" content="yes">
	    <meta name="author" content="">
	    <meta name="keywords" content="">
	    <meta name="description" content="">

	    <link rel="stylesheet" type="text/css" href="css/normalize.css">
	    <link rel="stylesheet" type="text/css" href="icomoon/icomoon.css">
	    <link rel="stylesheet" type="text/css" href="css/vendor.css">
	    <link rel="stylesheet" type="text/css" href="style.css">
		<!-- script
		================================================== -->
		<script src="http://translate.google.com/translate_a/element.js?cb=loadGoogleTranslate"></script>
		<script src="js/modernizr.js">
			function handle_keyup(event){
				if (event.keyCode === 13) {
                   document.getElementById('search_btn').click();
                }
			}
		</script>
		<script style="text/javascript">
			function show_filtertype()
			{
              var filter_opt=document.getElementById("filter_opt").value;
			  document.getElementById("order_date_opt").value="";
			  document.getElementById("order_status_opt").value="";
			  document.getElementById("total_items_opt").value="";
			  document.getElementById("amount_opt").value="";
              if(filter_opt=="")
			  {
                if(document.getElementById("order_date_opt").style.display=="inline-block")
				{  document.getElementById("order_date_opt").style.display="none";
				}
				if(document.getElementById("order_status_opt").style.display=="inline-block")
				{  document.getElementById("order_status_opt").style.display="none";
				}
				if(document.getElementById("total_items_opt").style.display=="inline-block")
				{  document.getElementById("total_items_opt").style.display="none";
				}
				if(document.getElementById("amount_opt").style.display=="inline-block")
				{  document.getElementById("amount_opt").style.display="none";
				}
				if(document.getElementById("custom-date").style.display=="inline-block")
				{  document.getElementById("custom-date").style.display="none";
				}
				document.getElementById('filterbtn').click();
			  }
			  else if(filter_opt=="1" && document.getElementById("order_date_opt").style.display=="none")
			  {
				document.getElementById("order_date_opt").style.display="inline-block";
				if(document.getElementById("order_status_opt").style.display=="inline-block")
				{  document.getElementById("order_status_opt").style.display="none";
				}
				if(document.getElementById("total_items_opt").style.display=="inline-block")
				{  document.getElementById("total_items_opt").style.display="none";
				}
				if(document.getElementById("amount_opt").style.display=="inline-block")
				{  document.getElementById("amount_opt").style.display="none";
				}
			  }
			  else if(filter_opt=="2" && document.getElementById("order_status_opt").style.display=="none")
			  {
				document.getElementById("order_status_opt").style.display="inline-block";
				if(document.getElementById("order_date_opt").style.display=="inline-block")
				{  document.getElementById("order_date_opt").style.display="none";
				}
				if(document.getElementById("total_items_opt").style.display=="inline-block")
				{  document.getElementById("total_items_opt").style.display="none";
				}
				if(document.getElementById("amount_opt").style.display=="inline-block")
				{  document.getElementById("amount_opt").style.display="none";
				}
				if(document.getElementById("custom-date").style.display=="inline-block")
				{  document.getElementById("custom-date").style.display="none";
				}
			  }
			  else if(filter_opt=="3" && document.getElementById("total_items_opt").style.display=="none")
			  {
				document.getElementById("total_items_opt").style.display="inline-block";
				if(document.getElementById("order_date_opt").style.display=="inline-block")
				{  document.getElementById("order_date_opt").style.display="none";
				}
				if(document.getElementById("order_status_opt").style.display=="inline-block")
				{  document.getElementById("order_status_opt").style.display="none";
				}
				if(document.getElementById("amount_opt").style.display=="inline-block")
				{  document.getElementById("amount_opt").style.display="none";
				}
				if(document.getElementById("custom-date").style.display=="inline-block")
				{  document.getElementById("custom-date").style.display="none";
				}
			  }
			  else if(filter_opt=="4" && document.getElementById("amount_opt").style.display=="none")
			  {
				document.getElementById("amount_opt").style.display="inline-block";
				if(document.getElementById("order_date_opt").style.display=="inline-block")
				{  document.getElementById("order_date_opt").style.display="none";
				}
				if(document.getElementById("order_status_opt").style.display=="inline-block")
				{  document.getElementById("order_status_opt").style.display="none";
				}
				if(document.getElementById("total_items_opt").style.display=="inline-block")
				{  document.getElementById("total_items_opt").style.display="none";
				}
				if(document.getElementById("custom-date").style.display=="inline-block")
				{  document.getElementById("custom-date").style.display="none";
				}
			  }
			}
			function orderdate_submit()
			{
				var order_opt=document.getElementById("order_date_opt").value;
				if(order_opt=="" || order_opt=="1" || order_opt=="2" || order_opt=="3" || order_opt=="4" || order_opt=="5")
				{ document.getElementById('filterbtn').click(); }
				else if(order_opt=="6")
				{ document.getElementById("custom-date").style.display="inline-block"; }
			}

			function loadGoogleTranslate() {
    const defaultLanguage = "en";

    const translateElement = new google.translate.TranslateElement({
      pageLanguage: defaultLanguage,
      includedLanguages: "en,ms,zh-CN",
      layout: google.translate.TranslateElement.InlineLayout.SIMPLE
    }, "google_element");

    // Get the language select dropdown element
    const languageSelect = document.getElementById("languageSelect");

    // Function to set a cookie
    function setCookie(name, value, days) {
      const expires = new Date();
      expires.setTime(expires.getTime() + days * 24 * 60 * 60 * 1000);
      document.cookie = `${name}=${value};expires=${expires.toUTCString()};path=/`;
    }

    // Function to get a cookie value
    function getCookie(name) {
      const cookieName = `${name}=`;
      const cookies = document.cookie.split(';');
      for (let i = 0; i < cookies.length; i++) {
        let cookie = cookies[i];
        while (cookie.charAt(0) === ' ') {
          cookie = cookie.substring(1);
        }
        if (cookie.indexOf(cookieName) === 0) {
          return cookie.substring(cookieName.length, cookie.length);
        }
      }
      return null;
    }

    // Set the initial language selection
    const storedLanguage = getCookie("selectedLanguage");
    if (storedLanguage) {
      languageSelect.value = storedLanguage;
      translateElement.update({
        includedLanguages: storedLanguage
      });
    }

    // Add event listener for change event
    languageSelect.addEventListener("change", function() {
      const selectedLanguage = this.value;
      translateElement.update({
        includedLanguages: selectedLanguage
      });
      setCookie("selectedLanguage", selectedLanguage, 30); // Set the cookie for 30 days
    });
  }
		</script>
	</head>

<body>


<div id="header-wrap">

	<div class="top-content">
		<div class="container">
			<div class="row">
				<div class="col-md-6" style="width: 25%;">

				</div>
				<div class="col-md-6" style="width: 75%;">
					<div class="right-element">
						<?php
						if(isset($_SESSION["id"]))
						{   $cust_id=$_SESSION["id"];
							$cartsql="SELECT * FROM cart WHERE customer_id=$cust_id";
							$run_cartsql=mysqli_query($connect, $cartsql);
							$num_rows_cartsql=mysqli_num_rows($run_cartsql);
							$rows_cartsql=mysqli_fetch_assoc($run_cartsql);
							if($num_rows_cartsql==0)
							{
								$cartitem_rows=0;
							}
							else
							{   $cartid=$rows_cartsql["cart_id"];
								$cartitemsql="SELECT * FROM cart_item WHERE cart_id=$cartid";
							    $run_cartitemsql=mysqli_query($connect, $cartitemsql);
							    $cartitem_rows=mysqli_num_rows($run_cartitemsql);
								$del_val=0;
								while($rows_cartitemsql=mysqli_fetch_assoc($run_cartitemsql))
								{
                                  $prodid=$rows_cartitemsql["product_id"];
								  $itemqty=$rows_cartitemsql["item_quantity"];
								  $stocksql="SELECT * FROM stock WHERE product_id='$prodid'";
                                  $run_stocksql=mysqli_query($connect, $stocksql);
                                  $stockrows=mysqli_fetch_assoc($run_stocksql);
                                  $stocklevel=$stockrows['stock_level'];
								  $prodsql="SELECT * FROM product WHERE product_id='$prodid' AND availability=0";
                                  $run_prodsql=mysqli_query($connect, $prodsql);
                                  $prodrows=mysqli_num_rows($run_prodsql);
								  if($prodrows==0)
								  {
									$del_cartitem="DELETE FROM cart_item WHERE cart_id=$cartid AND product_id='$prodid'";
									$run_del_cartitem=mysqli_query($connect, $del_cartitem);
									if($run_del_cartitem)
                                      $del_val++;
								  }
								  else if($stocklevel==0)
								  {
									$del_cartitem="DELETE FROM cart_item WHERE cart_id=$cartid AND product_id='$prodid'";
									$run_del_cartitem=mysqli_query($connect, $del_cartitem);
									if($run_del_cartitem)
                                      $del_val++;
								  }
								  else if($itemqty>$stocklevel)
								  {
									$update_cartitem="UPDATE cart_item SET item_quantity=$stocklevel WHERE cart_id=$cartid AND product_id='$prodid'";
									$run_update_cartitem=mysqli_query($connect, $update_cartitem);
								  }
								}
								if($del_val==$cartitem_rows)
								{
									$del_cart="DELETE FROM cart WHERE cart_id=$cartid";
									$run_del_cart=mysqli_query($connect, $del_cart);
								}
								$cartitem_rows-=$del_val;
							}
							$select_cust="SELECT * FROM customer WHERE customer_id=$cust_id";
							$run_select_cust=mysqli_query($connect, $select_cust);
							$row_select_cust=mysqli_fetch_assoc($run_select_cust);
							$user_profile=$row_select_cust["customer_profile_picture"];
							?>
							<a href="cart.php" class="cart for-buy"><img src="images/icon/carts.png" style="width: 50px; height: 50px; opacity: 70%; margin-bottom: 5px;"><span>Cart: <?php echo $cartitem_rows; ?> item(s)</span></a>
						<nav id="navbar" style="display: inline-block; margin-left: -40px; position: relative; z-index: 3;">
						<div class="main-menu stellarnav">
						<ul class="menu-list">
						<li class="menu-item has-sub">
						<a href="./user_profile.php" class="nav-link" data-effect="Pages"><img src="images/cus_profile/<?php echo $user_profile; ?>" style="width: 40px; height: 40px; border-radius: 50%; margin-right: 10px;" alt="user_profile" title="user_profile">Account</a>
							<ul style="font-size: 16px;">
								<li><a href="./user_profile.php">My Profile</a></li>
								<li><a href="./logoutaction.php">Logout</a></li>
							 </ul>
						</li>
						</ul>
						</div>
						</nav>
                        <?php
						}
						?>
						<div class="action-menu" style="margin-left: 10px;">

							<div class="search-bar">
								<a href="#" class="search-button search-toggle" data-selector="#header-wrap">
									<i class="icon icon-search"></i>
								</a>
								<form role="search" method="get" class="search-box" action="search_products.php">
									<input class="search-field text search-input" placeholder="Search products" type="text" name="search_keyword" onkeyup="handle_keyup(event)">
									<input type="submit" id="search_btn" style="display: none;">
								</form>
							</div>
						</div>
                        <div id="google_element" style="display: inline-block;"></div>
					</div><!--top-right-->
				</div>

			</div>
		</div>
	</div><!--top-content-->

	<header id="header" style="background-color: #f3e7be;">
		<div class="container">
			<div class="row">

			    <div class="col-md-2">
					<!--<div class="main-logo">-->
						<a href="index.php"><img src="images/icon/logo.png" alt="logo" style="height: 140px; margin:-60px 0px -30px 0px;"></a>
					<!--</div>-->
				</div>

				<div class="col-md-10">

					<nav id="navbar" style="position: relative; z-index: 1;">
						<div class="main-menu stellarnav">
							<ul class="menu-list">
								<li class="menu-item active"><a href="index.php" data-effect="Home">Home</a></li>
								<li class="menu-item"><a href="about_us.php" class="nav-link" data-effect="About">About</a></li>
								<!--<li class="menu-item has-sub">
									<a href="#pages" class="nav-link" data-effect="Pages">Pages</a>

									<ul>
								        <li><a href="styles.html">Styles</a></li>
								        <li><a href="blog.html">Blog</a></li>
								        <li><a href="single-post.html">Post Single</a></li>
								        <li><a href="thank-you.html">Thank You</a></li>
								     </ul>

								</li>-->
								<li class="menu-item"><a href="shop.php" class="nav-link" data-effect="Shop">Shop</a></li>
								<li class="menu-item"><a href="contact.php" class="nav-link" data-effect="Contact">Contact Us</a></li>
							</ul>

							<div class="hamburger">
				                <span class="bar"></span>
				                <span class="bar"></span>
				                <span class="bar"></span>
				            </div>

						</div>
					</nav>

				</div>

			</div>
		</div>
	</header>

</div><!--header-wrap-->

<div>
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div class="colored">
					<br>
					<div class="breadcum-items">
						<span class="item"><a href="index.php">Home</a> /</span>
						<span class="item colored">Order History</span>
					</div>
				</div>
			</div>
		</div>
	</div>
</div><!--site-banner-->

<section class="padding-large">
	<div class="container">
	<?php date_default_timezone_set('Asia/Kuala_Lumpur');
		   $max_date=date('Y-m-d');
		   $min_date=date('Y-m-d', strtotime('-10 years', strtotime($max_date)));
	$check_orders="SELECT * FROM orders WHERE customer_id=$cust_id";
	$run_check_orders=mysqli_query($connect, $check_orders);
	$num_check_orders=mysqli_num_rows($run_check_orders);
	if($num_check_orders!=0)
	{?>
    <form name="filter_form" style="margin-left: 850px; margin-bottom: -20px;" method="POST" action="order_history.php">
	<p>Filter by:
	<select id="filter_opt" name="filter_opt" onchange="show_filtertype()">
	    <option value="" >Select an option</option>
		<option value="1" <?php if(isset($_POST["filter_btn"]) && $_POST["filter_opt"]=="1" || isset($_GET["vo"]) && $_GET["fo"]=="1") echo "selected";?>>Order Date</option>
		<option value="2" <?php if(isset($_POST["filter_btn"]) && $_POST["filter_opt"]=="2" || isset($_GET["vo"]) && $_GET["fo"]=="2") echo "selected";?>>Order Status</option>
		<option value="3" <?php if(isset($_POST["filter_btn"]) && $_POST["filter_opt"]=="3" || isset($_GET["vo"]) && $_GET["fo"]=="3") echo "selected";?>>Total Items</option>
		<option value="4" <?php if(isset($_POST["filter_btn"]) && $_POST["filter_opt"]=="4" || isset($_GET["vo"]) && $_GET["fo"]=="4") echo "selected";?>>Amount</option>
	</select>
    <select id="order_date_opt" name="order_date_opt" onchange="orderdate_submit()" <?php if(isset($_POST["filter_btn"]) && $_POST["filter_opt"]=="1" || isset($_GET["vo"]) && $_GET["fo"]=="1") echo "style='display: inline-block;'"; else echo "style='display: none;'"; ?>>
	    <option value="" >Filter option</option>
		<option value="1" <?php if(isset($_POST["filter_btn"]) && $_POST["order_date_opt"]=="1" || isset($_GET["vo"]) && $_GET["fo"]=="1" && $_GET["ft"]=="1") echo "selected";?>>today</option>
		<option value="2" <?php if(isset($_POST["filter_btn"]) && $_POST["order_date_opt"]=="2" || isset($_GET["vo"]) && $_GET["fo"]=="1" && $_GET["ft"]=="2") echo "selected";?>>last 3 days</option>
		<option value="3" <?php if(isset($_POST["filter_btn"]) && $_POST["order_date_opt"]=="3" || isset($_GET["vo"]) && $_GET["fo"]=="1" && $_GET["ft"]=="3") echo "selected";?>>last 7 days</option>
		<option value="4" <?php if(isset($_POST["filter_btn"]) && $_POST["order_date_opt"]=="4" || isset($_GET["vo"]) && $_GET["fo"]=="1" && $_GET["ft"]=="4") echo "selected";?>>last 30 days</option>
		<option value="5" <?php if(isset($_POST["filter_btn"]) && $_POST["order_date_opt"]=="5" || isset($_GET["vo"]) && $_GET["fo"]=="1" && $_GET["ft"]=="5") echo "selected";?>>last 6 months</option>
		<option value="6" <?php if(isset($_POST["filter_btn"]) && $_POST["order_date_opt"]=="6" || isset($_GET["vo"]) && $_GET["fo"]=="1" && $_GET["ft"]=="6") echo "selected";?>>Custom Date</option>
	</select>
	<select id="order_status_opt" name="order_status_opt" onchange="document.getElementById('filterbtn').click()" <?php if(isset($_POST["filter_btn"]) && $_POST["filter_opt"]=="2" || isset($_GET["vo"]) && $_GET["fo"]=="2") echo "style='display: inline-block;'"; else echo "style='display: none;'"; ?>>
	    <option value="" >Filter option</option>
		<option value="1" <?php if(isset($_POST["filter_btn"]) && $_POST["order_status_opt"]=="1" || isset($_GET["vo"]) && $_GET["fo"]=="2" && $_GET["ft"]=="1") echo "selected";?>>Processing</option>
		<option value="2" <?php if(isset($_POST["filter_btn"]) && $_POST["order_status_opt"]=="2" || isset($_GET["vo"]) && $_GET["fo"]=="2" && $_GET["ft"]=="2") echo "selected";?>>Shipping</option>
		<option value="3" <?php if(isset($_POST["filter_btn"]) && $_POST["order_status_opt"]=="3" || isset($_GET["vo"]) && $_GET["fo"]=="2" && $_GET["ft"]=="3") echo "selected";?>>Delivered</option>
		<option value="4" <?php if(isset($_POST["filter_btn"]) && $_POST["order_status_opt"]=="4" || isset($_GET["vo"]) && $_GET["fo"]=="2" && $_GET["ft"]=="4") echo "selected";?>>Cancelled</option>
	</select>
	<select id="total_items_opt" name="total_items_opt" onchange="document.getElementById('filterbtn').click()" <?php if(isset($_POST["filter_btn"]) && $_POST["filter_opt"]=="3" || isset($_GET["vo"]) && $_GET["fo"]=="3") echo "style='display: inline-block;'"; else echo "style='display: none;'"; ?>>
	    <option value="" >Filter option</option>
		<option value="1" <?php if(isset($_POST["filter_btn"]) && $_POST["total_items_opt"]=="1" || isset($_GET["vo"]) && $_GET["fo"]=="3" && $_GET["ft"]=="1") echo "selected";?>>ascending</option>
		<option value="2" <?php if(isset($_POST["filter_btn"]) && $_POST["total_items_opt"]=="2" || isset($_GET["vo"]) && $_GET["fo"]=="3" && $_GET["ft"]=="2") echo "selected";?>>descending</option>
	</select>
	<select id="amount_opt" name="amount_opt" onchange="document.getElementById('filterbtn').click()" <?php if(isset($_POST["filter_btn"]) && $_POST["filter_opt"]=="4" || isset($_GET["vo"]) && $_GET["fo"]=="4") echo "style='display: inline-block;'"; else echo "style='display: none;'"; ?>>
	    <option value="" >Filter option</option>
		<option value="1" <?php if(isset($_POST["filter_btn"]) && $_POST["amount_opt"]=="1" || isset($_GET["vo"]) && $_GET["fo"]=="4" && $_GET["ft"]=="1") echo "selected";?>>ascending</option>
		<option value="2" <?php if(isset($_POST["filter_btn"]) && $_POST["amount_opt"]=="2" || isset($_GET["vo"]) && $_GET["fo"]=="4" && $_GET["ft"]=="2") echo "selected";?>>descending</option>
	</select>
	<input type="date" id="custom-date" name="custom-date" onchange="document.getElementById('filterbtn').click()" <?php if(isset($_POST["filter_btn"]) && $_POST["filter_opt"]=="1" && $_POST["order_date_opt"]=="6"){ $selected_custom_date=$_POST["custom-date"]; echo "style='display: inline-block;'"; echo "value='$selected_custom_date'";} else if(isset($_GET["vo"]) && $_GET["fo"]=="1" && $_GET["ft"]=="6"){ $selected_custom_date=$_GET["od"]; echo "style='display: inline-block;'"; echo "value='$selected_custom_date'";} else echo "style='display: none;'"; ?> max="<?php echo $max_date; ?>" min="<?php echo $min_date; ?>">
    </p>
	<input type="submit" id="filterbtn" name="filter_btn" style="display: none;">
   </form>
	<?php
	}
   $detect=0; $filter_opt="0"; $filter_type="0"; $custom_date="0";
   if(isset($_POST["filter_btn"]) || isset($_GET["vo"]))
   {   if(isset($_GET["vo"]))
	   { $filter_opt=$_GET["fo"];}
	   else
	   { $filter_opt=$_POST["filter_opt"];}
	   if($filter_opt=="" || $filter_opt=="0")
	   {
		   $orders="SELECT * FROM orders WHERE customer_id=$cust_id";
		   $run_orders=mysqli_query($connect, $orders);
		   $num_orders=mysqli_num_rows($run_orders);
		   if($num_orders!=0)
		   {
			echo "<p style='margin-left: 50px; font-size: 18px;'>Currently have $num_orders order record(s).</p>";
		   }
	   }
	   else if($filter_opt=="1")
	   {   date_default_timezone_set('Asia/Kuala_Lumpur');
		   $date=date('Y-m-d');
		   if(isset($_GET["vo"]))
		   { $order_date_opt=$_GET["ft"];}
		   else
		   { $order_date_opt=$_POST["order_date_opt"];}
		   if($order_date_opt=="")
	       {  $filter_type="";
		      $orders="SELECT * FROM orders WHERE customer_id=$cust_id";
		      $run_orders=mysqli_query($connect, $orders);
		      $num_orders=mysqli_num_rows($run_orders);
		      echo "<p style='margin-left: 50px; font-size: 18px;'>Currently have $num_orders order record(s).</p>";
	       }
		   else if($order_date_opt=="1")
		   {   $filter_type="1";
			   $orders="SELECT * FROM orders WHERE customer_id=$cust_id AND order_date LIKE '%$date%'";
			   $run_orders=mysqli_query($connect, $orders);
			   $num_orders=mysqli_num_rows($run_orders);
			   if($num_orders==0)
			   {   $detect++;
				   echo "<p style='margin-left: 50px; font-size: 18px;'>There is no order record placed on today.</p>";
			   }
			   else
			   {
				echo "<p style='margin-left: 50px; font-size: 18px;'>$num_orders order record(s) had placed on today currently.</p>";
			   }
		   }
		   else if($order_date_opt=="2")
		   {   $filter_type="2";
			   $date=date('Y-m-d H:i:s');
			   $before_date=date('Y-m-d', strtotime('-3 days', strtotime($date)));
			   $orders="SELECT * FROM orders WHERE customer_id=$cust_id AND order_date BETWEEN '$before_date' AND '$date'";
			   $run_orders=mysqli_query($connect, $orders);
			   $num_orders=mysqli_num_rows($run_orders);
			   if($num_orders==0)
			   {   $detect++;
				   echo "<p style='margin-left: 50px; font-size: 18px;'>There is no order record placed on last 3 days.</p>";
			   }
			   else
			   {
				echo "<p style='margin-left: 50px; font-size: 18px;'>$num_orders order record(s) had placed on last 3 days currently.</p>";
			   }
		   }
		   else if($order_date_opt=="3")
		   {   $filter_type="3";
			   $date=date('Y-m-d H:i:s');
			   $before_date=date('Y-m-d', strtotime('-7 days', strtotime($date)));
			   $orders="SELECT * FROM orders WHERE customer_id=$cust_id AND order_date BETWEEN '$before_date' AND '$date'";
			   $run_orders=mysqli_query($connect, $orders);
			   $num_orders=mysqli_num_rows($run_orders);
			   if($num_orders==0)
			   {   $detect++;
				   echo "<p style='margin-left: 50px; font-size: 18px;'>There is no order record placed on last 7 days.</p>";
			   }
			   else
			   {
				echo "<p style='margin-left: 50px; font-size: 18px;'>$num_orders order record(s) had placed on last 7 days currently.</p>";
			   }
		   }
		   else if($order_date_opt=="4")
		   {   $filter_type="4";
			   $date=date('Y-m-d H:i:s');
			   $before_date=date('Y-m-d', strtotime('-30 days', strtotime($date)));
			   $orders="SELECT * FROM orders WHERE customer_id=$cust_id AND order_date BETWEEN '$before_date' AND '$date'";
			   $run_orders=mysqli_query($connect, $orders);
			   $num_orders=mysqli_num_rows($run_orders);
			   if($num_orders==0)
			   {   $detect++;
				   echo "<p style='margin-left: 50px; font-size: 18px;'>There is no order record placed on last 30 days.</p>";
			   }
			   else
			   {
				echo "<p style='margin-left: 50px; font-size: 18px;'>$num_orders order record(s) had placed on last 30 days currently.</p>";
			   }
		   }
		   else if($order_date_opt=="5")
		   {   $filter_type="5";
			   $date=date('Y-m-d H:i:s');
			   $before_date=date('Y-m-d', strtotime('-6 months', strtotime($date)));
			   $orders="SELECT * FROM orders WHERE customer_id=$cust_id AND order_date BETWEEN '$before_date' AND '$date'";
			   $run_orders=mysqli_query($connect, $orders);
			   $num_orders=mysqli_num_rows($run_orders);
			   if($num_orders==0)
			   {   $detect++;
				   echo "<p style='margin-left: 50px; font-size: 18px;'>There is no order record placed on last 6 months.</p>";
			   }
			   else
			   {
				echo "<p style='margin-left: 50px; font-size: 18px;'>$num_orders order record(s) had placed on last 6 months currently.</p>";
			   }
		   }
		   else if($order_date_opt=="6")
		   {   $filter_type="6";
			   if(isset($_GET["vo"]))
			   { $custom_date=$_GET["od"];}
			   else
			   { $custom_date=$_POST["custom-date"];}
			   $orders="SELECT * FROM orders WHERE customer_id=$cust_id AND order_date LIKE '%$custom_date%'";
			   $run_orders=mysqli_query($connect, $orders);
			   $num_orders=mysqli_num_rows($run_orders);
			   if($num_orders==0)
			   {   $detect++;
				   echo "<p style='margin-left: 50px; font-size: 18px;'>There is no order record placed on $custom_date.</p>";
			   }
			   else
			   {
				echo "<p style='margin-left: 50px; font-size: 18px;'>$num_orders order record(s) had placed on $custom_date currently.</p>";
			   }
		   }
	   }
	   else if($filter_opt=="2")
	   {
		if(isset($_GET["vo"]))
		{ $order_status_opt=$_GET["ft"];}
		else
		{ $order_status_opt=$_POST["order_status_opt"];}
		 if($order_status_opt=="")
		 {  $filter_type="";
			$orders="SELECT * FROM orders WHERE customer_id=$cust_id";
		    $run_orders=mysqli_query($connect, $orders);
		    $num_orders=mysqli_num_rows($run_orders);
		    echo "<p style='margin-left: 50px; font-size: 18px;'>Currently have $num_orders order record(s).</p>";
		 }
		 else if($order_status_opt=="1")
		 {  $filter_type="1";
			$orders="SELECT * FROM orders WHERE customer_id=$cust_id AND order_status='Processing'";
			$run_orders=mysqli_query($connect, $orders);
			$num_orders=mysqli_num_rows($run_orders);
			if($num_orders==0)
			{   $detect++;
			    echo "<p style='margin-left: 50px; font-size: 18px;'>There is no Processing order record currently.</p>";
			}
			else
			{
				echo "<p style='margin-left: 50px; font-size: 18px;'>$num_orders Processing order record(s) found currently.</p>";
			}
		 }
		 else if($order_status_opt=="2")
		 {  $filter_type="2";
			$orders="SELECT * FROM orders WHERE customer_id=$cust_id AND order_status='Shipping'";
			$run_orders=mysqli_query($connect, $orders);
			$num_orders=mysqli_num_rows($run_orders);
			if($num_orders==0)
			{   $detect++;
			    echo "<p style='margin-left: 50px; font-size: 18px;'>There is no Shipping order record currently.</p>";
			}
			else
			{
				echo "<p style='margin-left: 50px; font-size: 18px;'>$num_orders Shipping order record(s) found currently.</p>";
			}
		 }
		 else if($order_status_opt=="3")
		 {  $filter_type="3";
			$orders="SELECT * FROM orders WHERE customer_id=$cust_id AND order_status='Delivered'";
			$run_orders=mysqli_query($connect, $orders);
			$num_orders=mysqli_num_rows($run_orders);
			if($num_orders==0)
			{   $detect++;
			    echo "<p style='margin-left: 50px; font-size: 18px;'>There is no Delivered order record currently.</p>";
			}
			else
			{
				echo "<p style='margin-left: 50px; font-size: 18px;'>$num_orders Delivered order record(s) found currently.</p>";
			}
		 }
		 else if($order_status_opt=="4")
		 {  $filter_type="4";
			$orders="SELECT * FROM orders WHERE customer_id=$cust_id AND order_status='Cancelled'";
			$run_orders=mysqli_query($connect, $orders);
			$num_orders=mysqli_num_rows($run_orders);
			if($num_orders==0)
			{   $detect++;
			    echo "<p style='margin-left: 50px; font-size: 18px;'>There is no Cancelled order record currently.</p>";
			}
			else
			{
				echo "<p style='margin-left: 50px; font-size: 18px;'>$num_orders Cancelled order record(s) found currently.</p>";
			}
		 }
	   }
	   else if($filter_opt=="3")
	   { if(isset($_GET["vo"]))
		 { $total_items_opt=$_GET["ft"];}
		 else
		 { $total_items_opt=$_POST["total_items_opt"];}
         if($total_items_opt=="")
		 {  $filter_type="";
			$orders="SELECT * FROM orders WHERE customer_id=$cust_id";
		    $run_orders=mysqli_query($connect, $orders);
		    $num_orders=mysqli_num_rows($run_orders);
		    echo "<p style='margin-left: 50px; font-size: 18px;'>Currently have $num_orders order record(s).</p>";
		 }
		 else if($total_items_opt=="1")
		 {  $filter_type="1";
			$orders="SELECT orders.*, COUNT(order_details.order_id) AS record_count FROM orders RIGHT JOIN order_details ON orders.order_id = order_details.order_id WHERE orders.customer_id=$cust_id GROUP BY order_id ORDER BY record_count ASC";
		    $run_orders=mysqli_query($connect, $orders);
		    $num_orders=mysqli_num_rows($run_orders);
		    echo "<p style='margin-left: 50px; font-size: 18px;'>Currently have $num_orders order record(s).</p>";
		 }
		 else if($total_items_opt=="2")
		 {  $filter_type="2";
			$orders="SELECT orders.*, COUNT(order_details.order_id) AS record_count FROM orders RIGHT JOIN order_details ON orders.order_id = order_details.order_id WHERE orders.customer_id=$cust_id GROUP BY order_id ORDER BY record_count DESC";
		    $run_orders=mysqli_query($connect, $orders);
		    $num_orders=mysqli_num_rows($run_orders);
		    echo "<p style='margin-left: 50px; font-size: 18px;'>Currently have $num_orders order record(s).</p>";
		 }
	   }
	   else if($filter_opt=="4")
	   { if(isset($_GET["vo"]))
		 { $amount_opt=$_GET["ft"];}
		 else
		 { $amount_opt=$_POST["amount_opt"];}
		 if($amount_opt=="")
		 {  $filter_type="";
			$orders="SELECT * FROM orders WHERE customer_id=$cust_id";
		    $run_orders=mysqli_query($connect, $orders);
		    $num_orders=mysqli_num_rows($run_orders);
		    echo "<p style='margin-left: 50px; font-size: 18px;'>Currently have $num_orders order record(s).</p>";
		 }
		 else if($amount_opt=="1")
		 {  $filter_type="1";
			$orders="SELECT * FROM orders WHERE customer_id=$cust_id ORDER BY overall_total ASC";
			$run_orders=mysqli_query($connect, $orders);
			$num_orders=mysqli_num_rows($run_orders);
			echo "<p style='margin-left: 50px; font-size: 18px;'>Currently have $num_orders order record(s).</p>";
		 }
		 else if($amount_opt=="2")
		 {  $filter_type="2";
			$orders="SELECT * FROM orders WHERE customer_id=$cust_id ORDER BY overall_total DESC";
			$run_orders=mysqli_query($connect, $orders);
			$num_orders=mysqli_num_rows($run_orders);
			echo "<p style='margin-left: 50px; font-size: 18px;'>Currently have $num_orders order record(s).</p>";
		 }
	   }
   }
   else
   {
	   $orders="SELECT * FROM orders WHERE customer_id=$cust_id";
	   $run_orders=mysqli_query($connect, $orders);
	   $num_orders=mysqli_num_rows($run_orders);
	   if($num_orders!=0)
	   {
			echo "<p style='margin-left: 50px; font-size: 18px;'>Currently have $num_orders order record(s).</p>";
	   }
   }
   if($detect==0 && $num_check_orders!=0)
   {?>
   <table width="1300px;" style="margin: auto; border-collapse: collapse;">
    <tr class="thead" style="background-color: #dbd9d9;">
           <th style="width:150px; font-size: 20px; text-align: center;">Order ID</th>
           <th style="width:350px; font-size: 20px; text-align: center;">Order Date/Time</th>
           <th style="width:250px; font-size: 20px; text-align: center;">Order Status</th>
           <th style="width:150px; font-size: 20px; text-align: center;">Total Items</th>
           <th style="width:250px; font-size: 20px; text-align: center;">Amount(RM)</th>
           <th style="width:150px; font-size: 20px; text-align: center;">Action</th>
    </tr>
    <?php
    while($rows_orders=mysqli_fetch_assoc($run_orders))
    {  $order_id=$rows_orders["order_id"];
       $order_date=$rows_orders["order_date"];
	   $formatted_date = date('d/m/Y H:i:s', strtotime($order_date));
       $order_status=$rows_orders["order_status"];
       $amount=$rows_orders["overall_total"];
       $order_items="SELECT * FROM order_details WHERE order_id=$order_id";
       $run_order_items=mysqli_query($connect, $order_items);
       $total_items=mysqli_num_rows($run_order_items);?>
       <tr class="thead" style="background-color: white;">
           <td style="font-size: 20px; text-align: center;"><?php echo $order_id; ?></td>
           <td style="font-size: 20px; text-align: center;"><?php echo $formatted_date; ?></td>
           <td style="font-size: 20px; text-align: center;"><?php echo $order_status; ?></td>
           <td style="font-size: 20px; text-align: center;"><?php echo $total_items; ?></td>
           <td style="font-size: 20px; text-align: center;"><?php echo $amount; ?></td>
           <td style="font-size: 20px; text-align: center;"><a href='order_details.php?vo&oid=<?php echo $order_id; ?>&fo=<?php echo $filter_opt; ?>&ft=<?php echo $filter_type; ?>&od=<?php echo $custom_date; ?>' style='text-decoration: none;'>More Details</a></td>
       </tr>
       <?php
    }
    ?>
    </table>
   <?php
   }
   else if($num_check_orders==0)
   { $sqlcust="SELECT * FROM customer WHERE customer_id=$cust_id";
	 $run_sqlcust=mysqli_query($connect, $sqlcust);
	 $rows_sqlcust=mysqli_fetch_assoc($run_sqlcust);
	 $cust_name=$rows_sqlcust["customer_name"];
	echo "<p style='text-align: center; font-size: 18px;'>Dear $cust_name, you currently do not have any order records placed before.</p>";
   }
   ?>
   </div>
</section>


<footer id="footer" style="background-color: #f3e7be;">
	<div class="container">
		<div class="row">

			<div class="col-md-4" style="width: 40%;">

				<div class="footer-item">
					<div class="company-brand">
						<img src="images/icon/logo.png" alt="logo" class="footer-logo" style="height: 180px; width: 200px; margin-left: 70px;">
						<p>Welcome to Knowledge Bookstore, your gateway to a vast world of literary treasures, where words come alive and imagination knows no bounds.</p>
					</div>
				</div>

			</div>

			<div class="col-md-2" style="margin-top: 80px;">

				<div class="footer-menu">
					<h5><a href="about_us.php">About Us</a></h5>
					<ul class="menu-list">
						<li class="menu-item">
							Phone: 06 – 252 3253
						</li>
						<!--<li class="menu-item">
							<a href="#">articles </a>
						</li>
						<li class="menu-item">
							<a href="#">careers</a>
						</li>
						<li class="menu-item">
							<a href="#">service terms</a>
						</li>
						<li class="menu-item">
							<a href="#">donate</a>
						</li>-->
					</ul>
				</div>

			</div>
			<!--<div class="col-md-2">

				<div class="footer-menu">
					<h5>Discover</h5>
					<ul class="menu-list">
						<li class="menu-item">
							<a href="#">Home</a>
						</li>
						<li class="menu-item">
							<a href="#">Books</a>
						</li>
						<li class="menu-item">
							<a href="#">Authors</a>
						</li>
						<li class="menu-item">
							<a href="#">Subjects</a>
						</li>
						<li class="menu-item">
							<a href="#">Advanced Search</a>
						</li>
					</ul>
				</div>

			</div>-->
			<div class="col-md-2" style="padding-left: 30px; margin-top: 80px;">

				<div class="footer-menu">
					<h5>Quick Links</h5>
					<ul class="menu-list">
						<li class="menu-item">
							<a href="index.php">Home</a>
						</li>
						<li class="menu-item">
							<a href="shop.php">Shop</a>
						</li>
					</ul>
				</div>

			</div>
			<div class="col-md-2" style="padding-left: 100px; margin-top: 80px;">

				<div class="footer-menu">
					<h5>Services</h5>
					<ul class="menu-list">
						<!--<li class="menu-item">
							<a href="#">Help center</a>
						</li>
						<li class="menu-item">
							<a href="#">Report a problem</a>
						</li>
						<li class="menu-item">
							<a href="#">Suggesting edits</a>
						</li>-->
						<li class="menu-item">
							<a href="contact.php">Contact us</a>
						</li>
						<li class="menu-item">
							<a href="faq.php">FAQ</a>
						</li>
					</ul>
				</div>

			</div>

		</div>
		<!-- / row -->

	</div>
</footer>

<div id="footer-bottom">
	<div class="container">
		<div class="row">
			<div class="col-md-12">

				<div class="copyright">
					<div class="row">

						<div class="col-md-6">
							<p>© 2023 All rights reserved.</p>
						</div>

						<div class="col-md-6">

						</div>

					</div>
				</div><!--grid-->

			</div><!--footer-bottom-content-->
		</div>
	</div>
</div>

<script src="js/jquery-1.11.0.min.js"></script>
<script src="js/plugins.js"></script>
<script src="js/script.js"></script>

</body>
</html>

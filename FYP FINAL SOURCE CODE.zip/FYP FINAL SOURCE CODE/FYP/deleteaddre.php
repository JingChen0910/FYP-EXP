<?php
session_start();
require_once 'dataconnection.php';
if(!isset($_SESSION['id']) || !isset($_SESSION['name']) || !isset($_SESSION['email']) || !isset($_SESSION['vemail'])){
	echo "<script>window.location.href='clogin.php';</script>";
 }else if(isset($_SESSION['id']) &&  isset($_SESSION['name']) && isset($_SESSION['email']) && isset($_SESSION['vemail'])){
	   $vemail = $_SESSION['vemail'];
	   if($vemail == false){
		echo "<script>window.location.href='sentOTP.php';</script>";
		  exit();
	   }
	}
if(isset($_GET['addressID'])){
    $addressID = $_GET['addressID'];
    $sql = "DELETE FROM address WHERE address_id ='".$addressID."';";
    $_SESSION["del"]="1";
    if(mysqli_query($connect,$sql)){
        header("Location:./user_profile.php?daerror=nonerrordeletedone");
    }else{
        header("Location:./user_profile.php?daerror=deleteerror");
    }
}
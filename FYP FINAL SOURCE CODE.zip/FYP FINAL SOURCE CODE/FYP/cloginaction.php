<?php
if(isset($_POST['signIn'])){
    require_once 'dataconnection.php';

    $email = mysqli_real_escape_string($connect,$_POST['email']);
    $password = mysqli_real_escape_string($connect,$_POST['password']);

    //recaptcha
    $secret ="6Lcfkl8mAAAAADYvd9vzdhNkkgUV7CqUmvLPK0Df";
	$response = $_POST['g-recaptcha-response'];
	$remoteip = $_SERVER['REMOTE_ADDR'];
	$URL = "https://www.google.com/recaptcha/api/siteverify?secret=$secret&response=$response&remoteip=$remoteip";
	$data = file_get_contents($URL);
	$Recaptcha = json_decode($data,true);

    if($Recaptcha['success'] == true){
        if(empty($email) || empty($password)){
            header("Location:./clogin.php?status=ALLemptyinput");
        }else{
            $vemail = filter_var($email,FILTER_VALIDATE_EMAIL);
            $vemailRegex = preg_match('/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/',$email);
            $vpassword = preg_match('/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^\w\s]).{12,}$/',$password);

            //all invalid
            if((!$vemail || !$vemailRegex) && !$vpassword){
                header("Location:./clogin.php?status=ALLinvalidformat");
                exit();
                }
            //invalid email
			else if((!$vemail || !$vemailRegex)){
				header("Location:./clogin.php?status=invalidemail");
                exit();
			}
			//invalid password
			else if(!$vpassword){
				header("Location:./clogin.php?status=invalidpassword");
				exit();
			}

            //all valid
            else if(($vemail && $vemailRegex) && $vpassword){
                $sql = "SELECT * FROM customer WHERE customer_email = ?";
                $stmt = mysqli_stmt_init($connect);
                if(!mysqli_stmt_prepare($stmt,$sql)){
                    header("Location:./clogin.php?status=sqlerror");
                    exit();
                }else{
                    mysqli_stmt_bind_param($stmt,"s",$email);
                    mysqli_stmt_execute($stmt);
                    $result = mysqli_stmt_get_result($stmt);
                    if($row = mysqli_fetch_assoc($result)){
                        $checkPass = password_verify($password,$row['customer_password']);
                        if($checkPass == true){
                            session_start();
                            $_SESSION['id'] = $row['customer_id'];
                            $_SESSION['name'] = $row['customer_name'];
                            $_SESSION['email'] = $row['customer_email'];
                            $_SESSION['vemail'] = $row['vemail'];
                            header("Location:./index.php");
                            exit();
                        }else if($checkPass == false){
                            header("Location:./clogin.php?status=wrongpassword");
                            exit();
                        }else{
                            header("Location:./clogin.php?status=wrongpassword");
                            exit();
                        }
                    }else{
                        //email not found
                        header("Location:./clogin.php?status=accountdoesnotexist");
                        exit();
                    }
                }
    //close statement
    mysqli_stmt_close($stmt);
    mysqli_close($connect);
   }
  }
 }else{//recaptcha else
		header("Location:./clogin.php?status=emptyrecaptcha");
		exit();
}
}

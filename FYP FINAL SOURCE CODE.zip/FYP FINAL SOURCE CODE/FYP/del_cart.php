<?php include("dataconnection.php"); 
	session_start();
    if(!isset($_SESSION['id']) || !isset($_SESSION['name']) || !isset($_SESSION['email']) || !isset($_SESSION['vemail'])){
        echo "<script>window.location.href='clogin.php';</script>";
     }else if(isset($_SESSION['id']) &&  isset($_SESSION['name']) && isset($_SESSION['email']) && isset($_SESSION['vemail'])){
           $vemail = $_SESSION['vemail'];
           if($vemail == false){
              echo "<script>window.location.href='sentOTP.php';</script>";
              exit();
           }
           // else{
           // 	header("Location:./index.php");
           // 	exit();
           // }
     }
    if(isset($_GET["del"]))
    {  $product_id=$_GET["id"];
       $customer_id=$_SESSION["id"];
       $selectcart_sql="SELECT * FROM cart WHERE customer_id=$customer_id";
       $run_selectcart_sql=mysqli_query($connect, $selectcart_sql);
       $rows_selectcart=mysqli_fetch_assoc($run_selectcart_sql);
       $cart_id=$rows_selectcart["cart_id"];
       $delcart_sql="DELETE FROM cart_item WHERE product_id='$product_id' AND cart_id=$cart_id";
       $run_delcart_sql=mysqli_query($connect, $delcart_sql);
       $selectcartitem_sql="SELECT * FROM cart_item WHERE cart_id=$cart_id";
       $run_selectcartitem_sql=mysqli_query($connect, $selectcartitem_sql);
       $num_rows=mysqli_num_rows($run_selectcartitem_sql);
       if($num_rows==0)
       {
        $deletecart_sql="DELETE FROM cart WHERE cart_id=$cart_id";
        $run_deletecart_sql=mysqli_query($connect, $deletecart_sql);
        if($run_deletecart_sql && $run_delcart_sql)
        {
            echo "<script>alert('One product deleted!')</script>";
        }
       }
       else
       {
        if($run_delcart_sql)
        {
            echo "<script>alert('One product deleted!')</script>";
        }
       }
       echo "<script>window.location.href='cart.php';</script>";
    }
?>
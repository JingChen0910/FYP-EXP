<?php
session_start();

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPmailer/src/Exception.php';
require 'PHPmailer/src/PHPMailer.php';
require 'PHPmailer/src/SMTP.php';
  if(isset($_POST['forget'])){
    require_once 'dataconnection.php';



    $email = mysqli_real_escape_string($connect,$_POST['email']);


    $secret ="6Lcfkl8mAAAAADYvd9vzdhNkkgUV7CqUmvLPK0Df";
	   $response = $_POST['g-recaptcha-response'];
	    $remoteip = $_SERVER['REMOTE_ADDR'];
	     $URL = "https://www.google.com/recaptcha/api/siteverify?secret=$secret&response=$response&remoteip=$remoteip";
	      $data = file_get_contents($URL);
	       $Recaptcha = json_decode($data,true);

         if($Recaptcha['success'] == true){
           //empty email
           if(empty($email)){
             header("Location:./forgetPass.php?status=emptyemail");
             exit();
           }else{
             $vemail = filter_var($email,FILTER_VALIDATE_EMAIL);
             $vemailRegex = preg_match('/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/',$email);
             //invalid email
             if(!$vemail || !$vemailRegex){
               header("Location:./forgetPass.php?status=invalidemail");
               exit();
             }
             //valid email
             else{
               $_SESSION["forgetPassEmail"];
               $sql = "SELECT * FROM customer WHERE customer_email = ?";
               $stmt = mysqli_stmt_init($connect);
               if(!mysqli_stmt_prepare($stmt,$sql)){
                 header("Location:./forgetPass.php?status=sqlerror");
                 exit();
               }else{
                 mysqli_stmt_bind_param($stmt, "s", $email);
                 mysqli_stmt_execute($stmt);
                 $result = mysqli_stmt_get_result($stmt);
                 if($row = mysqli_fetch_assoc($result)){
                       $Ownemail="knowledgemain1991@gmail.com";
                       $appPass="bsbddqyahqsshvdf";
                       $OTP= mt_rand(100000,999999);
                       $hashedOTP = password_hash($OTP,PASSWORD_DEFAULT);
                       $_SESSION["OTP"]= $hashedOTP;
                       $_SESSION["vExpiredTime"] = time() + 300;
                       $subject="Recovery Password -- Knowledge";
                       $body ='<div style="font-family: Helvetica,Arial,sans-serif;min-width:1000px;overflow:auto;line-height:2">
                       <div style="margin:50px auto;width:70%;padding:20px 0">
                         <div style="border-bottom:1px solid #eee">
                           <a href="" style="font-size:1.4em;color: #00466a;text-decoration:none;font-weight:600">Knowledge</a>
                         </div>
                         <p style="font-size:1.1em">Hi,</p>
                         <p>Thank you for choosing Knowledge. Use the following OTP to complete your Recovery Password procedures. OTP is valid for 5 minutes</p>
                         <h2 style="background: #00466a;margin: 0 auto;width: max-content;padding: 0 10px;color: #fff;border-radius: 4px;">'.$OTP.'</h2>
                         <p style="font-size:0.9em;">Regards,<br />Knowledge Sdn Bhd</p>
                         <hr style="border:none;border-top:1px solid #eee" />
                         <div style="float:right;padding:8px 0;color:#aaa;font-size:0.8em;line-height:1;font-weight:300">
                           <p>Knowledge Sdn Bhd, Jalan Ayer Keroh Lama,</p>
                           <p>75450, Bukit Beruang,</p>
                           <p>Melaka, Malaysia</p>
                         </div>
                       </div>
                       </div>
                       ';


                               $mail = new PHPMailer(true);

                               $mail -> isSMTP();
                               $mail -> Host = 'smtp.gmail.com';
                               $mail -> SMTPAuth = true;
                               $mail -> Username = $Ownemail; //Your email
                               $mail -> Password = $appPass; //Your email app password
                               $mail -> SMTPSecure = 'ssl';
                               $mail -> Port = 465;

                               $mail -> setFrom($Ownemail); //Your email

                               $mail -> addAddress($email); // customer email

                               $mail -> isHTML(true);

                               $mail -> Subject = $subject;
                               $mail -> Body = $body;

                               $mail -> send();

                               //OTP sent
                               echo
                               "
                               <script>
                               alert('Recovery Password OTP sent!');
                               document.location.href='recoveryOTPcheck.php';
                               </script>
                               ";
                 }else{
                  header("Location:./forgetPass.php?status=accountdoesnotexist");
                  exit();
                 }
               }


             }

           }
         }else{
           //empty recaptcha
           header("Location:./forgetPass.php?status=emptyrecaptcha&email=".$email);
           exit();
         }

  }




//generate random new password
//built in function used in this generate random new password
//str_shuffle() = The str_shuffle() function randomly shuffles all the characters of a string./ shuffle all the characters with randoms order
//The substr() function returns a part of a string.
//substr(string,start,length)
//example hello word with substr("Hello World",6,1) = "W"
//strlen() = total length of a string/ The strlen() function returns the length of a string.

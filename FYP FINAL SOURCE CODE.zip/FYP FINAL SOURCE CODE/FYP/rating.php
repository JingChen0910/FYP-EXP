<!DOCTYPE html>
    <?php include("dataconnection.php");
	session_start();
	if(!isset($_SESSION['id']) || !isset($_SESSION['name']) || !isset($_SESSION['email']) || !isset($_SESSION['vemail'])){
		echo "<script>window.location.href='clogin.php';</script>";
	 }else if(isset($_SESSION['id']) &&  isset($_SESSION['name']) && isset($_SESSION['email']) && isset($_SESSION['vemail'])){
		   $vemail = $_SESSION['vemail'];
		   if($vemail == false){
			  echo "<script>window.location.href='sentOTP.php';</script>";
			  exit();
		   }
		   // else{
		   // 	header("Location:./index.php");
		   // 	exit();
		   // }
	 }
	if(!isset($_GET["rate"]))
	{
		header("location: order_details.php");
	}
    if(isset($_GET["rate"]))
    {
        $prod_id=$_GET["id"];
        $order_id=$_GET["oid"];
		$filter_opt=$_GET["fo"];
		$filter_type=$_GET["ft"];
		$custom_date=$_GET["od"];
    }

    ?>
	<html lang="en">
	<head>
		<title>Book Store</title>
		<meta charset="utf-8">
	    <meta http-equiv="X-UA-Compatible" content="IE=edge">
	    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	    <meta name="format-detection" content="telephone=no">
	    <meta name="apple-mobile-web-app-capable" content="yes">
	    <meta name="author" content="">
	    <meta name="keywords" content="">
	    <meta name="description" content="">

	    <link rel="stylesheet" type="text/css" href="css/normalize.css">
	    <link rel="stylesheet" type="text/css" href="icomoon/icomoon.css">
	    <link rel="stylesheet" type="text/css" href="css/vendor.css">
	    <link rel="stylesheet" type="text/css" href="style.css">
		<!-- script
		================================================== -->
		<script src="http://translate.google.com/translate_a/element.js?cb=loadGoogleTranslate"></script>
		<script src="js/modernizr.js">
			function handle_keyup(event){
				if (event.keyCode === 13) {
                   document.getElementById('search_btn').click();
                }
			}
		</script>
		<script style="text/javascript">
            function validate_rate()
			{
				var r1=document.getElementById("star1"), r2=document.getElementById("star2"), r3=document.getElementById("star3"), r4=document.getElementById("star4"), r5=document.getElementById("star5");
                if(!r1.checked && !r2.checked && !r3.checked && !r4.checked && !r5.checked)
				{
					document.getElementById("error_rate").innerHTML="Please choose one of the above rating";
					document.getElementById("wrap-comments").style.left="-278px";
					document.getElementById("submitrating").style.left="230px";
					document.getElementById("submitrating").style.top="-100px";
					return false;
				}
			}
			function loadGoogleTranslate() {
    const defaultLanguage = "en";

    const translateElement = new google.translate.TranslateElement({
      pageLanguage: defaultLanguage,
      includedLanguages: "en,ms,zh-CN",
      layout: google.translate.TranslateElement.InlineLayout.SIMPLE
    }, "google_element");

    // Get the language select dropdown element
    const languageSelect = document.getElementById("languageSelect");

    // Function to set a cookie
    function setCookie(name, value, days) {
      const expires = new Date();
      expires.setTime(expires.getTime() + days * 24 * 60 * 60 * 1000);
      document.cookie = `${name}=${value};expires=${expires.toUTCString()};path=/`;
    }

    // Function to get a cookie value
    function getCookie(name) {
      const cookieName = `${name}=`;
      const cookies = document.cookie.split(';');
      for (let i = 0; i < cookies.length; i++) {
        let cookie = cookies[i];
        while (cookie.charAt(0) === ' ') {
          cookie = cookie.substring(1);
        }
        if (cookie.indexOf(cookieName) === 0) {
          return cookie.substring(cookieName.length, cookie.length);
        }
      }
      return null;
    }

    // Set the initial language selection
    const storedLanguage = getCookie("selectedLanguage");
    if (storedLanguage) {
      languageSelect.value = storedLanguage;
      translateElement.update({
        includedLanguages: storedLanguage
      });
    }

    // Add event listener for change event
    languageSelect.addEventListener("change", function() {
      const selectedLanguage = this.value;
      translateElement.update({
        includedLanguages: selectedLanguage
      });
      setCookie("selectedLanguage", selectedLanguage, 30); // Set the cookie for 30 days
    });
  }
		</script>
	</head>

<body>


<div id="header-wrap">

	<div class="top-content">
		<div class="container">
			<div class="row">
				<div class="col-md-6" style="width: 25%;">

				</div>
				<div class="col-md-6" style="width: 75%;">
					<div class="right-element">
						<?php
						if(isset($_SESSION["id"]))
						{   $cust_id=$_SESSION["id"];
							$cartsql="SELECT * FROM cart WHERE customer_id=$cust_id";
							$run_cartsql=mysqli_query($connect, $cartsql);
							$num_rows_cartsql=mysqli_num_rows($run_cartsql);
							$rows_cartsql=mysqli_fetch_assoc($run_cartsql);
							if($num_rows_cartsql==0)
							{
								$cartitem_rows=0;
							}
							else
							{   $cartid=$rows_cartsql["cart_id"];
								$cartitemsql="SELECT * FROM cart_item WHERE cart_id=$cartid";
							    $run_cartitemsql=mysqli_query($connect, $cartitemsql);
							    $cartitem_rows=mysqli_num_rows($run_cartitemsql);
								$del_val=0;
								while($rows_cartitemsql=mysqli_fetch_assoc($run_cartitemsql))
								{
                                  $prodid=$rows_cartitemsql["product_id"];
								  $itemqty=$rows_cartitemsql["item_quantity"];
								  $stocksql="SELECT * FROM stock WHERE product_id='$prodid'";
                                  $run_stocksql=mysqli_query($connect, $stocksql);
                                  $stockrows=mysqli_fetch_assoc($run_stocksql);
                                  $stocklevel=$stockrows['stock_level'];
								  $prodsql="SELECT * FROM product WHERE product_id='$prodid' AND availability=0";
                                  $run_prodsql=mysqli_query($connect, $prodsql);
                                  $prodrows=mysqli_num_rows($run_prodsql);
								  if($prodrows==0)
								  {
									$del_cartitem="DELETE FROM cart_item WHERE cart_id=$cartid AND product_id='$prodid'";
									$run_del_cartitem=mysqli_query($connect, $del_cartitem);
									if($run_del_cartitem)
                                      $del_val++;
								  }
								  else if($stocklevel==0)
								  {
									$del_cartitem="DELETE FROM cart_item WHERE cart_id=$cartid AND product_id='$prodid'";
									$run_del_cartitem=mysqli_query($connect, $del_cartitem);
									if($run_del_cartitem)
                                      $del_val++;
								  }
								  else if($itemqty>$stocklevel)
								  {
									$update_cartitem="UPDATE cart_item SET item_quantity=$stocklevel WHERE cart_id=$cartid AND product_id='$prodid'";
									$run_update_cartitem=mysqli_query($connect, $update_cartitem);
								  }
								}
								if($del_val==$cartitem_rows)
								{
									$del_cart="DELETE FROM cart WHERE cart_id=$cartid";
									$run_del_cart=mysqli_query($connect, $del_cart);
								}
								$cartitem_rows-=$del_val;
							}
							$select_cust="SELECT * FROM customer WHERE customer_id=$cust_id";
							$run_select_cust=mysqli_query($connect, $select_cust);
							$row_select_cust=mysqli_fetch_assoc($run_select_cust);
							$user_profile=$row_select_cust["customer_profile_picture"];
							?>
							<a href="cart.php" class="cart for-buy"><img src="images/icon/carts.png" style="width: 50px; height: 50px; opacity: 70%; margin-bottom: 5px;"><span>Cart: <?php echo $cartitem_rows; ?> item(s)</span></a>
							<a href="order_history.php?vo&fo=<?php echo $filter_opt; ?>&ft=<?php echo $filter_type; ?>&od=<?php echo $custom_date; ?>" class="cart for-buy"><i class="icon icon-clipboard"></i> <span>Order History</span></a>
						<nav id="navbar" style="display: inline-block; margin-left: -40px; position: relative; z-index: 3;">
						<div class="main-menu stellarnav">
						<ul class="menu-list">
						<li class="menu-item has-sub">
						<a href="./user_profile.php" class="nav-link" data-effect="Pages"><img src="images/cus_profile/<?php echo $user_profile; ?>" style="width: 40px; height: 40px; border-radius: 50%; margin-right: 10px;" alt="user_profile" title="user_profile">Account</a>
							<ul style="font-size: 16px;">
								<li><a href="./user_profile.php">My Profile</a></li>
								<li><a href="./logoutaction.php">Logout</a></li>
							 </ul>
						</li>
						</ul>
						</div>
						</nav>
						<?php
						}
						?>
						<div class="action-menu" style="margin-left: 10px;">

							<div class="search-bar">
								<a href="#" class="search-button search-toggle" data-selector="#header-wrap">
									<i class="icon icon-search"></i>
								</a>
								<form role="search" method="get" class="search-box" action="search_products.php">
									<input class="search-field text search-input" placeholder="Search products" type="text" name="search_keyword" onkeyup="handle_keyup(event)">
									<input type="submit" id="search_btn" style="display: none;">
								</form>
							</div>
						</div>
                        <div id="google_element" style="display: inline-block;"></div>
					</div><!--top-right-->
				</div>

			</div>
		</div>
	</div><!--top-content-->

	<header id="header" style="background-color: #f3e7be;">
		<div class="container">
			<div class="row">

			    <div class="col-md-2">
					<!--<div class="main-logo">-->
						<a href="index.php"><img src="images/icon/logo.png" alt="logo" style="height: 140px; margin:-60px 0px -30px 0px;"></a>
					<!--</div>-->
				</div>

				<div class="col-md-10">

					<nav id="navbar" style="position: relative; z-index: 1;">
						<div class="main-menu stellarnav">
							<ul class="menu-list">
								<li class="menu-item active"><a href="index.php" data-effect="Home">Home</a></li>
								<li class="menu-item"><a href="about_us.php" class="nav-link" data-effect="About">About</a></li>
								<!--<li class="menu-item has-sub">
									<a href="#pages" class="nav-link" data-effect="Pages">Pages</a>

									<ul>
								        <li><a href="styles.html">Styles</a></li>
								        <li><a href="blog.html">Blog</a></li>
								        <li><a href="single-post.html">Post Single</a></li>
								        <li><a href="thank-you.html">Thank You</a></li>
								     </ul>

								</li>-->
								<li class="menu-item"><a href="shop.php" class="nav-link" data-effect="Shop">Shop</a></li>
								<li class="menu-item"><a href="contact.php" class="nav-link" data-effect="Contact">Contact Us</a></li>
							</ul>

							<div class="hamburger">
				                <span class="bar"></span>
				                <span class="bar"></span>
				                <span class="bar"></span>
				            </div>

						</div>
					</nav>

				</div>

			</div>
		</div>
	</header>

</div><!--header-wrap-->

<div>
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div class="colored">
					<br>
					<div class="breadcum-items">
						<span class="item"><a href="index.php">Home</a> /</span>
                        <span class="item"><a href="order_history.php?vo&fo=<?php echo $filter_opt; ?>&ft=<?php echo $filter_type; ?>&od=<?php echo $custom_date; ?>">Order History</a> /</span>
						<span class="item colored"><a href="order_details.php?vo&oid=<?php echo $order_id; ?>&fo=<?php echo $filter_opt; ?>&ft=<?php echo $filter_type; ?>&od=<?php echo $custom_date; ?>">Order Details</a> /</span>
                        <span class="item colored">Product Rating</span>
					</div>
				</div>
			</div>
		</div>
	</div>
</div><!--site-banner-->

<div class="container">
<section class="padding-large">
	<?php $category_id=0; $num_page=1; $sort_opt=-1;
    $select_rate="SELECT * FROM rating WHERE order_id=$order_id AND product_id='$prod_id' AND customer_id=$cust_id";
    $runselect_rate=mysqli_query($connect, $select_rate);
    $row_rate=mysqli_num_rows($runselect_rate);
    $select_prod="SELECT * FROM product WHERE product_id='$prod_id' AND availability=0";
    $runselect_prod=mysqli_query($connect, $select_prod);
    $row_prod=mysqli_fetch_assoc($runselect_prod);
    $prod_name=$row_prod["product_name"];
    if($row_rate==0)
    {?>

    <form id="rate_form" name="rating_frm" style="margin-left: 20px; border: 1px solid #bbb9b9; width: 100%;" method="POST" action="insert_rating.php" onsubmit="return validate_rate()">
       <div class="container" style="width: 100%;">
	   <div name="wrap-rate" id="wrap-rate" style="margin-left: 50px; margin-top: 20px;">
       <p style="font-size: 20px;">You're rating: <span style="font-weight: bold;"><a href="single-product.php?view&id=<?php echo $prod_id; ?>&cat=<?php echo $category_id; ?>&num=<?php echo $num_page; ?>&sort_opt=<?php echo $sort_opt; ?>" style="text-decoration: none;"><?php echo $prod_name; ?></a></span></p>
       <div style="display: inline-block; margin-right: 30px; margin-bottom: 30px;">
			<a href="single-product.php?view&id=<?php echo $prod_id; ?>&cat=<?php echo $category_id; ?>&num=<?php echo $num_page; ?>&sort_opt=<?php echo $sort_opt; ?>" class="product-image"><img src="staff/product_image/<?php echo $row_prod['product_image']; ?>" style="height: 350px; width: 200px;"></a>
		</div>
		<div class="rating" style="display: inline-block; margin-top: 20px; border-top: 1px solid #bbb9b9; border-bottom: 1px solid #bbb9b9; position: absolute;">
		  <span style="margin-left: 80px;">
          <span style="font-size: 23px; margin-right: 60px;"><span style="color: #f1cf23;">&#9733; </span>&#9733; &#9733; &#9733; &#9733;</span>
          <span style="font-size: 23px; margin-right: 60px;"><span style="color: #f1cf23;">&#9733; &#9733; </span>&#9733; &#9733; &#9733;</span>
          <span style="font-size: 23px; margin-right: 60px;"><span style="color: #f1cf23;">&#9733; &#9733; &#9733; </span>&#9733; &#9733;</span>
          <span style="font-size: 23px; margin-right: 60px;"><span style="color: #f1cf23;">&#9733; &#9733; &#9733; &#9733; </span>&#9733;</span>
          <span style="font-size: 23px;"><span style="color: #f1cf23;">&#9733; &#9733; &#9733; &#9733; &#9733;</span></span>
		  </span><br>
		  <span style="font-weight: bold;">Rating<span style="color:red;">*</span></span>
		  <span style="margin-left: 25px;">
		  <input type="radio" id="star1" name="rating" value="1" style="margin-left: 60px;" />
		  <input type="radio" id="star2" name="rating" value="2" style="margin-left: 168px;" />
		  <input type="radio" id="star3" name="rating" value="3" style="margin-left: 168px;" />
		  <input type="radio" id="star4" name="rating" value="4" style="margin-left: 168px;" />
		  <input type="radio" id="star5" name="rating" value="5" style="margin-left: 168px;" />
	      </span>
       </div>
	   <span id="error_rate" style="position: relative; display: inline-block; top: -40px; color: red; height: 10px;"></span>
	   <input type="text" name="order_id" value="<?php echo $order_id; ?>" style="display: none;">
	   <input type="text" name="product_id" value="<?php echo $prod_id; ?>" style="display: none;">
	   <div id="wrap-comments" style="position: relative; display: inline-block; top: 120px;">
	   <label for="comments">Any Feedback?</label>
	   <textarea id="comments" name="comments" style="width: 650px; height: 80px;"></textarea>
	   </div>
	   <input type="submit" id="submitrating" name="submitrating" value="Submit Rating" style="position: relative; display: inline-block; top: 150px; right: 650px;">
      </div>
	 </div>
    </form>
	</div>
    <?php
    }
	else
	{   $rate_row=mysqli_fetch_assoc($runselect_rate);
		$rating=$rate_row["rating_rate"];
		$rating_id=$rate_row["rating_id"];
		$comments=$rate_row["comments"];
		$rating_date=$rate_row["rating_date"];
		$formatted_date = date('d/m/Y H:i:s', strtotime($rating_date));
		date_default_timezone_set('Asia/Kuala_Lumpur');
        $date=date('Y-m-d H:i:s');
		$valid_date=date('Y-m-d H:i:s', strtotime('+1 days', strtotime($rating_date)));
	?>
    <form id="rate_form" name="rating_frm" style="margin-left: 20px; border: 1px solid #bbb9b9; width: 100%;" method="POST" action="delete_rating.php">
	   <input type="text" name="rating_id" value="<?php echo $rating_id; ?>" style="display: none;">
       <div name="wrap-rate" id="wrap-rate" style="margin-left: 50px; margin-top: 20px;">
       <p style="font-size: 20px;">Rated product: <span style="font-weight: bold;"><a href="single-product.php?view&id=<?php echo $prod_id; ?>&cat=<?php echo $category_id; ?>&num=<?php echo $num_page; ?>&sort_opt=<?php echo $sort_opt; ?>" style="text-decoration: none;"><?php echo $prod_name; ?></a></span></p>
       <div style="display: inline-block; margin-right: 30px; margin-bottom: 30px;">
			<a href="single-product.php?view&id=<?php echo $prod_id; ?>&cat=<?php echo $category_id; ?>&num=<?php echo $num_page; ?>&sort_opt=<?php echo $sort_opt; ?>" class="product-image"><img src="staff/product_image/<?php echo $row_prod['product_image']; ?>" style="position: relative; margin-top: -30px; height: 350px;"></a>
		</div>
		<p style="display: inline-block; margin-right: 30px; font-size: 20px; position: absolute;">Rated date: <?php echo $formatted_date; ?></p>
		<div style="display: inline-block; position: relative; top: 30px;">
		Rating:
        <?php
		if($rating==1)
		{?><span style="font-size: 23px; margin-right: 60px;"><span style="color: #f1cf23;">&#9733; </span>&#9733; &#9733; &#9733; &#9733;</span><?php
		}
		else if($rating==2)
		{?><span style="font-size: 23px; margin-right: 60px;"><span style="color: #f1cf23;">&#9733; &#9733; </span>&#9733; &#9733; &#9733;</span><?php
		}
		else if($rating==3)
		{?><span style="font-size: 23px; margin-right: 60px;"><span style="color: #f1cf23;">&#9733; &#9733; &#9733; </span>&#9733; &#9733;</span><?php
		}
		else if($rating==4)
		{?><span style="font-size: 23px; margin-right: 60px;"><span style="color: #f1cf23;">&#9733; &#9733; &#9733; &#9733; </span>&#9733;</span><?php
		}
		else if($rating==5)
		{?><span style="font-size: 23px; margin-right: 60px;"><span style="color: #f1cf23;">&#9733; &#9733; &#9733; &#9733; &#9733;</span></span><?php
		}
		?>
	   <div id="container">
	   <?php
	   if($comments!="")
	   {?><label for="comments">Feedback</label>
	   <textarea id="comments" name="comments" style="width: 650px; height: 80px;" disabled><?php echo $comments; ?></textarea>
       <?php
	   }?>
	   </div>


	  <?php
	  if($date<=$valid_date)
	  {?><input type="submit" name="delrate" value="Delete Rating">
       <?php
	  }
	  else
	  {?><span style="color: red;">*The validation date of deleting this rating(one day after the rating date) had expired.</span><br>
       <?php
	  }
	  ?></div></div>
    </form>
    <?php
	}
    ?>
</section>
</div>


<footer id="footer" style="background-color: #f3e7be;">
	<div class="container">
		<div class="row">

			<div class="col-md-4" style="width: 40%;">

				<div class="footer-item">
					<div class="company-brand">
						<img src="images/icon/logo.png" alt="logo" class="footer-logo" style="height: 180px; width: 200px; margin-left: 70px;">
						<p>Welcome to Knowledge Bookstore, your gateway to a vast world of literary treasures, where words come alive and imagination knows no bounds.</p>
					</div>
				</div>

			</div>

			<div class="col-md-2" style="margin-top: 80px;">

				<div class="footer-menu">
					<h5><a href="about_us.php">About Us</a></h5>
					<ul class="menu-list">
						<li class="menu-item">
							Phone: 06 – 252 3253
						</li>
						<!--<li class="menu-item">
							<a href="#">articles </a>
						</li>
						<li class="menu-item">
							<a href="#">careers</a>
						</li>
						<li class="menu-item">
							<a href="#">service terms</a>
						</li>
						<li class="menu-item">
							<a href="#">donate</a>
						</li>-->
					</ul>
				</div>

			</div>
			<!--<div class="col-md-2">

				<div class="footer-menu">
					<h5>Discover</h5>
					<ul class="menu-list">
						<li class="menu-item">
							<a href="#">Home</a>
						</li>
						<li class="menu-item">
							<a href="#">Books</a>
						</li>
						<li class="menu-item">
							<a href="#">Authors</a>
						</li>
						<li class="menu-item">
							<a href="#">Subjects</a>
						</li>
						<li class="menu-item">
							<a href="#">Advanced Search</a>
						</li>
					</ul>
				</div>

			</div>-->
			<div class="col-md-2" style="padding-left: 30px; margin-top: 80px;">

				<div class="footer-menu">
					<h5>Quick Links</h5>
					<ul class="menu-list">
						<li class="menu-item">
							<a href="index.php">Home</a>
						</li>
						<li class="menu-item">
							<a href="shop.php">Shop</a>
						</li>
					</ul>
				</div>

			</div>
			<div class="col-md-2" style="padding-left: 100px; margin-top: 80px;">

				<div class="footer-menu">
					<h5>Services</h5>
					<ul class="menu-list">
						<!--<li class="menu-item">
							<a href="#">Help center</a>
						</li>
						<li class="menu-item">
							<a href="#">Report a problem</a>
						</li>
						<li class="menu-item">
							<a href="#">Suggesting edits</a>
						</li>-->
						<li class="menu-item">
							<a href="contact.php">Contact us</a>
						</li>
						<li class="menu-item">
							<a href="faq.php">FAQ</a>
						</li>
					</ul>
				</div>

			</div>

		</div>
		<!-- / row -->

	</div>
</footer>

<div id="footer-bottom">
	<div class="container">
		<div class="row">
			<div class="col-md-12">

				<div class="copyright">
					<div class="row">

						<div class="col-md-6">
							<p>© 2023 All rights reserved.</p>
						</div>

						<div class="col-md-6">

						</div>

					</div>
				</div><!--grid-->

			</div><!--footer-bottom-content-->
		</div>
	</div>
</div>

<script src="js/jquery-1.11.0.min.js"></script>
<script src="js/plugins.js"></script>
<script src="js/script.js"></script>

</body>
</html>

<?php include("dataconnection.php"); 
	session_start();
    if(!isset($_SESSION['id']) || !isset($_SESSION['name']) || !isset($_SESSION['email']) || !isset($_SESSION['vemail'])){
        echo "<script>window.location.href='clogin.php';</script>";
     }else if(isset($_SESSION['id']) &&  isset($_SESSION['name']) && isset($_SESSION['email']) && isset($_SESSION['vemail'])){
           $vemail = $_SESSION['vemail'];
           if($vemail == false){
              echo "<script>window.location.href='sentOTP.php';</script>";
              exit();
           }
           // else{
           // 	header("Location:./index.php");
           // 	exit();
           // }
     }
    $customer_id=$_SESSION["id"];
    $selectcart_sql="SELECT * FROM cart WHERE customer_id=$customer_id";
    $run_selectcart_sql=mysqli_query($connect, $selectcart_sql);
    $rows_selectcart=mysqli_fetch_assoc($run_selectcart_sql);
    $cart_id=$rows_selectcart["cart_id"];
    $selectcartitem_sql="SELECT * FROM cart_item WHERE cart_id=$cart_id";
    $run_selectcartitem_sql=mysqli_query($connect, $selectcartitem_sql);
    $num_rows=mysqli_num_rows($run_selectcartitem_sql);
    if(isset($_POST["update_qtybtn"]) || isset($_POST["update_qtybtn_all"]))
    {
        for($a=0; $a<$num_rows; $a++)
        {
            $product_id=$_POST["prodid_$a"];
            $qty=$_POST["quantity_$a"];
            $updateqty_sql="UPDATE cart_item SET item_quantity=$qty WHERE product_id='$product_id' AND cart_id=$cart_id";
            $run_updateqty_sql=mysqli_query($connect, $updateqty_sql);
        }
        if(isset($_POST["update_qtybtn_all"]))
        {
            header("Location: checkout.php"); exit();
        }
        else if(isset($_POST["update_qtybtn"]))
        {
            header("Location: cart.php"); exit();
        }
    }
?>
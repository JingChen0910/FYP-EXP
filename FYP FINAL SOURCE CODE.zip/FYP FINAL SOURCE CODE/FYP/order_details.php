<!DOCTYPE html>
    <?php include("dataconnection.php");
	session_start();
	if(!isset($_SESSION['id']) || !isset($_SESSION['name']) || !isset($_SESSION['email']) || !isset($_SESSION['vemail'])){
		echo "<script>window.location.href='clogin.php';</script>";
	 }else if(isset($_SESSION['id']) &&  isset($_SESSION['name']) && isset($_SESSION['email']) && isset($_SESSION['vemail'])){
		   $vemail = $_SESSION['vemail'];
		   if($vemail == false){
			  echo "<script>window.location.href='sentOTP.php';</script>";
			  exit();
		   }
		   // else{
		   // 	header("Location:./index.php");
		   // 	exit();
		   // }
	 }
	if(!isset($_GET["vo"]))
	{
		header("location: order_history.php");
	}
    if(isset($_GET["vo"]))
    {
        $order_id=$_GET["oid"];
		$filter_opt=$_GET["fo"];
		$filter_type=$_GET["ft"];
		$custom_date=$_GET["od"];
    }

    ?>
	<html lang="en">
	<head>
		<title>Book Store</title>
		<meta charset="utf-8">
	    <meta http-equiv="X-UA-Compatible" content="IE=edge">
	    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	    <meta name="format-detection" content="telephone=no">
	    <meta name="apple-mobile-web-app-capable" content="yes">
	    <meta name="author" content="">
	    <meta name="keywords" content="">
	    <meta name="description" content="">

	    <link rel="stylesheet" type="text/css" href="css/normalize.css">
	    <link rel="stylesheet" type="text/css" href="icomoon/icomoon.css">
	    <link rel="stylesheet" type="text/css" href="css/vendor.css">
	    <link rel="stylesheet" type="text/css" href="style.css">
		<!-- script
		================================================== -->
		<script src="http://translate.google.com/translate_a/element.js?cb=loadGoogleTranslate"></script>
		<script src="js/modernizr.js">
			function handle_keyup(event){
				if (event.keyCode === 13) {
                   document.getElementById('search_btn').click();
                }
			}
		</script>
		<script style="text/javascript">
			function confirm_cancel()
			{
				var result=confirm("Are you confirm to cancel the order?");
				if(!result)
				{
					return false;
				}
			}

			function loadGoogleTranslate() {
    const defaultLanguage = "en";

    const translateElement = new google.translate.TranslateElement({
      pageLanguage: defaultLanguage,
      includedLanguages: "en,ms,zh-CN",
      layout: google.translate.TranslateElement.InlineLayout.SIMPLE
    }, "google_element");

    // Get the language select dropdown element
    const languageSelect = document.getElementById("languageSelect");

    // Function to set a cookie
    function setCookie(name, value, days) {
      const expires = new Date();
      expires.setTime(expires.getTime() + days * 24 * 60 * 60 * 1000);
      document.cookie = `${name}=${value};expires=${expires.toUTCString()};path=/`;
    }

    // Function to get a cookie value
    function getCookie(name) {
      const cookieName = `${name}=`;
      const cookies = document.cookie.split(';');
      for (let i = 0; i < cookies.length; i++) {
        let cookie = cookies[i];
        while (cookie.charAt(0) === ' ') {
          cookie = cookie.substring(1);
        }
        if (cookie.indexOf(cookieName) === 0) {
          return cookie.substring(cookieName.length, cookie.length);
        }
      }
      return null;
    }

    // Set the initial language selection
    const storedLanguage = getCookie("selectedLanguage");
    if (storedLanguage) {
      languageSelect.value = storedLanguage;
      translateElement.update({
        includedLanguages: storedLanguage
      });
    }

    // Add event listener for change event
    languageSelect.addEventListener("change", function() {
      const selectedLanguage = this.value;
      translateElement.update({
        includedLanguages: selectedLanguage
      });
      setCookie("selectedLanguage", selectedLanguage, 30); // Set the cookie for 30 days
    });
  }
		</script>
	</head>

<body>


<div id="header-wrap">

	<div class="top-content">
		<div class="container">
			<div class="row">
				<div class="col-md-6" style="width: 25%;">

				</div>
				<div class="col-md-6" style="width: 75%;">
					<div class="right-element">
						<?php
						if(isset($_SESSION["id"]))
						{   $cust_id=$_SESSION["id"];
							$cartsql="SELECT * FROM cart WHERE customer_id=$cust_id";
							$run_cartsql=mysqli_query($connect, $cartsql);
							$num_rows_cartsql=mysqli_num_rows($run_cartsql);
							$rows_cartsql=mysqli_fetch_assoc($run_cartsql);
							if($num_rows_cartsql==0)
							{
								$cartitem_rows=0;
							}
							else
							{   $cartid=$rows_cartsql["cart_id"];
								$cartitemsql="SELECT * FROM cart_item WHERE cart_id=$cartid";
							    $run_cartitemsql=mysqli_query($connect, $cartitemsql);
							    $cartitem_rows=mysqli_num_rows($run_cartitemsql);
								$del_val=0;
								while($rows_cartitemsql=mysqli_fetch_assoc($run_cartitemsql))
								{
                                  $prodid=$rows_cartitemsql["product_id"];
								  $itemqty=$rows_cartitemsql["item_quantity"];
								  $stocksql="SELECT * FROM stock WHERE product_id='$prodid'";
                                  $run_stocksql=mysqli_query($connect, $stocksql);
                                  $stockrows=mysqli_fetch_assoc($run_stocksql);
                                  $stocklevel=$stockrows['stock_level'];
								  $prodsql="SELECT * FROM product WHERE product_id='$prodid' AND availability=0";
                                  $run_prodsql=mysqli_query($connect, $prodsql);
                                  $prodrows=mysqli_num_rows($run_prodsql);
								  if($prodrows==0)
								  {
									$del_cartitem="DELETE FROM cart_item WHERE cart_id=$cartid AND product_id='$prodid'";
									$run_del_cartitem=mysqli_query($connect, $del_cartitem);
									if($run_del_cartitem)
                                      $del_val++;
								  }
								  else if($stocklevel==0)
								  {
									$del_cartitem="DELETE FROM cart_item WHERE cart_id=$cartid AND product_id='$prodid'";
									$run_del_cartitem=mysqli_query($connect, $del_cartitem);
									if($run_del_cartitem)
                                      $del_val++;
								  }
								  else if($itemqty>$stocklevel)
								  {
									$update_cartitem="UPDATE cart_item SET item_quantity=$stocklevel WHERE cart_id=$cartid AND product_id='$prodid'";
									$run_update_cartitem=mysqli_query($connect, $update_cartitem);
								  }
								}
								if($del_val==$cartitem_rows)
								{
									$del_cart="DELETE FROM cart WHERE cart_id=$cartid";
									$run_del_cart=mysqli_query($connect, $del_cart);
								}
								$cartitem_rows-=$del_val;
							}
							$select_cust="SELECT * FROM customer WHERE customer_id=$cust_id";
							$run_select_cust=mysqli_query($connect, $select_cust);
							$row_select_cust=mysqli_fetch_assoc($run_select_cust);
							$user_profile=$row_select_cust["customer_profile_picture"];
							?>
							<a href="cart.php" class="cart for-buy"><img src="images/icon/carts.png" style="width: 50px; height: 50px; opacity: 70%; margin-bottom: 5px;"><span>Cart: <?php echo $cartitem_rows; ?> item(s)</span></a>
							<a href="order_history.php?vo&fo=<?php echo $filter_opt; ?>&ft=<?php echo $filter_type; ?>&od=<?php echo $custom_date; ?>" class="cart for-buy"><i class="icon icon-clipboard"></i> <span>Order History</span></a>
						<nav id="navbar" style="display: inline-block; margin-left: -40px; position: relative; z-index: 3;">
						<div class="main-menu stellarnav">
						<ul class="menu-list">
						<li class="menu-item has-sub">
						<a href="./user_profile.php" class="nav-link" data-effect="Pages"><img src="images/cus_profile/<?php echo $user_profile; ?>" style="width: 40px; height: 40px; border-radius: 50%; margin-right: 10px;" alt="user_profile" title="user_profile">Account</a>
							<ul style="font-size: 16px;">
								<li><a href="./user_profile.php">My Profile</a></li>
								<li><a href="./logoutaction.php">Logout</a></li>
							 </ul>
						</li>
						</ul>
						</div>
						</nav>
                        <?php
						}
						?>
						<div class="action-menu" style="margin-left: 10px;">

							<div class="search-bar">
								<a href="#" class="search-button search-toggle" data-selector="#header-wrap">
									<i class="icon icon-search"></i>
								</a>
								<form role="search" method="get" class="search-box" action="search_products.php">
									<input class="search-field text search-input" placeholder="Search products" type="text" name="search_keyword" onkeyup="handle_keyup(event)">
									<input type="submit" id="search_btn" style="display: none;">
								</form>
							</div>
						</div>
                        <div id="google_element" style="display: inline-block;"></div>
					</div><!--top-right-->
				</div>

			</div>
		</div>
	</div><!--top-content-->

	<header id="header" style="background-color: #f3e7be;">
		<div class="container">
			<div class="row">

			    <div class="col-md-2">
					<!--<div class="main-logo">-->
						<a href="index.php"><img src="images/icon/logo.png" alt="logo" style="height: 140px; margin:-60px 0px -30px 0px;"></a>
					<!--</div>-->
				</div>

				<div class="col-md-10">

					<nav id="navbar" style="position: relative; z-index: 1;">
						<div class="main-menu stellarnav">
							<ul class="menu-list">
								<li class="menu-item active"><a href="index.php" data-effect="Home">Home</a></li>
								<li class="menu-item"><a href="about_us.php" class="nav-link" data-effect="About">About</a></li>
								<!--<li class="menu-item has-sub">
									<a href="#pages" class="nav-link" data-effect="Pages">Pages</a>

									<ul>
								        <li><a href="styles.html">Styles</a></li>
								        <li><a href="blog.html">Blog</a></li>
								        <li><a href="single-post.html">Post Single</a></li>
								        <li><a href="thank-you.html">Thank You</a></li>
								     </ul>

								</li>-->
								<li class="menu-item"><a href="shop.php" class="nav-link" data-effect="Shop">Shop</a></li>
								<li class="menu-item"><a href="contact.php" class="nav-link" data-effect="Contact">Contact Us</a></li>
							</ul>

							<div class="hamburger">
				                <span class="bar"></span>
				                <span class="bar"></span>
				                <span class="bar"></span>
				            </div>

						</div>
					</nav>

				</div>

			</div>
		</div>
	</header>

</div><!--header-wrap-->

<div>
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div class="colored">
					<br>
					<div class="breadcum-items">
						<span class="item"><a href="index.php">Home</a> /</span>
                        <span class="item"><a href="order_history.php?vo&fo=<?php echo $filter_opt; ?>&ft=<?php echo $filter_type; ?>&od=<?php echo $custom_date; ?>">Order History</a> /</span>
						<span class="item colored">Order Details</span>
					</div>
				</div>
			</div>
		</div>
	</div>
</div><!--site-banner-->

<section class="padding-large">
	<div class="container" style="background-color: white; margin: auto;">
      <div style="height: 40px; width: 103%; background-color: #f1daa0; font-weight: bold; font-size: 20px; margin-left: -20px;"><span style="margin-left: 20px; color: #866e37;">Order Details</span></div>
	  <div>
		<?php
		$select_cust="SELECT customer_name FROM customer WHERE customer_id=$cust_id";
		$run_select_cust=mysqli_query($connect, $select_cust);
		$cust_row=mysqli_fetch_assoc($run_select_cust);
		$cust_name=$cust_row["customer_name"];
		$select_orders="SELECT * FROM orders WHERE order_id=$order_id";
		$run_select_orders=mysqli_query($connect, $select_orders);
		$row_orders=mysqli_fetch_assoc($run_select_orders);
		$status=$row_orders["order_status"];
		if($status=="Cancelled")
		{
			$select_payment="SELECT * FROM payment WHERE order_id=$order_id";
		    $run_select_payment=mysqli_query($connect, $select_payment);
		    $row_payment=mysqli_fetch_assoc($run_select_payment);
		    $payment_status=$row_payment["payment_status"];
			$payment_refundDate=$row_payment["refund_date"];
		    $formatted_payrefundDate=date('d/m/Y H:i:s', strtotime($payment_refundDate));
		}
		else
		{
			$payment_status="Successful";
		}
		$order_date=$row_orders["order_date"];
		$formatted_date = date('d/m/Y H:i:s', strtotime($order_date));
		$rname=$row_orders["recipient_name"];
		$remail=$row_orders["recipient_email"];
		$rhp=$row_orders["recipient_phoneNumber"];
		$address1=$row_orders["delivery_address1"];
		$address2=$row_orders["delivery_address2"];
		$city=$row_orders["delivery_city"];
		$postcode=$row_orders["delivery_postalCode"];
		$state=$row_orders["delivery_state"];
		$estimated_arriveDate=$row_orders["estimated_arriveDate"];
		$formatted_arriveDate=date('d/m/Y', strtotime($estimated_arriveDate));
		$shipping_fee=$row_orders["shipping_fee"];
		$overall_total=$row_orders["overall_total"];
		$select_orderitems="SELECT * FROM order_details WHERE order_id=$order_id";
		$run_select_orderitems=mysqli_query($connect, $select_orderitems);
		$num_orderitems=mysqli_num_rows($run_select_orderitems);
		?>
		<span style="font-size: 22px; font-weight: bold; margin-left: 30px;">Order ID: <?php echo $order_id; ?><span style="margin-left: 800px;">Order Status: <?php echo $status; ?></span></span><br>
		<?php
		if($status=="Cancelled")
		{?><span style="font-size: 22px; font-weight: bold; margin-left: 920px;">Payment Status: <?php echo $payment_status; ?></span><br>
         <?php
		}?>
		<span style="font-size: 18px; margin-left: 30px; opacity: 70%;">You have <?php echo $num_orderitems; ?> item(s) in this order
        <span style="margin-left: 670px;">Ordered/ Paid on <?php echo $formatted_date; ?></span></span><br>
		<?php
		if($status=="Cancelled")
		{ $cancel_refunddate=$row_orders["cancellation_date"];
		  $formatted_cancel_refunddate=date('d/m/Y H:i:s', strtotime($cancel_refunddate));
		 ?><span style="font-size: 18px; margin-left: 790px; opacity: 70%;">Order Cancelled/ Refund Approved on <?php echo $formatted_cancel_refunddate; ?></span>
         <?php
		}?></span>
		<?php
		/*if($payment_status=="refunded")
		{
		 ?><span style="font-size: 18px; margin-left: 930px; opacity: 70%;">Payment Refunded on <?php echo $formatted_payrefundDate; ?></span>
         <?php
		}?></span>*/
		if($payment_status=="Refund Approved")
		{
		 ?><span style="font-size: 18px; margin-left: 890px; opacity: 70%;">Refunding process may take 3 to 7 working days</span>
         <?php
		}?></span>
		<?php
		if($status!="Delivered" && $status!="Cancelled")
		{?><span style="font-size: 18px; margin-left: 960px; opacity: 70%;">Estimated Arrive Date: <?php echo $formatted_arriveDate; ?></span>
         <?php
		}?></span><br><br>
		<span style="font-size: 22px; margin-left: 30px; font-weight: bold;">Recipient's Information</span><br>
	    <span style="font-size: 18px; margin-left: 30px;"><span style="font-weight: bold;">Name: </span><?php echo $rname; ?></span><br>
		<span style="font-size: 18px; margin-left: 30px;"><span style="font-weight: bold;">Email: </span><?php echo $remail; ?></span><br>
		<span style="font-size: 18px; margin-left: 30px;"><span style="font-weight: bold;">Phone Number: </span><?php echo $rhp; ?></span><br>
		<span style="font-size: 18px; margin-left: 30px; font-weight: bold;">Address: </span><br>
		<span style="font-size: 18px; margin-left: 30px;"><?php echo $address1; ?></span>
		<?php
		if(!empty(trim($address2)))
		{
		  echo "<br><span style='font-size: 20px; margin-left: 30px;'>$address2</span>";
		}?>
		<br><span style="font-size: 20px; margin-left: 30px;"><?php echo $postcode; ?>, <?php echo $city; ?></span><br><span style="font-size: 20px; margin-left: 30px;"><?php echo $state; ?></span>
		<table width="1000px;" style="margin: auto; margin-left: 150px; margin-top: 50px; border-collapse: collapse;">
         <tr class="thead" style="background-color: #dbd9d9;">
           <th style="width:600px; font-size: 20px; border-bottom: 1px solid grey; text-align: center;">Product</th>
		   <th style="width:200px; font-size: 20px; border-bottom: 1px solid grey; text-align: center;">Price(RM)</th>
           <th style="width:100px; font-size: 20px; border-bottom: 1px solid grey; text-align: center;">Quantity</th>
           <th style="width:300px; font-size: 20px; border-bottom: 1px solid grey; text-align: center;">Subtotal(RM)</th>
		   <?php
		   if($status=="Delivered")
		   {?><th style="width:250px; font-size: 20px; border-bottom: 1px solid grey;"></th>
		   <?php
		   }?>
         </tr>
		<?php
		while($row_orderitems=mysqli_fetch_assoc($run_select_orderitems))
		{
			$prod_id=$row_orderitems["product_id"];
			$item_quantity=$row_orderitems["quantity"];
			$prodinfo="SELECT * FROM product WHERE product_id='$prod_id'";
			$run_prodinfo=mysqli_query($connect, $prodinfo);
			$rows_prodinfo=mysqli_fetch_assoc($run_prodinfo);
			$prod_name=$rows_prodinfo["product_name"];
			$prod_img=$rows_prodinfo["product_image"];
			$del_code=$rows_prodinfo["availability"];
			$price=$row_orderitems["price"];
			$quantity=$row_orderitems["quantity"];
			$subtotal=$row_orderitems["total_price"];
		?>
		<tr style="background-color: white;">
		   <?php $category_id=0; $num_page=1; $sort_opt=-1;
		   if($del_code==0)
		   {?><td style="border-bottom: 1px solid grey;"><div style="margin-left: 120px;"><a href="single-product.php?view&id=<?php echo $prod_id; ?>&cat=<?php echo $category_id; ?>&num=<?php echo $num_page; ?>&sort_opt=<?php echo $sort_opt; ?>"><?php echo $prod_name; ?></a><br><a href="single-product.php?view&id=<?php echo $prod_id; ?>&cat=<?php echo $category_id; ?>&num=<?php echo $num_page; ?>&sort_opt=<?php echo $sort_opt; ?>"><img src="staff/product_image/<?php echo $prod_img; ?>" style="width:100px; height:150px; position: relative; margin-bottom: 20px"></a></div></td>
           <?php
		   }
		   else
		   {?><td style="border-bottom: 1px solid grey;"><div style="margin-left: 120px;"><?php echo $prod_name; ?><br><img src="staff/product_image/<?php echo $prod_img; ?>" style="width:100px; height:150px; position: relative; margin-bottom: 20px"><br><span style="margin-left: -80px; color: red;">*This product is no longer available</span></div></td>
           <?php
		   }
		   ?>
           <td style="border-bottom: 1px solid grey; text-align: center;"><?php echo number_format($price, 2); ?></td>
		   <td style="border-bottom: 1px solid grey; text-align: center;"><?php echo $quantity; ?></td>
		   <td style="border-bottom: 1px solid grey; text-align: center;"><?php echo number_format($subtotal, 2); ?></td>
		   <?php
		   if($status=="Delivered" && $del_code==0)
		   { $select_rating="SELECT * FROM rating WHERE order_id=$order_id AND product_id='$prod_id' AND customer_id=$cust_id";
			 $run_select_rating=mysqli_query($connect, $select_rating);
			 $num_rating=mysqli_num_rows($run_select_rating);
			 if($num_rating==0)
			 {?><td style="border-bottom: 1px solid grey;"><a href="rating.php?rate&id=<?php echo $prod_id; ?>&oid=<?php echo $order_id; ?>&fo=<?php echo $filter_opt; ?>&ft=<?php echo $filter_type; ?>&od=<?php echo $custom_date; ?>"><button style="margin-right: 15px;">Rate product</button></a></td>
				<?php
			 }
		    else
			{?><td style="border-bottom: 1px solid grey; text-align: center; font-size: 20px;"><a href="rating.php?rate&id=<?php echo $prod_id; ?>&oid=<?php echo $order_id; ?>&fo=<?php echo $filter_opt; ?>&ft=<?php echo $filter_type; ?>&od=<?php echo $custom_date; ?>" style="text-decoration: none;">Rating Details</a></td>
			<?php
			}
		   }
		   else if($status=="Delivered" && $del_code==1)
		   {
			?><td style="border-bottom: 1px solid grey; text-align: center; font-size: 20px; width: 420px;"></td>
			<?php
		   }
		   ?>
		</tr>
		<?php
		}
		?>
		<tr>
		   <td style="text-align: center;">Shipping Fee(RM):</td>
		   <td style="text-align: center;"></td>
		   <td style="text-align: center;"></td>
		   <td style="text-align: center;"><?php echo number_format($shipping_fee, 2);
		   if($state!="Sarawak" && $state!="Sabah")
		    echo " (6%)";
		   else
		     echo " (9%)";
		   ?>
		   </td>
           <?php
		   if($status=="Delivered")
		   {?><td style="text-align: center;"></td>
		   <?php
		   }?>
		</tr>
		<tr>
		   <td style="text-align: center; font-size: 20px; font-weight: bold;">Total(RM):</td>
		   <td style="text-align: center;"></td>
		   <td style="text-align: center;"></td>
		   <td style="text-align: center; font-size: 20px; font-weight: bold;"><?php echo number_format($overall_total, 2); ?></td>
           <?php
		   if($status=="Delivered")
		   {?><td style="text-align: center;"></td>
		   <?php
		   }?>
		</tr>
		</table>
		<?php
		if($status=="Processing")
		{?> <form id="cancelorder" name="cancel_orderfrm" method="POST" onsubmit="return confirm_cancel()" action="cancel_order.php">
			  <input type="text" name="corder_id" value="<?php echo $order_id; ?>" style="display: none;">
			  <input type="submit" name="cancel_orderbtn" value="Cancel Order" style="margin-left: 70px; margin-top: 50px;">
		    </form>
			<?php
		}
		?>
		<br><br>
	 </div>
	</div>
</section>


<footer id="footer" style="background-color: #f3e7be;">
	<div class="container">
		<div class="row">

			<div class="col-md-4" style="width: 40%;">

				<div class="footer-item">
					<div class="company-brand">
						<img src="images/icon/logo.png" alt="logo" class="footer-logo" style="height: 180px; width: 200px; margin-left: 70px;">
						<p>Welcome to Knowledge Bookstore, your gateway to a vast world of literary treasures, where words come alive and imagination knows no bounds.</p>
					</div>
				</div>

			</div>

			<div class="col-md-2" style="margin-top: 80px;">

				<div class="footer-menu">
					<h5><a href="about_us.php">About Us</a></h5>
					<ul class="menu-list">
						<li class="menu-item">
							Phone: 06 – 252 3253
						</li>
						<!--<li class="menu-item">
							<a href="#">articles </a>
						</li>
						<li class="menu-item">
							<a href="#">careers</a>
						</li>
						<li class="menu-item">
							<a href="#">service terms</a>
						</li>
						<li class="menu-item">
							<a href="#">donate</a>
						</li>-->
					</ul>
				</div>

			</div>
			<!--<div class="col-md-2">

				<div class="footer-menu">
					<h5>Discover</h5>
					<ul class="menu-list">
						<li class="menu-item">
							<a href="#">Home</a>
						</li>
						<li class="menu-item">
							<a href="#">Books</a>
						</li>
						<li class="menu-item">
							<a href="#">Authors</a>
						</li>
						<li class="menu-item">
							<a href="#">Subjects</a>
						</li>
						<li class="menu-item">
							<a href="#">Advanced Search</a>
						</li>
					</ul>
				</div>

			</div>-->
			<div class="col-md-2" style="padding-left: 30px; margin-top: 80px;">

				<div class="footer-menu">
					<h5>Quick Links</h5>
					<ul class="menu-list">
						<li class="menu-item">
							<a href="index.php">Home</a>
						</li>
						<li class="menu-item">
							<a href="shop.php">Shop</a>
						</li>
					</ul>
				</div>

			</div>
			<div class="col-md-2" style="padding-left: 100px; margin-top: 80px;">

				<div class="footer-menu">
					<h5>Services</h5>
					<ul class="menu-list">
						<!--<li class="menu-item">
							<a href="#">Help center</a>
						</li>
						<li class="menu-item">
							<a href="#">Report a problem</a>
						</li>
						<li class="menu-item">
							<a href="#">Suggesting edits</a>
						</li>-->
						<li class="menu-item">
							<a href="contact.php">Contact us</a>
						</li>
						<li class="menu-item">
							<a href="faq.php">FAQ</a>
						</li>
					</ul>
				</div>

			</div>

		</div>
		<!-- / row -->

	</div>
</footer>

<div id="footer-bottom">
	<div class="container">
		<div class="row">
			<div class="col-md-12">

				<div class="copyright">
					<div class="row">

						<div class="col-md-6">
							<p>© 2023 All rights reserved.</p>
						</div>

						<div class="col-md-6">

						</div>

					</div>
				</div><!--grid-->

			</div><!--footer-bottom-content-->
		</div>
	</div>
</div>

<script src="js/jquery-1.11.0.min.js"></script>
<script src="js/plugins.js"></script>
<script src="js/script.js"></script>

</body>
</html>

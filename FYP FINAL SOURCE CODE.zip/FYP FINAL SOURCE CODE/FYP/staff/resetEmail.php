<?php
session_start();

if(!isset($_SESSION['Staffid']) || !isset($_SESSION['Staffname']) || !isset($_SESSION['Staffemail'])){
 echo '
 <script>
 alert("Please sign in your account!");
 window.location.href="../master/login.php";
 </script>
 ';
}else{
 require_once 'dataconnection.php';

}

?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Reset Email</title>
      <link rel="stylesheet" href="formstyle.css">
  </head>
  <body>
    <form action="./resetEmailAct.php" method="post" style="border:1px solid #ccc">
  <div class="container">
    <h1>Reset Email</h1>
    <p>Please fill in this form to reset email.</p>
    <?php
      if(!isset($_GET['status'])){

      }else if(isset($_GET['status'])){
        $s = $_GET['status'];
        //all empty input
        if($s == "emptyinput"){
          echo '<h1 style="color:red;">Please enter all inputs! &#128581;&#8205;&#9794;&#65039;</h1>';
        }

        //all invalid input
        else if($s == "allinvalid"){
            echo '<h1 style="color:red;">Please enter all inputs in the correct format! &#128581;&#8205;&#9794;&#65039;</h1>';
        }

        //invalid new email
        else if($s == "invalidnewemail"){
            echo '<h1 style="color:red;">Invalid new email! &#128581;&#8205;&#9794;&#65039;</h1>';
        }

        //invalid new password
        else if($s == "invalidpassword"){
              echo '<h1 style="color:red;">Invalid password! &#128581;&#8205;&#9794;&#65039;</h1>';
        }

        //email taken
        else if($s == "emailtaken"){
            echo '<h1 style="color:red;">The email address has been taken! &#128581;&#8205;&#9794;&#65039;</h1>';
        }

        //sql error
        else if($s == "sqlerror"){
           echo '<h1 style="color:red;">Sorry, reset email got trouble. &#128581;&#8205;&#9794;&#65039;</h1>';
        }

        //wrong password
        else if($s == "wrongpassword"){
             echo '<h1 style="color:red;">Wrong password. &#128581;&#8205;&#9794;&#65039;</h1>';
        }
      }
    ?>
    <hr>

    <label for="email"><b>New Email</b></label>
    <?php
    if(isset($_GET['email'])){
    $mail = $_GET['email'];
    echo '  <input type="email" placeholder="Enter New Email" name="email" id="email" required value="'.$mail.'">';
  }else{
    echo'<input type="email" placeholder="Enter New Email" name="email" id="email"required>';
  }

    ?>


    <label for="psw"><b>Password</b></label>
    <input type="password" placeholder="Enter Password" name="pass" id="psw" required>

    <label for="show">
      <input type="checkbox" onclick="showPassword()" name="show" id="show" style="margin-bottom:15px">Show password
    </label>



    <div class="clearfix">
        <button type="submit" class="signupbtn" name="resetEmail">Reset Email</button>
      <button type="button" class="cancelbtn" onclick="user_profile()">Cancel</button>

    </div>
  </div>
</form>
<script type="text/javascript">
  function showPassword() {
    var show = document.getElementById("psw");
    if (show.type == "password") {
      show.type = "text";
    } else if(show.type == "text"){
      show.type = "password";
    }
  }

  function user_profile(){
    window.location.href="./user_profile.php";
  }

</script>
  </body>
</html>

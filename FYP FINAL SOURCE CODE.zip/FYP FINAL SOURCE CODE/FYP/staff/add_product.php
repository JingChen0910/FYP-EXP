<?php
session_start();
 if(!isset($_SESSION['Staffid']) || !isset($_SESSION['Staffname']) || !isset($_SESSION['Staffemail'])){
	echo '
	<script>
	alert("Please sign in your account!");
	window.location.href="../master/login.php";
	</script>
	';
 }else{
	include("dataconnection.php");
 }



if(isset($_POST["addproduct"])) {
    $p_id = $_POST["product_id"];
    $p_name = $_POST["product_name"];
    $p_price = $_POST["product_price"];
    $discount = $_POST["discount"];
    $p_description = $_POST["product_description"];
    $productImage = $_FILES["file"];
    $productFileName = $_FILES["file"]["name"];
    $productFileTmpName = $_FILES["file"]["tmp_name"];
    $productFileSize = $_FILES["file"]["size"];
    $productFileError = $_FILES["file"]["error"];
    $productFileType = $_FILES["file"]["type"];
    $productFileExtension = explode('.',$productFileName);
    $productFileActualExtension = strtolower(end($productFileExtension));
    $productFileExtensionAllowed = array("jpg","jpeg","png");
    $pbs_date = $_POST["publisher_date"];
    $a_code = $_POST["availability"];
    $cat_id = $_POST["category_id"];
    $pbs_id = $_POST["publisher_id"];
    $a_id = $_POST["author_id"];
    $stock = $_POST["stock_level"];
    // Calculate the discounted price
    $p_disprice = $p_price - ($p_price * ($discount / 100));

    $query = "SELECT * FROM product WHERE product_id = '$p_id'";
    $result = mysqli_query($connect, $query);

	$Authorquery = "SELECT * FROM product WHERE product_name = '$p_name' AND author_id = '$a_id'";
    $Authoresult = mysqli_query($connect, $Authorquery);

	if(mysqli_num_rows($result) > 0) {
		echo "<script>alert('Product ID already exists.');
		        document.location.href='add_product.php';</script>";
	}
	else if(mysqli_num_rows($Authoresult) > 0) {
		echo"<script>alert('Product name already exists. try other author name.');
		document.location.href='add_product.php';</script>";
	} else {
		if(in_array($productFileActualExtension,$productFileExtensionAllowed)){
			if($productFileError === 0){
		/*1mb*/if($productFileSize <= 1000000){
			$productNewFileName = "product".$p_id.".".$productFileActualExtension;
			$productFileDestination = "product_image/".$productNewFileName;
			move_uploaded_file($productFileTmpName,$productFileDestination);

			mysqli_query($connect,"INSERT INTO product(product_id, product_name, product_price, discount, discount_price, product_description, product_image, publisher_date, availability, category_id, publisher_id, author_id)
			VALUES('$p_id', '$p_name', '$p_price', '$discount', '$p_disprice', '$p_description', '$productNewFileName', '$pbs_date', '$a_code', '$cat_id', '$pbs_id', '$a_id')");
			/*$p_image*/

			mysqli_query($connect, "INSERT INTO stock(product_id, stock_level) VALUES ('$p_id', '$stock')");

			echo "<script>alert('$p_name saved');</script>";
			header("refresh:0.5; url=manage_product.php");
				}else{
					echo "<script>alert('The size of the product image uploaded cannot be more than 1mb!');
					        document.location.href='add_product.php';</script>";
				}
			}else{
				echo "<script>alert('Product image upload error!');
				        document.location.href='add_product.php';</script>";
			}
		}else{
		echo "<script>alert('You can only upload files with jpg, jpeg, and png extensions!');
		        document.location.href='add_product.php';</script>";
		}

	}
	// mysqli_close($connect);

}
?>

<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<!-- <meta name="description" content="">
    <meta name="author" content="Dashboard">
    <meta name="keyword" content="Dashboard, Bootstrap, Admin, Template, Theme, Responsive, Fluid, Retina"> -->

	<title>Knowledge Sdn Bhd</title>

	<!-- Bootstrap core CSS -->
	<link href="./assets/css/bootstrap.css" rel="stylesheet">
	<!--external css-->
	<link href="./assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
	<!-- <link rel="stylesheet" type="text/css" href="assets/css/zabuto_calendar.css"> -->
	<!-- <link rel="stylesheet" type="text/css" href="assets/js/gritter/css/jquery.gritter.css" /> boleh-->
	<link rel="stylesheet" type="text/css" href="./assets/lineicons/style.css">

	<!-- Custom styles for this template -->
	<link href="./assets/css/style.css" rel="stylesheet">
	<link href="./assets/css/style-responsive.css" rel="stylesheet">

	<script src="./assets/js/chart-master/Chart.js"></script>
	<script src="https://kit.fontawesome.com/2a7abdb60f.js" crossorigin="anonymous"></script>

	<!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
	<!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>

<body>

	<section id="container">
		<!-- **********************************************************************************************************************************************************
      TOP BAR CONTENT & NOTIFICATIONS
      *********************************************************************************************************************************************************** -->
		<!--header start-->
		<header class="header black-bg">
			<div class="sidebar-toggle-box">
				<div class="fa fa-bars tooltips" data-placement="right" data-original-title="Toggle Navigation"></div>
			</div>
			<!--logo start-->
		<a href="index.php" class="logo"><b>Knowledge</b></a>
			<!--logo end-->
			<div class="top-menu">
				<ul class="nav pull-right top-menu">
			<li><a class="logout" href="./logoutaction.php">Logout</a></li>
				</ul>
			</div>
		</header>
		<!--header end-->

		<!-- **********************************************************************************************************************************************************
      MAIN SIDEBAR MENU
      *********************************************************************************************************************************************************** -->
		<!--sidebar start-->
		<aside>
			<div id="sidebar" class="nav-collapse ">
				<!-- sidebar menu start-->
				<ul class="sidebar-menu" id="nav-accordion">
				<?php
 				$get_profile_stmt = "SELECT * FROM staff WHERE staff_id ='".$_SESSION['Staffid']."';";
				$get_profile_result = mysqli_query($connect, $get_profile_stmt);
				if($get_profile_row = mysqli_fetch_assoc($get_profile_result)){
					$name = $get_profile_row['staff_name'];
					$picture = $get_profile_row['staff_profile_picture'];
				}else{
					echo "<script>alert('Database error!');
						window.location.href='../master/login.php';
					</script>";
				}
				?>
							<p class="centered"><a href="./user_profile.php"><img src="./staff_picture/<?php echo $picture?>" class="img-circle" width="60"></a></p>
					<h5 class="centered"><?php echo $name ?></h5>

					<li class="mt">
						<a href="./index.php">
							<i class="fa fa-dashboard"></i>
							<span>Dashboard</span>
						</a>
					</li>

					<li class="sub-menu">
						<a href="./smasterlist.php">
						<i class="fa-solid fa-user-secret"></i>
							<span>Master</span>
						</a>
					</li>

					<li class="sub-menu">
						<a href="./sstafflist.php">
							<i class="fa-solid fa-helmet-safety"></i>
							<span>Staff</span>
						</a>
					</li>

					<li class="sub-menu">
				<a href="./scustomerlist.php">
							<i class="fa-solid fa-address-book"></i>
							<span>Customer</span>
						</a>
					</li>

					<li class="sub-menu">
						<a class="active" href="#">
							<i class="fa fa-book"></i>
							<span>Product</span>
						</a>
					</li>

					<li class="sub-menu">
						<a href="./order.php">
							<i class="fa-solid fa-cart-arrow-down"></i>
							<span>Order</span>
						</a>
					</li>

					<li class="sub-menu">
						<a href="./payment.php">
							<i class="fa fa-sack-dollar"></i>
							<span>Payment</span>
						</a>
					</li>

					<li class="sub-menu">
						<a href="./customer_review.php">
							<i class="fa-solid fa-comments"></i>
							<span>Customer Review</span>
						</a>
					</li>

					<li class="sub-menu">
						<a href="./faq.php">
                            <i class="fas fa-question-circle"></i>
							<span>FAQ</span>
						</a>
					</li>

				</ul>
				<!-- sidebar menu end-->
			</div>
		</aside>
		<!--sidebar end-->

		<!-- **********************************************************************************************************************************************************
      MAIN CONTENT
      *********************************************************************************************************************************************************** -->
		<!--main content start-->
		<section id="main-content">
			<section class="wrapper">

				<!-- BASIC FORM ELELEMNTS -->
				<div class="row mt">
					<div class="col-lg-12">
						<div class="form-panel">
							<h3 class="mb"><i class="fa fa-angle-right"></i> Add New Product</h3>


							<form name="add" method="post" action="add_product.php" enctype="multipart/form-data" class="form-horizontal style-form" >



								<div class="form-group">
									<label class="col-sm-2 col-sm-2 control-label" for="p_id">Product ID: </label>
									<div class="col-sm-10">
										<input type="text" id="p_id" name="product_id" size="50" required class="form-control">
									</div>
								</div>

								<div class="form-group">
									<label for="file" class="col-sm-2 col-sm-2 control-label">Product Image: </label>
									<div class="col-sm-10">
										<input type="file" id="file" name="file" size="50" required class="form-control">
									</div>
								</div>

								<div class="form-group">
									<label for="p_name" class="col-sm-2 col-sm-2 control-label">Product Name: </label>
									<div class="col-sm-10">
										<input type="text" id="p_name" name="product_name" size="50" required class="form-control">
									</div>
								</div>

								<div class="form-group">
									<label for="p_description" class="col-sm-2 col-sm-2 control-label">Product Description: </label>
									<div class="col-sm-10">
										<textarea cols="60" rows="3" id="p_description" name="product_description" required class="form-control"></textarea>
									</div>
								</div>


								<div class="form-group">
									<label for="category_id" class="col-sm-2 col-sm-2 control-label">Category:</label>
									<div class="col-sm-10">
										<select name="category_id" id="category_id" class="btn btn-theme dropdown-toggle">
											<?php
											$query = "SELECT * FROM category";
											$result = mysqli_query($connect, $query);
											while($row =mysqli_fetch_assoc($result)){
												echo '<option value="'.$row['category_id'].'">'.$row['category_name'].'</option>';
											}
											?>
										</select>
									</div>
								</div>



								<div class="form-group">
									<label for="author_id" class="col-sm-2 col-sm-2 control-label">Author Name:</label>
									<div class="col-sm-10">
										<select name="author_id" id="author_id" class="btn btn-theme dropdown-toggle">
											<?php
											$query = "SELECT * FROM author";
											$result = mysqli_query($connect, $query);
											while($row =mysqli_fetch_assoc($result)){
												echo '<option value="'.$row['author_id'].'">'.$row['author_name'].'</option>';
											}
											?>
										</select>

									</div>
								</div>


							    <div class="form-group">
									<label for="publisher_id" class="col-sm-2 col-sm-2 control-label">Publisher Name:</label>
									<div class="col-sm-10">
										<select name="publisher_id" id="publisher_id" class="btn btn-theme dropdown-toggle">
											<?php
											$query = "SELECT * FROM publisher";
											$result = mysqli_query($connect, $query);
											while($row =mysqli_fetch_assoc($result)){
											echo '<option value="'.$row['publisher_id'].'">'.$row['publisher_name'].'</option>';
											
										}
										mysqli_close($connect);
										?>
										</select>
									</div>
								</div>


								<div class="form-group">
									<label for="pbs_date" class="col-sm-2 col-sm-2 control-label">Publisher Date:</label>
									<div class="col-sm-10">
										<input type="date" id="pbs_date" name="publisher_date" size="15" required class="form-control">
									</div>
								</div>

								<script>
								// Get today's date
								var today = new Date().toISOString().split('T')[0];
								// Set the max attribute of the date input to today's date
								document.getElementById("pbs_date").setAttribute("max", today);
								</script>


								<div class="form-group">
									<label for="p_price" class="col-sm-2 col-sm-2 control-label">Product Price(RM): </label>
									<div class="col-sm-10">
										<input type="number" id="p_price" step="0.01" min="1" name="product_price" size="15" required class="form-control">
									</div>
								</div>

								<div class="form-group">
									<label for="dis_price" class="col-sm-2 col-sm-2 control-label">Discount(%): </label>
									<div class="col-sm-10">
										<input type="number" id="dis_price" step="0.01" min="0" max="70" name="discount" size="15" required class="form-control" onchange="updateDiscountedPrice()">
									</div>
								</div>

								<div class="form-group">
									<label for="discounted_price" class="col-sm-2 col-sm-2 control-label">Discounted Price(RM): </label>
									<div class="col-sm-10">
										<input type="number" id="discounted_price" name="discounted_price" size="15" required class="form-control" readonly>
    								</div>
								</div>

								<script>
								function updateDiscountedPrice() {
									var originalPrice = parseFloat(document.getElementById('p_price').value);
									var discountPercentage = parseFloat(document.getElementById('dis_price').value);
									var discountedPrice = originalPrice - (originalPrice * (discountPercentage / 100));
									document.getElementById('discounted_price').value = discountedPrice.toFixed(2);
									}
								</script>


								<div class="form-group">
									<label for="stock" class="col-sm-2 col-sm-2 control-label">Stock:</label>
									<div class="col-sm-10">
										<input type="number" id="stock_level" step="1" min="1" max="500" name="stock_level" size="15" required class="form-control">
									</div>
								</div>


								<div class="form-group">
									<label for="availability" class="col-sm-2 col-sm-2 control-label">Available:</label>
									<div class="col-sm-10">
										<select name="availability" id="availability" class="btn btn-theme dropdown-toggle">
											<option value="Active">0</option>
											<option value="Inactive">1</option>
										</select>
									</div>
								</div>

								<div class="form-group">
									<div class="col-sm-10">
										<input type="submit" name="addproduct" value="Add Product" class="btn btn-rounded btn-success">
									</div>
								</div>
							</form>
							<div>
								<a href="manage_product.php" class="btn btn-rounded btn-primary"> Back to Product List</a>
							</div>
						</div>
					</div><!-- col-lg-12-->
				</div><!-- /row -->



			</section>
			<!--/wrapper -->
		</section><!-- /MAIN CONTENT -->










		<!--main content end-->
		<!--footer start-->
		<footer class="site-footer">
			<div class="text-center">
				2023 - Knowledge
				<!-- <a href="index.html#" class="go-top">
                  <i class="fa fa-angle-up"></i>
              </a> -->
			</div>
		</footer>
		<!--footer end-->
	</section>

	<!-- js placed at the end of the document so the pages load faster -->
	<script src="./assets/js/jquery.js"></script>
	<script src="./assets/js/jquery-1.8.3.min.js"></script>
	<script src="./assets/js/bootstrap.min.js"></script>
	<script class="include" type="text/javascript" src="./assets/js/jquery.dcjqaccordion.2.7.js"></script>
	<script src="./assets/js/jquery.scrollTo.min.js"></script>
	<script src="./assets/js/jquery.nicescroll.js" type="text/javascript"></script>
	<script src="./assets/js/jquery.sparkline.js"></script>


	<!--common script for all pages-->
	<script src="./assets/js/common-scripts.js"></script>

	<!-- <script type="text/javascript" src="assets/js/gritter/js/jquery.gritter.js"></script>
    <script type="text/javascript" src="assets/js/gritter-conf.js"></script>  boleh-->

	<!--script for this page-->
	<!-- <script src="assets/js/sparkline-chart.js"></script>
	<script src="assets/js/zabuto_calendar.js"></script>	 -->

	<!-- <script type="text/javascript">
        $(document).ready(function () {
        var unique_id = $.gritter.add({
            // (string | mandatory) the heading of the notification
            title: 'Welcome to Dashgum!',
            // (string | mandatory) the text inside the notification
            text: 'Hover me to enable the Close Button. You can hide the left sidebar clicking on the button next to the logo. Free version for <a href="http://blacktie.co" target="_blank" style="color:#ffd777">BlackTie.co</a>.',
            // (string | optional) the image to display on the left
            image: 'assets/img/ui-sam.jpg',
            // (bool | optional) if you want it to fade out on its own or just sit there
            sticky: true,
            // (int | optional) the time you want it to be alive for before fading out
            time: '',
            // (string | optional) the class name you want to apply to that specific message
            class_name: 'my-sticky-class'
        });

        return false;
        });
	</script> boleh -->

	<script type="application/javascript">
		$(document).ready(function() {
					$("#date-popover").popover({
						html: true,
						trigger: "manual"
					});
					$("#date-popover").hide();
					$("#date-popover").click(function(e) {
						$(this).hide();
					});

					//   boleh  $("#my-calendar").zabuto_calendar({
					//         action: function () {
					//             return myDateFunction(this.id, false);
					//         },
					//         action_nav: function () {
					//             return myNavFunction(this.id);
					//         },
					//         ajax: {
					//             url: "show_data.php?action=1",
					//             modal: true
					//         },
					//         legend: [
					//             {type: "text", label: "Special event", badge: "00"},
					//             {type: "block", label: "Regular event", }
					//         ]
					//     });
					// });


					// function myNavFunction(id) {
					//     $("#date-popover").hide();
					//     var nav = $("#" + id).data("navigation");
					//     var to = $("#" + id).data("to");
					//     console.log('nav ' + nav + ' to: ' + to.month + '/' + to.year);
					// }

	</script>


</body>

</html>

<?php
session_start();
if(!isset($_SESSION['Staffid']) || !isset($_SESSION['Staffname']) || !isset($_SESSION['Staffemail'])){
 echo '
 <script>
 alert("Please sign in your account!");
 window.location.href="../master/login.php";
 </script>
 ';
}else{
 require_once 'dataconnection.php';

}

  use PHPMailer\PHPMailer\PHPMailer;
	use PHPMailer\PHPMailer\Exception;

	require 'PHPmailer/src/Exception.php';
	require 'PHPmailer/src/PHPMailer.php';
	require 'PHPmailer/src/SMTP.php';


if(isset($_POST['resetEmail'])){
  $newEmail = mysqli_real_escape_string($connect,$_POST['email']);
  $pass =  mysqli_real_escape_string($connect,$_POST['pass']);

  //all empty
  if(empty($newEmail) || empty($pass)){
    header("Location:./resetEmail.php?status=emptyinput");
    exit();
  }else{
    $vemail = filter_var($newEmail,FILTER_VALIDATE_EMAIL);
    $vemailRegex = preg_match('/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/',$newEmail);
    $vpass = preg_match('/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^\w\s]).{12,}$/',$pass);

    //all invalid
    if((!$vemail || !$vemailRegex) && !$vpass){
      header("Location:./resetEmail.php?status=allinvalid");
      exit();
    }

    //all valid
    else if($vemail && $vemailRegex && $vpass){
      //all valid start



      //start prepare statement staff email
      $sql = "SELECT * FROM staff WHERE staff_id = ? && staff_email = ?";
      $stmt = mysqli_stmt_init($connect);
      if(!mysqli_stmt_prepare($stmt,$sql)){
        //statement error
        header("Location:./resetEmail.php?status=sqlerror");
        exit();
      }else{
        //statement check password
        mysqli_stmt_bind_param($stmt, "ss", $_SESSION['Staffid'], $_SESSION['Staffemail']);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
        if($row = mysqli_fetch_assoc($result)){
          $checkPassword = password_verify($pass, $row['staff_password']);
          if($checkPassword == false){
            //statement wrong password
            header("Location:./resetEmail.php?status=wrongpassword");
            exit();
            //statement wrong password end
          }else if($checkPassword == true){
            //statement if password correct

            //check master email row prepare statement start
          $sqlmaster123 = "SELECT * FROM master WHERE master_email =?";
          $stmtmaster123 = mysqli_stmt_init($connect);
          if(!mysqli_stmt_prepare($stmtmaster123,$sqlmaster123)){
            header("Location:./sregister.php?status=sqlerror");
            exit(); //database error
          }else{ //database success
            mysqli_stmt_bind_param($stmtmaster123, "s", $newEmail);
            mysqli_stmt_execute($stmtmaster123);
            mysqli_stmt_store_result($stmtmaster123);
            $emailRowMaster = mysqli_stmt_num_rows($stmtmaster123);
          }
          mysqli_stmt_close($stmtmaster123);

          //check master email row prepare statement end


            //select staff email
            $sql1 = "SELECT * FROM staff WHERE staff_email = ?";
            $stmt1 = mysqli_stmt_init($connect);
            if(!mysqli_stmt_prepare($stmt1,$sql1)){
              header("Location:./resetEmail.php?status=sqlerror");
              exit();
              //statement statement error
            }else{
              mysqli_stmt_bind_param($stmt1, "s", $newEmail);
              mysqli_stmt_execute($stmt1);
              mysqli_stmt_store_result($stmt1);
              $newEmailRow = mysqli_stmt_num_rows($stmt1);
            }
						mysqli_stmt_close($stmt1);


            //check email taken
            if($newEmailRow >0 || $emailRowMaster >0){
              header("Location:./resetEmail.php?status=emailtaken");
              exit();
              //check email taken end
            }else{
            //send otp
              //session new email
              $_SESSION['StaffResettheNewEmailis'] = $newEmail;
              //send OTP
              $email="knowledgemain1991@gmail.com";
              $appPass="bsbddqyahqsshvdf";
              $OTP= mt_rand(100000,999999);
              $hashedOTP = password_hash($OTP,PASSWORD_DEFAULT);
              $_SESSION["StaffResetEmailOTP"]= $hashedOTP;
              $_SESSION["StaffOTPvExpiredTime"] = time() + 300;
              $subject="Reset Email -- Knowledge";
              $body ='<div style="font-family: Helvetica,Arial,sans-serif;min-width:1000px;overflow:auto;line-height:2">
              <div style="margin:50px auto;width:70%;padding:20px 0">
                <div style="border-bottom:1px solid #eee">
                  <a href="" style="font-size:1.4em;color: #00466a;text-decoration:none;font-weight:600">Knowledge</a>
                </div>
                <p style="font-size:1.1em">Hi,</p>
                <p>Thank you for choosing Knowledge. Use the following OTP to complete your Reset Email procedures. OTP is valid for 5 minutes</p>
                <h2 style="background: #00466a;margin: 0 auto;width: max-content;padding: 0 10px;color: #fff;border-radius: 4px;">'.$OTP.'</h2>
                <p style="font-size:0.9em;">Regards,<br />Knowledge Sdn Bhd</p>
                <hr style="border:none;border-top:1px solid #eee" />
                <div style="float:right;padding:8px 0;color:#aaa;font-size:0.8em;line-height:1;font-weight:300">
                  <p>Knowledge Sdn Bhd, Jalan Ayer Keroh Lama,</p>
                  <p>75450, Bukit Beruang,</p>
                  <p>Melaka, Malaysia</p>
                </div>
              </div>
              </div>
              ';


                      $mail = new PHPMailer(true);

                      $mail -> isSMTP();
                      $mail -> Host = 'smtp.gmail.com';
                      $mail -> SMTPAuth = true;
                      $mail -> Username = $email; //Your email
                      $mail -> Password = $appPass; //Your email app password
                      $mail -> SMTPSecure = 'ssl';
                      $mail -> Port = 465;

                      $mail -> setFrom($email); //Your email

                      $mail -> addAddress($newEmail); // customer email

                      $mail -> isHTML(true);

                      $mail -> Subject = $subject;
                      $mail -> Body = $body;

                      $mail -> send();

                      //OTP sent
                      echo
                      "
                      <script>
                      alert('Reset Email OTP sent!');
                      document.location.href='resetEmailOTPcheck.php';
                      </script>
                      ";



            }//email not taken send otp









          } //statement correct password end









        }//get password








      } // statement check password end







      //close statement
    	mysqli_stmt_close($stmt);
			mysqli_close($connect);

}//all valid end

    //invalid new email
    else if((!$vemail || !$vemailRegex) && $vpass){
      header("Location:./resetEmail.php?status=invalidnewemail");
      exit();
    }

    //invalid password
    else if(($vemail && $vemailRegex) && !$vpass){
      header("Location:./resetEmail.php?status=invalidpassword&email=".$newEmail);
      exit();
    }

  }





/*
//check email taken
if($newEmailRow >0){
  header("Location:./resetEmail.php?status=emailtaken");
  exit();
}else{

  //session new email
  $_SESSION['StaffResettheNewEmailis'] = $newEmail;
  //send OTP
  $email="knowledgemain1991@gmail.com";
  $appPass="bsbddqyahqsshvdf";
  $OTP= mt_rand(100000,999999);
  $hashedOTP = password_hash($OTP,PASSWORD_DEFAULT);
  $_SESSION["StaffResetEmailOTP"]= $hashedOTP;
  $_SESSION["StaffOTPvExpiredTime"] = time() + 300;
  $subject="Reset Email -- Knowledge";
  $body ='<div style="font-family: Helvetica,Arial,sans-serif;min-width:1000px;overflow:auto;line-height:2">
  <div style="margin:50px auto;width:70%;padding:20px 0">
    <div style="border-bottom:1px solid #eee">
      <a href="" style="font-size:1.4em;color: #00466a;text-decoration:none;font-weight:600">Knowledge</a>
    </div>
    <p style="font-size:1.1em">Hi,</p>
    <p>Thank you for choosing Knowledge. Use the following OTP to complete your Reset Email procedures. OTP is valid for 5 minutes</p>
    <h2 style="background: #00466a;margin: 0 auto;width: max-content;padding: 0 10px;color: #fff;border-radius: 4px;">'.$OTP.'</h2>
    <p style="font-size:0.9em;">Regards,<br />Knowledge Sdn Bhd</p>
    <hr style="border:none;border-top:1px solid #eee" />
    <div style="float:right;padding:8px 0;color:#aaa;font-size:0.8em;line-height:1;font-weight:300">
      <p>Knowledge Sdn Bhd, Jalan Ayer Keroh Lama,</p>
      <p>75450, Bukit Beruang,</p>
      <p>Melaka, Malaysia</p>
    </div>
  </div>
  </div>
  ';


          $mail = new PHPMailer(true);

          $mail -> isSMTP();
          $mail -> Host = 'smtp.gmail.com';
          $mail -> SMTPAuth = true;
          $mail -> Username = $email; //Your email
          $mail -> Password = $appPass; //Your email app password
          $mail -> SMTPSecure = 'ssl';
          $mail -> Port = 465;

          $mail -> setFrom($email); //Your email

          $mail -> addAddress($newEmail); // customer email

          $mail -> isHTML(true);

          $mail -> Subject = $subject;
          $mail -> Body = $body;

          $mail -> send();

          //OTP sent
          echo
          "
          <script>
          alert('Reset Email OTP sent!');
          document.location.href='resetEmailOTPcheck.php';
          </script>
          ";



}//email not taken send otp
*/








}


?>

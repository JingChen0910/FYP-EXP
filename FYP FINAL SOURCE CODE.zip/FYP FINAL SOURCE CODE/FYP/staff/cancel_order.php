<?php
session_start();
if(!isset($_SESSION['Staffid']) || !isset($_SESSION['Staffname']) || !isset($_SESSION['Staffemail'])){
   echo '
   <script>
   alert("Please sign in your account!");
   window.location.href="../master/login.php";
   </script>
   ';
}else{
   include("dataconnection.php");
}


if(isset($_GET['id'])) {
    $order_id = $_GET['id'];
    $query = "SELECT order_status FROM orders WHERE order_id = '$order_id'";
    $result = mysqli_query($connect, $query);
    $row = mysqli_fetch_assoc($result);
    $order_status = $row['order_status'];

    if($order_status !== 'Delivered') {
        // update the order status to "Cancelled"
        $query = "UPDATE orders SET order_status = 'Cancelled' WHERE order_id = $order_id";
        mysqli_query($connect, $query);
        echo "<script>alert('Order cancelled successfully!');</script>";
        echo "<script>window.location.href='order.php';</script>";
}
    else {
        echo "<script>alert('Error: Cannot cancel a delivered order.');</script>";
        echo "<script>window.location.href='order.php';</script>";
    }
}   else{
        echo "<script>alert('Error: order ID not provided. ');</script>";
        echo "<script>window.location.href='order.php';</script>";
}
?>

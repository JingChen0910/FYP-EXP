<?php
session_start();

unset($_SESSION['Staffid']);
unset($_SESSION['Staffname']);
unset($_SESSION['Staffemail']);
unset($_SESSION['Staffgender']);
unset($_SESSION['Staffbirthyear']);
unset($_SESSION['StaffpNumber']);
unset($_SESSION['Staffpicture']);

if(isset($_SESSION['StafftheHashedNewPasswordis'])){
  unset($_SESSION['StafftheHashedNewPasswordis']);
  }

if(isset($_SESSION['StaffrecoveryEmail'])){
  unset($_SESSION['StaffrecoveryEmail']);
}

if(isset($_SESSION['StaffRecoveryOTP'])){
  unset($_SESSION['StaffRecoveryOTP']);
}

if(isset($_SESSION['recoverWho'])){
  unset($_SESSION['recoverWho']);
}

if(isset($_SESSION['StaffRecoveryvExpiredTime'])){
  unset($_SESSION['StaffRecoveryvExpiredTime']);
}


header("Location:../master/login.php");

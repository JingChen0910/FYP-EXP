<?php
session_start();

if(!isset($_SESSION['Staffid']) || !isset($_SESSION['Staffname']) || !isset($_SESSION['Staffemail'])){
 echo '
 <script>
 alert("Please sign in your account!");
 window.location.href="../master/login.php";
 </script>
 ';
}else{
 require_once 'dataconnection.php';

}
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPmailer/src/Exception.php';
require 'PHPmailer/src/PHPMailer.php';
require 'PHPmailer/src/SMTP.php';



if(isset($_POST['reset'])){
  $pass = mysqli_real_escape_string($connect,$_POST['pass']);
  $newPass = mysqli_real_escape_string($connect,$_POST['newPass']);
  $newPassR = mysqli_real_escape_string($connect,$_POST['newPassR']);



	//all empty
  if(empty($pass) || empty($newPass) || empty($newPassR)){
    header("Location:./resetPass.php?status=emptyinput");
    exit();
  }else{
    $vpass = preg_match('/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^\w\s]).{12,}$/',$pass);
    $vnewPass = preg_match('/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^\w\s]).{12,}$/',$newPass);
    $vnewPassR = preg_match('/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^\w\s]).{12,}$/',$newPassR);

    //all invalid
    if(!$vpass && !$vnewPass && !$vnewPassR){
      header("Location:./resetPass.php?status=allinvalid");
			exit();
    }

    //all valid
    else if($vpass && $vnewPass && $vnewPassR){
      if(isset($_SESSION['Staffemail'])){
        $sql = "SELECT * FROM staff WHERE staff_email= ? ";
        $stmt = mysqli_stmt_init($connect);
        if(!mysqli_stmt_prepare($stmt,$sql)){
          header("Location:./resetPas.php?status=sqlerror");
        }else{
          mysqli_stmt_bind_param($stmt, "s", $_SESSION['Staffemail']);
          mysqli_stmt_execute($stmt);
          $result = mysqli_stmt_get_result($stmt);
          if($row = mysqli_fetch_assoc($result)){
            $checkedPassword = password_verify($pass,$row['staff_password']);
            if($checkedPassword == true){
              if($newPass != $pass && $newPass == $newPassR){
                $_SESSION['StafftheHashedNewPasswordis'] = password_hash($newPass,PASSWORD_DEFAULT);



								$email="knowledgemain1991@gmail.com";
								$appPass="bsbddqyahqsshvdf";
								$OTP= mt_rand(100000,999999);
								$hashedOTP = password_hash($OTP,PASSWORD_DEFAULT);
								$_SESSION["StaffResetPassOTP"]= $hashedOTP;
								$_SESSION["StaffResetPassvExpiredTime"] = time() + 300;
								$subject="Reset Password -- Knowledge";
								$body ='<div style="font-family: Helvetica,Arial,sans-serif;min-width:1000px;overflow:auto;line-height:2">
								<div style="margin:50px auto;width:70%;padding:20px 0">
								  <div style="border-bottom:1px solid #eee">
								    <a href="" style="font-size:1.4em;color: #00466a;text-decoration:none;font-weight:600">Knowledge</a>
								  </div>
								  <p style="font-size:1.1em">Hi,</p>
								  <p>Thank you for choosing Knowledge. Use the following OTP to complete your Reset Password procedures. OTP is valid for 5 minutes</p>
								  <h2 style="background: #00466a;margin: 0 auto;width: max-content;padding: 0 10px;color: #fff;border-radius: 4px;">'.$OTP.'</h2>
								  <p style="font-size:0.9em;">Regards,<br />Knowledge Sdn Bhd</p>
								  <hr style="border:none;border-top:1px solid #eee" />
								  <div style="float:right;padding:8px 0;color:#aaa;font-size:0.8em;line-height:1;font-weight:300">
								    <p>Knowledge Sdn Bhd, Jalan Ayer Keroh Lama,</p>
								    <p>75450, Bukit Beruang,</p>
								    <p>Melaka, Malaysia</p>
								  </div>
								</div>
								</div>
								';


								        $mail = new PHPMailer(true);

								        $mail -> isSMTP();
								        $mail -> Host = 'smtp.gmail.com';
								        $mail -> SMTPAuth = true;
								        $mail -> Username = $email; //Your email
								        $mail -> Password = $appPass; //Your email app password
								        $mail -> SMTPSecure = 'ssl';
								        $mail -> Port = 465;

								        $mail -> setFrom($email); //Your email

								        $mail -> addAddress($_SESSION['Staffemail']); // staff email

								        $mail -> isHTML(true);

								        $mail -> Subject = $subject;
								        $mail -> Body = $body;

								        $mail -> send();

								        //OTP sent
								        echo
								        "
								        <script>
								        alert('Reset Password OTP sent!');
								        document.location.href='resetOTPcheck.php';
								        </script>
								        ";


              }else if($newPass == $pass && $newPass == $newPassR ){
                header("Location:./resetPass.php?status=newpasssamewithcurrentpass");
								exit();
              }else if($newPass != $pass && $newPass != $newPassR){
								header("Location:./resetPass.php?status=newpassisnotsamewithnewpassr");
								exit();
							}else if($newPass == $pass && $newPass != $newPassR){
								header("Location:./resetPass.php?status=newpassissamewithcurrentpassandnewpassisnotsamewithnewpassr");
								exit();
							}
            }else if($checkedPassword == false){
              header("Location:./resetPass.php?status=incorrectcurrentpass");
							exit();
            }
          }else{
            header("Location:./resetPass.php?status=sqlerror");
						exit();
          }
        }

      }else{
        header("Location:./resetPass.php?status=failemail");
				exit();
      }
    }

    //only current pass invalid
    else if(!$vpass && $vnewPass && $vnewPassR){
      header("Location:./resetPass.php?status=invalidcurrentpass");
			exit();
    }

    //only new pass invalid
    else if($vpass && !$vnewPass && $vnewPassR){
      header("Location:./resetPass.php?status=invalidnewpass");
			exit();
    }

    //only new pass repeat invalid
    else if($vpass && $vnewPass && !$vnewPassR){
      header("Location:./resetPass.php?status=invalidnewpassrepeat");
			exit();
    }

    //only password valid
    else if($vpass && !$vnewPass && !$vnewPassR){
      header("Location:./resetPass.php?status=onlypassvalid");
			exit();
    }

    //only new pass valid
    else if(!$vpass && $vnewPass && !$vnewPassR){
      header("Location:./resetPass.php?status=onlynewpassvalid");
			exit();
    }

    //only new pass repeat valid
    else if(!$vpass && !$vnewPass && $vnewPassR){
      header("Location:./resetPass.php?status=onlynewpassrvalid");
			exit();
    }


  }




}

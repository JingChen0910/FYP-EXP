<?php
session_start();
require_once 'dataconnection.php';
if(!isset($_SESSION['Staffid']) || !isset($_SESSION['Staffname']) || !isset($_SESSION['Staffemail'])){
 echo '
 <script>
 alert("Please sign in your account!");
 window.location.href="../master/login.php";
 </script>
 ';
}

if(isset($_POST['delete'])){
    $id = $_POST['delete'];
    $sql1 = "SELECT staff_profile_picture FROM staff WHERE staff_id='".$id."';";
    $result = mysqli_query($connect,$sql1);
    if($row = mysqli_fetch_array($result)){
        $databaseProfilePicture = $row["staff_profile_picture"];
        if($databaseProfilePicture == "default.png"){
          echo
"
<script>
alert('You cannot delete the default profile picture!');
document.location.href='user_profile.php';
</script>
";
exit();

        }else if($databaseProfilePicture != "default.png"){
            $documentCustomerPicture = "./staff_picture/".$databaseProfilePicture;
            if(!unlink($documentCustomerPicture)){
              echo
          "
          <script>
          alert('Fail to delete the current profile picture file!');
          document.location.href='user_profile.php';
          </script>
          ";
          exit();
            }else{
                $sql2 = "UPDATE staff SET staff_profile_picture='default.png' WHERE staff_id = '".$id."';";
                if(mysqli_query($connect,$sql2)){
                  echo
      "
      <script>
      alert('Profile picture successfully deleted!');
      document.location.href='user_profile.php';
      </script>
      ";
      exit();
                }
            }
        }
    }else{
      echo
    "
    <script>
    alert('Sorry, SQL error!');
    document.location.href='user_profile.php';
    </script>
    ";
    exit();
	}
}

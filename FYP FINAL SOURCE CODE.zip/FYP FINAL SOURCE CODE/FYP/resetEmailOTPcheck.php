
<?php
session_start();
require_once 'dataconnection.php';
if(!isset($_SESSION['id']) || !isset($_SESSION['name']) || !isset($_SESSION['email']) || !isset($_SESSION['vemail'])){
	echo "<script>window.location.href='clogin.php';</script>";
 }else if(isset($_SESSION['id']) &&  isset($_SESSION['name']) && isset($_SESSION['email']) && isset($_SESSION['vemail'])){
	   $vemail = $_SESSION['vemail'];
	   if($vemail == false){
		echo "<script>window.location.href='sentOTP.php';</script>";
		  exit();
	   }
	}
	if(isset($_SESSION["rname"]))
    {
      unset($_SESSION["rname"]);
    }
    if(isset($_SESSION["remail"]))
    {
      unset($_SESSION["remail"]);
    }
    if(isset($_SESSION["rhp"]))
    {
      unset($_SESSION["rhp"]);
    }
	if(isset($_SESSION["padd1"]))
    {
      unset($_SESSION["padd1"]);
    }
    if(isset($_SESSION["padd2"]))
    {
      unset($_SESSION["padd2"]);
    }
    if(isset($_SESSION["pst"]))
    {
      unset($_SESSION["pst"]);
    }
    if(isset($_SESSION["ppc"]))
    {
      unset($_SESSION["ppc"]);
    }
    if(isset($_SESSION["pct"]))
    {
      unset($_SESSION["pct"]);
    }
    if(isset($_SESSION["ptype"]))
    {
      unset($_SESSION["ptype"]);
    }
    /*if(isset($_SESSION["payment_method"]))
    {
      unset($_SESSION["payment_method"]);
    }*/
    if(isset($_SESSION["cardtype"]))
    {
      unset($_SESSION["cardtype"]);
    }
    if(isset($_SESSION["holder_name"]))
    {
      unset($_SESSION["holder_name"]);
    }
    if(isset($_SESSION["cardnum"]))
    {
      unset($_SESSION["cardnum"]);
    }
    if(isset($_SESSION["cardvv"]))
    {
      unset($_SESSION["cardvv"]);
    }
    if(isset($_SESSION["carddate"]))
    {
      unset($_SESSION["carddate"]);
    }
    /*if(isset($_SESSION["ewallet_types"]))
    {
      unset($_SESSION["ewallet_types"]);
    }
    if(isset($_SESSION["transaction_no"]))
    {
      unset($_SESSION["transaction_no"]);
    }*/
    if(isset($_SESSION["address1"]))
    {
      unset($_SESSION["address1"]);
    }
    if(isset($_SESSION["address2"]))
    {
      unset($_SESSION["address2"]);
    }
    if(isset($_SESSION["city"]))
    {
      unset($_SESSION["city"]);
    }
    if(isset($_SESSION["state"]))
    {
      unset($_SESSION["state"]);
    }
    if(isset($_SESSION["postcode"]))
    {
      unset($_SESSION["postcode"]);
    }
?>

<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Reset Email OTP</title>
	<link rel="stylesheet" href="formstyle.css">
	<meta name="format-detection" content="telephone=no">
	    <meta name="apple-mobile-web-app-capable" content="yes">
	    <meta name="author" content="">
	    <meta name="keywords" content="">
	    <meta name="description" content="">

	    <link rel="stylesheet" type="text/css" href="css/normalize.css">
	    <link rel="stylesheet" type="text/css" href="icomoon/icomoon.css">
	    <link rel="stylesheet" type="text/css" href="css/vendor.css">
	    <link rel="stylesheet" type="text/css" href="style.css">
		<!-- script
		================================================== -->
		<script src="http://translate.google.com/translate_a/element.js?cb=loadGoogleTranslate"></script>
		<script src="js/modernizr.js">
			function handle_keyup(event){
				if (event.keyCode === 13) {
                   document.getElementById('search_btn').click();
                }
			}
		</script>
		<script style="text/javascript">
		  function loadGoogleTranslate() {
    const defaultLanguage = "en";

    const translateElement = new google.translate.TranslateElement({
      pageLanguage: defaultLanguage,
      includedLanguages: "en,ms,zh-CN",
      layout: google.translate.TranslateElement.InlineLayout.SIMPLE
    }, "google_element");

    // Get the language select dropdown element
    const languageSelect = document.getElementById("languageSelect");

    // Function to set a cookie
    function setCookie(name, value, days) {
      const expires = new Date();
      expires.setTime(expires.getTime() + days * 24 * 60 * 60 * 1000);
      document.cookie = `${name}=${value};expires=${expires.toUTCString()};path=/`;
    }

    // Function to get a cookie value
    function getCookie(name) {
      const cookieName = `${name}=`;
      const cookies = document.cookie.split(';');
      for (let i = 0; i < cookies.length; i++) {
        let cookie = cookies[i];
        while (cookie.charAt(0) === ' ') {
          cookie = cookie.substring(1);
        }
        if (cookie.indexOf(cookieName) === 0) {
          return cookie.substring(cookieName.length, cookie.length);
        }
      }
      return null;
    }

    // Set the initial language selection
    const storedLanguage = getCookie("selectedLanguage");
    if (storedLanguage) {
      languageSelect.value = storedLanguage;
      translateElement.update({
        includedLanguages: storedLanguage
      });
    }

    // Add event listener for change event
    languageSelect.addEventListener("change", function() {
      const selectedLanguage = this.value;
      translateElement.update({
        includedLanguages: selectedLanguage
      });
      setCookie("selectedLanguage", selectedLanguage, 30); // Set the cookie for 30 days
    });
  }
		</script>
</head>

<body>
<div id="header-wrap">

<div class="top-content">
	<div class="container">
		<div class="row">
		<div class="col-md-6" style="width: 25%;">

			</div>
			<div class="col-md-6" style="width: 75%;">
				<div class="right-element">

					<?php
					if(isset($_SESSION['id']) &&  isset($_SESSION['name']) && isset($_SESSION['email']) && isset($_SESSION['vemail'])){
						$vemail = $_SESSION['vemail'];
						if($vemail == false){
							echo "<script>window.location.href='sentOTP.php';</script>";
							exit();
						}
						// else{
						// 	header("Location:./index.php");
						// 	exit();
						// }
					}
					if(isset($_SESSION["id"]))
					{   $cust_id=$_SESSION["id"];
						$cartsql="SELECT * FROM cart WHERE customer_id=$cust_id";
						$run_cartsql=mysqli_query($connect, $cartsql);
						$num_rows_cartsql=mysqli_num_rows($run_cartsql);
						$rows_cartsql=mysqli_fetch_assoc($run_cartsql);
						if($num_rows_cartsql==0)
						{
							$cartitem_rows=0;
						}
						else
						{   $cartid=$rows_cartsql["cart_id"];
							$cartitemsql="SELECT * FROM cart_item WHERE cart_id=$cartid";
							$run_cartitemsql=mysqli_query($connect, $cartitemsql);
							$cartitem_rows=mysqli_num_rows($run_cartitemsql);
							$del_val=0;
							while($rows_cartitemsql=mysqli_fetch_assoc($run_cartitemsql))
							{
							  $prodid=$rows_cartitemsql["product_id"];
							  $itemqty=$rows_cartitemsql["item_quantity"];
							  $stocksql="SELECT * FROM stock WHERE product_id='$prodid'";
							  $run_stocksql=mysqli_query($connect, $stocksql);
							  $stockrows=mysqli_fetch_assoc($run_stocksql);
							  $stocklevel=$stockrows['stock_level'];
							  $prodsql="SELECT * FROM product WHERE product_id='$prodid' AND availability=0";
							  $run_prodsql=mysqli_query($connect, $prodsql);
							  $prodrows=mysqli_num_rows($run_prodsql);
							  if($prodrows==0)
							  {
								$del_cartitem="DELETE FROM cart_item WHERE cart_id=$cartid AND product_id='$prodid'";
								$run_del_cartitem=mysqli_query($connect, $del_cartitem);
								if($run_del_cartitem)
								  $del_val++;
							  }
							  else if($stocklevel==0)
							  {
								$del_cartitem="DELETE FROM cart_item WHERE cart_id=$cartid AND product_id='$prodid'";
								$run_del_cartitem=mysqli_query($connect, $del_cartitem);
								if($run_del_cartitem)
								  $del_val++;
							  }
							  else if($itemqty>$stocklevel)
							  {
								$update_cartitem="UPDATE cart_item SET item_quantity=$stocklevel WHERE cart_id=$cartid AND product_id='$prodid'";
								$run_update_cartitem=mysqli_query($connect, $update_cartitem);
							  }
							}
							if($del_val==$cartitem_rows)
							{
								$del_cart="DELETE FROM cart WHERE cart_id=$cartid";
								$run_del_cart=mysqli_query($connect, $del_cart);
							}
							$cartitem_rows-=$del_val;
						}
						$select_cust="SELECT * FROM customer WHERE customer_id=$cust_id";
						$run_select_cust=mysqli_query($connect, $select_cust);
						$row_select_cust=mysqli_fetch_assoc($run_select_cust);
						$user_profile=$row_select_cust["customer_profile_picture"];
						?>
						<a href="cart.php" class="cart for-buy"><img src="images/icon/carts.png" style="width: 50px; height: 50px; opacity: 70%; margin-bottom: 5px;"><span>Cart: <?php echo $cartitem_rows; ?> item(s)</span></a>
						<a href="order_history.php" class="cart for-buy"><i class="icon icon-clipboard"></i> <span>Order History</span></a>
					<nav id="navbar" style="display: inline-block; margin-left: -40px; position: relative; z-index: 3;">
					<div class="main-menu stellarnav">
					<ul class="menu-list">
					<li class="menu-item has-sub">
					<a href="./user_profile.php" class="nav-link" data-effect="Pages"><img src="images/cus_profile/<?php echo $user_profile; ?>" style="width: 40px; height: 40px; border-radius: 50%; margin-right: 10px;" alt="user_profile" title="user_profile">Account</a>
						<ul style="font-size: 16px;">
							<li><a href="./user_profile.php">My Profile</a></li>
							<li><a href="./logoutaction.php">Logout</a></li>
						 </ul>
					</li>
					</ul>
					</div>
					</nav>
					<?php
					}
					else
					{?><i class="icon icon-user"></i> <span>
					   <a href="./clogin.php">Login</a> | <a href="./cregister.php">Register</a>
					</span>
					<?php
					}?>

					<div class="action-menu" style="margin-left: 10px;">

						<div class="search-bar">
							<a href="#" class="search-button search-toggle" data-selector="#header-wrap">
								<i class="icon icon-search"></i>
							</a>
							<form role="search" method="get" class="search-box" action="search_products.php">
								<input class="search-field text search-input" placeholder="Search products" type="text" name="search_keyword" onkeyup="handle_keyup(event)">
								<input type="submit" id="search_btn" style="display: none;">
							</form>
						</div>
					</div>
					<div id="google_element" style="display: inline-block;"></div>
				</div><!--top-right-->
			</div>

		</div>
	</div>
</div><!--top-content-->

<header id="header" style="background-color: #f3e7be;">
	<div class="container">
		<div class="row">

			<div class="col-md-2">
				<!--<div class="main-logo">-->
					<a href="index.php"><img src="images/icon/logo.png" alt="logo" style="height: 140px; margin:-60px 0px -30px 0px;"></a>
				<!--</div>-->
			</div>

			<div class="col-md-10">

				<nav id="navbar" style="position: relative; z-index: 1;">
					<div class="main-menu stellarnav">
						<ul class="menu-list">
							<li class="menu-item"><a href="index.php" data-effect="Home" style="font-size: 17px;">Home</a></li>
							<li class="menu-item active"><a href="about_us.php" class="nav-link" data-effect="About" style="font-size: 17px;">About</a></li>
							<!--<li class="menu-item has-sub">
								<a href="#pages" class="nav-link" data-effect="Pages">Pages</a>

								<ul>
									<li><a href="styles.html">Styles</a></li>
									<li><a href="blog.html">Blog</a></li>
									<li><a href="single-post.html">Post Single</a></li>
									<li><a href="shop.php">Products</a></li>
									<li><a href="thank-you.html">Thank You</a></li>
								 </ul>

							</li>-->
							<li class="menu-item"><a href="shop.php" class="nav-link" data-effect="Shop" style="font-size: 17px;">Shop</a></li>
							<li class="menu-item"><a href="contact.php" class="nav-link" data-effect="Contact" style="font-size: 17px;">Contact Us</a></li>
						</ul>

						<div class="hamburger">
							<span class="bar"></span>
							<span class="bar"></span>
							<span class="bar"></span>
						</div>

					</div>
				</nav>

			</div>

		</div>
	</div>
</header>
    <div class="container" style="border:1px solid #ccc;">
	<form action="resetEmailOTPcheck.php" method="post">
		<div class="container">
			<h1>Reset Email</h1>
			<p>Please input the OTP to reset email.</p>
			<p style="color:red;">The OTP will expire in 5 minutes.</p>

			<hr>

			<label for="otp"><b>Reset Email OTP</b></label>
			<input type="number" placeholder="Enter OTP" name="otp" id="otp" min="0" required>

			<div class="clearfix">
				<button type="submit" class="signupbtn" name="otp-check" style="background-color: #04aa6d; height: 40px;">Submit</button>
			</div>

		</div>
		<?php

    if(isset($_POST['otp-check'])){
			if(time() <= $_SESSION['vExpiredTime']){
				$otp = mysqli_real_escape_string($connect,$_POST['otp']);
				if(empty($_POST['otp'])){
						echo
						"
						<script>
						alert('Please input OTP!');
						</script>
						";
				}else{
						$vOTP = preg_match('/^\d{6}$/',$otp);
						if($vOTP){
								if(password_verify($otp,$_SESSION["OTP"])){
									if(isset($_SESSION['theNewEmailis'])){
											$theNewEmailis = $_SESSION['theNewEmailis'];
											$sql = "UPDATE customer SET customer_email = ? WHERE customer_id = ?";
										$stmt = mysqli_stmt_init($connect);
										if(!mysqli_stmt_prepare($stmt,$sql)){
												echo
												"
												<script>
												alert('Sorry SQL error!');
												</script>
												";
										}else{

				mysqli_stmt_bind_param($stmt, "ss", $theNewEmailis ,$_SESSION['id']);
				mysqli_stmt_execute($stmt);

												echo
												"
												<script>
												alert('Reset email successfully!');
												  document.location.href='user_profile.php';
												</script>
												";

				}
					mysqli_stmt_close($stmt);
					mysqli_close($connect);
									}else{
				echo
					'
				<script>
				alert("Sorry, the reset email system got into trouble. Please try it later.");
				</script>
				';
									}




				}else if(!password_verify($vOTP,$_SESSION['OTP'])){
				 echo
				"
				<script>
				alert('Invalid OTP!');
				</script>
				";
				}

			}else{
				echo
				"
				<script>
				alert('Invalid OTP!');
				</script>
				";
			}
				}



			}else if(time() > $_SESSION['vExpiredTime']){
				//clear session
				unset($_SESSION["OTP"]);
				unset($_SESSION['theNewEmailis']);
				//alert user
				
				?>
				<script>
				alert("The OTP has expired! Please click the 'Reapply' button to reapply again to reset your email.");
				</script>
                <?php
				

				//output the resend button
				echo '
				<br>
				<br>
				';
				echo '<a href="./resetEmail.php" style="margin-left: 30px; margin-bottom: 20px; display: inline-block; padding: 10px 20px; background-color: #4CAF50; color: white; text-decoration: none; border-radius: 4px; border: none; text-align: center; cursor: pointer;">Reapply</a>';

			}
    }
?>
	</form></div>
	<footer id="footer" style="background-color: #f3e7be;">
	<div class="container">
		<div class="row">

			<div class="col-md-4" style="width: 40%;">

				<div class="footer-item">
					<div class="company-brand">
						<img src="images/icon/logo.png" alt="logo" class="footer-logo" style="height: 180px; width: 200px; margin-left: 70px;">
						<p>Welcome to Knowledge Bookstore, your gateway to a vast world of literary treasures, where words come alive and imagination knows no bounds.</p>
					</div>
				</div>

			</div>

			<div class="col-md-2" style="margin-top: 80px;">

				<div class="footer-menu">
					<h5><a href="about_us.php">About Us</a></h5>
					<ul class="menu-list">
						<li class="menu-item">
							Phone: 06 – 252 3253
						</li>
						<!--<li class="menu-item">
							<a href="#">articles </a>
						</li>
						<li class="menu-item">
							<a href="#">careers</a>
						</li>
						<li class="menu-item">
							<a href="#">service terms</a>
						</li>
						<li class="menu-item">
							<a href="#">donate</a>
						</li>-->
					</ul>
				</div>

			</div>
			<!--<div class="col-md-2">

				<div class="footer-menu">
					<h5>Discover</h5>
					<ul class="menu-list">
						<li class="menu-item">
							<a href="#">Home</a>
						</li>
						<li class="menu-item">
							<a href="#">Books</a>
						</li>
						<li class="menu-item">
							<a href="#">Authors</a>
						</li>
						<li class="menu-item">
							<a href="#">Subjects</a>
						</li>
						<li class="menu-item">
							<a href="#">Advanced Search</a>
						</li>
					</ul>
				</div>

			</div>-->
			<div class="col-md-2" style="padding-left: 30px; margin-top: 80px;">

				<div class="footer-menu">
					<h5>Quick Links</h5>
					<ul class="menu-list">
						<li class="menu-item">
							<a href="index.php">Home</a>
						</li>
						<li class="menu-item">
							<a href="shop.php">Shop</a>
						</li>
					</ul>
				</div>

			</div>
			<div class="col-md-2" style="padding-left: 100px; margin-top: 80px;">

				<div class="footer-menu">
					<h5>Services</h5>
					<ul class="menu-list">
						<!--<li class="menu-item">
							<a href="#">Help center</a>
						</li>
						<li class="menu-item">
							<a href="#">Report a problem</a>
						</li>
						<li class="menu-item">
							<a href="#">Suggesting edits</a>
						</li>-->
						<li class="menu-item">
							<a href="contact.php">Contact us</a>
						</li>
						<li class="menu-item">
							<a href="faq.php">FAQ</a>
						</li>
					</ul>
				</div>

			</div>

		</div>
		<!-- / row -->

	</div>
</footer>

<div id="footer-bottom">
	<div class="container">
		<div class="row">
			<div class="col-md-12">

				<div class="copyright">
					<div class="row">

						<div class="col-md-6">
							<p>© 2023 All rights reserved.</p>
						</div>

						<div class="col-md-6">

						</div>

					</div>
				</div><!--grid-->

			</div><!--footer-bottom-content-->
		</div>
	</div>
</div>

<script src="js/jquery-1.11.0.min.js"></script>
<script src="js/plugins.js"></script>
<script src="js/script.js"></script>
</body>

</html>

<!DOCTYPE html>
    <?php include("dataconnection.php");
	session_start();
	if(!isset($_GET["view"]) && !isset($_GET["hview"]))
	{
		header("location: shop.php");
	}
    ?>
	<html lang="en">
	<head>
		<title>Book Store</title>
		<meta charset="utf-8">
	    <meta http-equiv="X-UA-Compatible" content="IE=edge">
	    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	    <meta name="format-detection" content="telephone=no">
	    <meta name="apple-mobile-web-app-capable" content="yes">
	    <meta name="author" content="">
	    <meta name="keywords" content="">
	    <meta name="description" content="">
		<style>
			.half-yellow-black-star {
  background: linear-gradient(to right, #f1cf23 30%, black 70%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  font-size: 23px;
}
.range-container {
    width: 300px;
    height: 10px;
    background-color: #ccc;
    border-radius: 5px;
    position: relative;
  }
  .range-progress {
    background-color: #aa8b2f;
    height: 100%;
    border-radius: 5px;
  }
  .clearfix::after {
    content: "";
    display: table;
    clear: both;
  }
  .review_box {
    width: 80%;
    margin: 10px;
  }
  #wrap-comments{
	display: inline-block;
  width: 80%; /* Adjust this value to set the desired width of the span element */
  overflow: hidden;
  white-space: normal; /* Set the white-space property to "normal" */
  word-wrap: break-word;
  height: 100px;
  flex: 1;
  display: -webkit-box;
  -webkit-box-orient: vertical;
  -webkit-line-clamp: 3; /* Adjust this value to determine the number of lines to display */
  overflow: hidden;
  text-overflow: ellipsis;
  }
		</style>
	    <link rel="stylesheet" type="text/css" href="css/normalize.css">
	    <link rel="stylesheet" type="text/css" href="icomoon/icomoon.css">
	    <link rel="stylesheet" type="text/css" href="css/vendor.css">
	    <link rel="stylesheet" type="text/css" href="style.css">
		<!-- script
		================================================== -->
		<script src="http://translate.google.com/translate_a/element.js?cb=loadGoogleTranslate"></script>
		<script src="js/modernizr.js">
			function handle_keyup(event){
				if (event.keyCode === 13) {
                   document.getElementById('search_btn').click();
                }
			}
		</script>
		<script style="text/javascript">
			function loadGoogleTranslate() {
    const defaultLanguage = "en";

    const translateElement = new google.translate.TranslateElement({
      pageLanguage: defaultLanguage,
      includedLanguages: "en,ms,zh-CN",
      layout: google.translate.TranslateElement.InlineLayout.SIMPLE
    }, "google_element");

    // Get the language select dropdown element
    const languageSelect = document.getElementById("languageSelect");

    // Function to set a cookie
    function setCookie(name, value, days) {
      const expires = new Date();
      expires.setTime(expires.getTime() + days * 24 * 60 * 60 * 1000);
      document.cookie = `${name}=${value};expires=${expires.toUTCString()};path=/`;
    }

    // Function to get a cookie value
    function getCookie(name) {
      const cookieName = `${name}=`;
      const cookies = document.cookie.split(';');
      for (let i = 0; i < cookies.length; i++) {
        let cookie = cookies[i];
        while (cookie.charAt(0) === ' ') {
          cookie = cookie.substring(1);
        }
        if (cookie.indexOf(cookieName) === 0) {
          return cookie.substring(cookieName.length, cookie.length);
        }
      }
      return null;
    }

    // Set the initial language selection
    const storedLanguage = getCookie("selectedLanguage");
    if (storedLanguage) {
      languageSelect.value = storedLanguage;
      translateElement.update({
        includedLanguages: storedLanguage
      });
    }

    // Add event listener for change event
    languageSelect.addEventListener("change", function() {
      const selectedLanguage = this.value;
      translateElement.update({
        includedLanguages: selectedLanguage
      });
      setCookie("selectedLanguage", selectedLanguage, 30); // Set the cookie for 30 days
    });
  }
  function validate_cart()
  {
	var cart_qty=document.getElementById("cart_qty").value;
	if(cart_qty=="")
	{
		alert("Please select the quantity of product to add into the cart..."); return false;
	}
  }
		</script>
	</head>

<body>


<div id="header-wrap">

	<div class="top-content">
		<div class="container">
			<div class="row">
				<div class="col-md-6" style="width: 25%;">

				</div>
				<div class="col-md-6" style="width: 75%;">
					<div class="right-element">
						<?php
						if(isset($_SESSION['id']) &&  isset($_SESSION['name']) && isset($_SESSION['email']) && isset($_SESSION['vemail'])){
							$vemail = $_SESSION['vemail'];
							if($vemail == false){
								echo "<script>window.location.href='sentOTP.php';</script>";
								exit();
							}
							// else{
							// 	header("Location:./index.php");
							// 	exit();
							// }
						}
						if(isset($_SESSION["id"]))
						{   $cust_id=$_SESSION["id"];
							$cartsql="SELECT * FROM cart WHERE customer_id=$cust_id";
							$run_cartsql=mysqli_query($connect, $cartsql);
							$num_rows_cartsql=mysqli_num_rows($run_cartsql);
							$rows_cartsql=mysqli_fetch_assoc($run_cartsql);
							if($num_rows_cartsql==0)
							{
								$cartitem_rows=0;
							}
							else
							{   $cartid=$rows_cartsql["cart_id"];
								$cartitemsql="SELECT * FROM cart_item WHERE cart_id=$cartid";
							    $run_cartitemsql=mysqli_query($connect, $cartitemsql);
							    $cartitem_rows=mysqli_num_rows($run_cartitemsql);
								$del_val=0;
								while($rows_cartitemsql=mysqli_fetch_assoc($run_cartitemsql))
								{
                                  $prodid=$rows_cartitemsql["product_id"];
								  $itemqty=$rows_cartitemsql["item_quantity"];
								  $stocksql="SELECT * FROM stock WHERE product_id='$prodid'";
                                  $run_stocksql=mysqli_query($connect, $stocksql);
                                  $stockrows=mysqli_fetch_assoc($run_stocksql);
                                  $stocklevel=$stockrows['stock_level'];
								  $prodsql="SELECT * FROM product WHERE product_id='$prodid' AND availability=0";
                                  $run_prodsql=mysqli_query($connect, $prodsql);
                                  $prodrows=mysqli_num_rows($run_prodsql);
								  if($prodrows==0)
								  {
									$del_cartitem="DELETE FROM cart_item WHERE cart_id=$cartid AND product_id='$prodid'";
									$run_del_cartitem=mysqli_query($connect, $del_cartitem);
									if($run_del_cartitem)
                                      $del_val++;
								  }
								  else if($stocklevel==0)
								  {
									$del_cartitem="DELETE FROM cart_item WHERE cart_id=$cartid AND product_id='$prodid'";
									$run_del_cartitem=mysqli_query($connect, $del_cartitem);
									if($run_del_cartitem)
                                      $del_val++;
								  }
								  else if($itemqty>$stocklevel)
								  {
									$update_cartitem="UPDATE cart_item SET item_quantity=$stocklevel WHERE cart_id=$cartid AND product_id='$prodid'";
									$run_update_cartitem=mysqli_query($connect, $update_cartitem);
								  }
								}
								if($del_val==$cartitem_rows)
								{
									$del_cart="DELETE FROM cart WHERE cart_id=$cartid";
									$run_del_cart=mysqli_query($connect, $del_cart);
								}
								$cartitem_rows-=$del_val;
							}
							$select_cust="SELECT * FROM customer WHERE customer_id=$cust_id";
							$run_select_cust=mysqli_query($connect, $select_cust);
							$row_select_cust=mysqli_fetch_assoc($run_select_cust);
							$user_profile=$row_select_cust["customer_profile_picture"];
							?>
							<a href="cart.php" class="cart for-buy"><img src="images/icon/carts.png" style="width: 50px; height: 50px; opacity: 70%; margin-bottom: 5px;"><span>Cart: <?php echo $cartitem_rows; ?> item(s)</span></a>
							<a href="order_history.php" class="cart for-buy"><i class="icon icon-clipboard"></i> <span>Order History</span></a>
						<nav id="navbar" style="display: inline-block; margin-left: -40px; position: relative; z-index: 3;">
						<div class="main-menu stellarnav">
						<ul class="menu-list">
						<li class="menu-item has-sub">
						<a href="./user_profile.php" class="nav-link" data-effect="Pages"><img src="images/cus_profile/<?php echo $user_profile; ?>" style="width: 40px; height: 40px; border-radius: 50%; margin-right: 10px;" alt="user_profile" title="user_profile">Account</a>
							<ul style="font-size: 16px;">
								<li><a href="./user_profile.php">My Profile</a></li>
								<li><a href="./logoutaction.php">Logout</a></li>
							 </ul>
						</li>
						</ul>
						</div>
						</nav>
                        <?php
						}
						else
						{?><i class="icon icon-user"></i> <span>
						   <a href="./clogin.php">Login</a> | <a href="./cregister.php">Register</a>
						</span>
                        <?php
						}?>
						<div class="action-menu" style="margin-left: 10px;">

							<div class="search-bar">
								<a href="#" class="search-button search-toggle" data-selector="#header-wrap">
									<i class="icon icon-search"></i>
								</a>
								<form role="search" method="get" class="search-box" action="search_products.php">
									<input class="search-field text search-input" placeholder="Search products" type="text" name="search_keyword" onkeyup="handle_keyup(event)">
									<input type="submit" id="search_btn" style="display: none;">
								</form>
							</div>
						</div>
                        <div id="google_element" style="display: inline-block;"></div>
					</div><!--top-right-->
				</div>

			</div>
		</div>
	</div><!--top-content-->

	<header id="header" style="background-color: #f3e7be;">
		<div class="container">
			<div class="row">

			    <div class="col-md-2">
					<!--<div class="main-logo">-->
						<a href="index.php"><img src="images/icon/logo.png" alt="logo" style="height: 140px; margin:-60px 0px -30px 0px;"></a>
					<!--</div>-->
				</div>

				<div class="col-md-10">

					<nav id="navbar" style="position: relative; z-index: 1;">
						<div class="main-menu stellarnav">
							<ul class="menu-list">
								<li class="menu-item active"><a href="index.php" data-effect="Home">Home</a></li>
								<li class="menu-item"><a href="about_us.php" class="nav-link" data-effect="About">About</a></li>
								<!--<li class="menu-item has-sub">
									<a href="#pages" class="nav-link" data-effect="Pages">Pages</a>

									<ul>
								        <li><a href="styles.html">Styles</a></li>
								        <li><a href="blog.html">Blog</a></li>
								        <li><a href="single-post.html">Post Single</a></li>
								        <li><a href="thank-you.html">Thank You</a></li>
								     </ul>

								</li>-->
								<?php
								if(isset($_GET["hview"]))
								{?><li class="menu-item"><a href="shop.php" class="nav-link" data-effect="Shop">Shop</a></li>
                                <?php
								}
		                        else if(isset($_GET["view"]))
								{
                                    if (isset($_GET['cat']) && !isset($_GET['cart'])) {
										$category_id = $_GET['cat'];
										$num = $_GET['num'];
										if($category_id==0)
										{
										 if(!isset($_GET['sort_opt']))
										  {?>
										  <li class="menu-item"><a href="shop.php?cat=<?php echo $category_id; ?>&no=<?php echo $num; ?>">Shop</a></li>
										  <?php
											}
											else if(isset($_GET['sort_opt']))
											{  $sort_opt=$_GET['sort_opt'];
												if($sort_opt!="")
												{?>
												<li class="menu-item"><a href="shop.php?cat=<?php echo $category_id; ?>&no=<?php echo $num; ?>&sort_opt=<?php echo $sort_opt; ?>">Shop</a></li>
												<?php
												}
												else if($sort_opt=="")
												{?>
												<li class="menu-item"><a href="shop.php?cat=<?php echo $category_id; ?>&no=<?php echo $num; ?>">Shop</a></li>
												<?php
												}
											}
										}
										else if($category_id!=0)
										{?><li class="menu-item"><a href="shop.php">Shop</a></li>
										<?php
										}
									}
									else
									{?><li class="menu-item"><a href="shop.php">Shop</a></li>
									<?php
									}
								}
								?>
								<li class="menu-item"><a href="#contact" class="nav-link" data-effect="contact.php">Contact Us</a></li>
							</ul>

							<div class="hamburger">
				                <span class="bar"></span>
				                <span class="bar"></span>
				                <span class="bar"></span>
				            </div>

						</div>
					</nav>

				</div>

			</div>
		</div>
	</header>

</div><!--header-wrap-->
<div>
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div class="colored">
					<br>
					<div class="breadcum-items">
					<?php
					  if(isset($_GET["view"]))
					  {  $proid=$_GET["id"];
						 $num_page=$_GET["num"];
						 $prosql="SELECT * FROM product WHERE product_id='$proid'";
                         $run_prosql=mysqli_query($connect, $prosql);
                         $prorows=mysqli_fetch_assoc($run_prosql);
						 $proname=$prorows["product_name"];
		              if (isset($_GET['cat']) && !isset($_GET['cart'])) {
				        $category_id = $_GET['cat'];
						$num = $_GET['num'];
						if($category_id!=0)
						{
							$cat_query = "SELECT * FROM category WHERE category_id=$category_id";
							$cat_result = mysqli_query($connect, $cat_query);
							$cat_row=mysqli_fetch_assoc($cat_result);
							$cat_name=$cat_row["category_name"];?>
							<span class="item"><a href="index.php">Home</a> /</span>
							<span class="item colored"><a href="shop.php">Shop</a> /</span>
							<?php
							if(!isset($_GET['sort_opt']))
							{?><span class="item colored"><a href="shop.php?cat=<?php echo $category_id; ?>&no=<?php echo $num; ?>"><?php echo $cat_name; ?></a> /</span>
                            <?php
							}
							else if(isset($_GET['sort_opt']))
							{  $sort_opt=$_GET['sort_opt'];
								if($sort_opt!="")
								{?><span class="item colored"><a href="shop.php?cat=<?php echo $category_id; ?>&no=<?php echo $num; ?>&sort_opt=<?php echo $sort_opt; ?>"><?php echo $cat_name; ?></a> /</span>
							    <?php
								}
							    else if($sort_opt=="")
								{?><span class="item colored"><a href="shop.php?cat=<?php echo $category_id; ?>&no=<?php echo $num; ?>"><?php echo $cat_name; ?></a> /</span>
							    <?php
								}
							}?>
							<span class="item colored"><?php echo $proname; ?></span>
                             <?php
						}
						else
						{?>
						 <span class="item"><a href="index.php">Home</a> /</span>
						 <?php
						 if(!isset($_GET['sort_opt']))
						  {?>
						  <span class="item colored"><a href="shop.php?cat=<?php echo $category_id; ?>&no=<?php echo $num; ?>">Shop</a> /</span>
						  <?php
							}
							else if(isset($_GET['sort_opt']))
							{  $sort_opt=$_GET['sort_opt'];
								if($sort_opt!="")
								{?>
						        <span class="item colored"><a href="shop.php?cat=<?php echo $category_id; ?>&no=<?php echo $num; ?>&sort_opt=<?php echo $sort_opt; ?>">Shop</a> /</span>
						        <?php
								}
								else if($sort_opt=="")
								{?>
								<span class="item colored"><a href="shop.php?cat=<?php echo $category_id; ?>&no=<?php echo $num; ?>">Shop</a> /</span>
								<?php
								}
							}?>
						  <span class="item colored"><?php echo $proname; ?></span>
						 <?php
						}
					  }
					  else
					  {  if(isset($_GET["sh"]))
						{  $num_page=$_GET["num"];
							$keyword=$_GET["sh"];?>
							<span class="item"><a href="index.php">Home</a> /</span>
							<span class="item colored"><a href="search_products.php?page&search_keyword=<?php echo $keyword; ?>&num=<?php echo $num_page; ?>">Search Products</a> /</span>
							<span class="item colored"><?php echo $proname; ?></span>
							<?php
						}
						else if(isset($_GET['cart']))
						{?>
                         <span class="item"><a href="index.php">Home</a> /</span>
						 <span class="item colored"><a href="cart.php">Cart</a> /</span>
						 <span class="item colored"><?php echo $proname; ?></span>
						<?php
						}
					  }
					  }
					  else if(isset($_GET["hview"]))
					  {  $proid=$_GET["id"];
						$prosql="SELECT * FROM product WHERE product_id='$proid'";
						$run_prosql=mysqli_query($connect, $prosql);
						$prorows=mysqli_fetch_assoc($run_prosql);
						$proname=$prorows["product_name"];
						?>
					    <span class="item"><a href="index.php">Home</a> /</span>
						 <span class="item colored"><?php echo $proname; ?></span>
                        <?php
					  }
					  ?>
					</div>
				</div>
			</div>
		</div>
	</div>
</div><!--site-banner-->
<section class="bg-sand padding-large">
	<div class="container">
		<div class="row">
            <?php
            if(isset($_GET["view"]) || isset($_GET["hview"]))
            {  $product_id=$_GET["id"];
               $product_sql="SELECT * FROM product WHERE product_id='$product_id'";
               $run_product_sql=mysqli_query($connect, $product_sql);
               $product_rows=mysqli_fetch_assoc($run_product_sql);
               $author_id=$product_rows['author_id'];
               $author_sql="SELECT * FROM author WHERE author_id=$author_id";
               $run_author_sql=mysqli_query($connect, $author_sql);
               $author_rows=mysqli_fetch_assoc($run_author_sql);
               $author_name=$author_rows['author_name'];
               $publisher_id=$product_rows['publisher_id'];
               $publisher_sql="SELECT * FROM publisher WHERE publisher_id=$publisher_id";
               $run_publisher_sql=mysqli_query($connect, $publisher_sql);
               $publisher_rows=mysqli_fetch_assoc($run_publisher_sql);
               $publisher_name=$publisher_rows['publisher_name'];
			   $stock_sql="SELECT * FROM stock WHERE product_id='$product_id'";
               $run_stock_sql=mysqli_query($connect, $stock_sql);
               $stock_rows=mysqli_fetch_assoc($run_stock_sql);
               $stock_level=$stock_rows['stock_level'];
			   $count_products="SELECT * FROM order_details LEFT JOIN orders ON order_details.order_id = orders.order_id WHERE order_details.product_id='$product_id' AND NOT orders.order_status='cancelled'";
			   $run_count_products=mysqli_query($connect, $count_products);
			   $num_counts=mysqli_num_rows($run_count_products);
			   $product_rating="SELECT * FROM rating WHERE product_id='$product_id'";
			   $runproduct_rating=mysqli_query($connect, $product_rating);
			   $total_rates=mysqli_num_rows($runproduct_rating);
			   if($total_rates!=0)
			   {  $rating_rates=0;
				  while($rows_rate=mysqli_fetch_assoc($runproduct_rating))
				  {
                    $rating_rates+=$rows_rate["rating_rate"];
				  }
				  $count_rates=$overall_rates=number_format($rating_rates/$total_rates, 1);
			   }
            ?>
            <div class="col-md-6">
				<a href="#" class="product-image"><img src="staff/product_image/<?php echo $product_rows['product_image']; ?>" style="width: 60%; height: 80%; margin-left: 100px;"></a>
			</div>

			<div class="col-md-6 pl-5">
				<div class="product-detail">
					<h1><?php echo $product_rows['product_name']; ?></h1>
					By <?php echo $author_rows['author_name']; ?><br>
					<?php $star_num=0;
					  if($total_rates!=0)
					  {  while($count_rates>=1)
						 {?><span style="color: #f1cf23; font-size: 23px;">&#9733; </span>
						 <?php $count_rates--; $star_num++;
						 }
						 if($count_rates!=0)
						 {?><span class="half-yellow-black-star">&#9733; </span>
                          <?php $star_num++;
						 }
						 while($star_num!=5)
						 {?><span style="font-size: 23px;">&#9733; </span>
							<?php $star_num++;
						 }
						?>
					      <?php echo $overall_rates;
						?>
					  <?php
					  }
					  else
					  {?>No rated yet
					  <?php
					  }
					?>
					|
					<?php echo $num_counts; ?> sold<br><br>
					<?php $drate=$product_rows['discount']; $pprice=$product_rows['product_price'];
						if($drate!=0)
						{  $dprice=$product_rows['discount_price'];?>
                          <span class="price colored"><del>RM <?php echo number_format($pprice, 2); ?></del></span><br>
						  <span class="price colored" style="font-size: 22px; font-weight: bold;">RM <?php echo number_format($dprice, 2); ?></span><br><br>
                        <?php
						}
						else
						{?>
						<span class="price colored" style="font-size: 22px; font-weight: bold;">RM <?php echo number_format($pprice, 2); ?></span><br><br>
						<?php
						}?>
					<p>
					<span style="font-weight: bold; font-size: 20px;">Summary:</span><br>
                    <?php echo $product_rows['product_description']; $formatted_date = date('d/m/Y', strtotime($product_rows['publisher_date']));?>
					</p>
                    <p><span style="font-weight: bold; font-size: 18px;">Publisher: </span><?php echo $publisher_name; ?> on <?php echo $formatted_date; ?></p>
					<p><span style="font-weight: bold; font-size: 18px; <?php if($stock_level==0) echo 'color: red;'; ?>">
					<?php
					if($stock_level!=0)
					{?>Available Stock: </span><?php echo $stock_level; ?>
                     <?php
					}
					else
					{?>*Out of Stock</span>
					 <?php
					}
					?>
					</p>
					<form action="add-to-cart.php" method="POST" onsubmit="return validate_cart()">
					<input type="hidden" id="product_id" name="product_id" value="<?php echo $product_rows['product_id']; ?>">
					<?php
					if($stock_level!=0)
					{?>Quantity<br>
					<input type="number" id="cart_qty" name="cart_qty" min="1" max="<?php echo $stock_level; ?>" value="1"><br>
					<?php
					}?>
					<button type="submit" name="add-to-cart" value="27545" class="button" <?php if($stock_level==0) echo "disabled style='opacity: 40%; cursor: default;'";?>>Add to cart</button>
			        </form>
				</div>
			</div>
			<?php
			if($total_rates!=0)
			{?>
			  <div style="margin-left: 50px;">
                 <span style="font-weight: bold; font-size:20px; background-color: #74642F; color: white; padding: 10px;">Product Ratings</span><br>
				<div id="wrap-all-rates" class="clearfix" style="width: 95%; border: 1px solid #74642F;">
				 <div style="margin-left: 150px; margin-top: 30px; float: left; width: 50%;">
					<span style="font-size: 75px;"><?php echo $overall_rates;?></span>
					<?php
					$star_num=0; $count_rates=$overall_rates;
                         while($count_rates>=1)
						 {?><span style="color: #f1cf23; font-size: 23px;">&#9733; </span>
						 <?php $count_rates--; $star_num++;
						 }
						 if($count_rates!=0)
						 {?><span class="half-yellow-black-star">&#9733; </span>
                          <?php $star_num++;
						 }
						 while($star_num!=5)
						 {?><span style="font-size: 23px;">&#9733; </span>
							<?php $star_num++;
						 }
						?>
						<br>
						<span style="font-size: 20px;"><?php echo $total_rates; ?> Review(s)</span>
			     </div>
				 <div style="display: inline-block; margin-top: -150px; float: right; width: 50%;">
				       <div style="margin-left: 140px;">
				        <?php $rate5="SELECT * FROM rating WHERE product_id='$product_id' AND rating_rate=5";
						      $run_rate5=mysqli_query($connect, $rate5);
							  $total_rate5=mysqli_num_rows($run_rate5);
							  $width5=number_format(($total_rate5/$total_rates)*100, 1);
						?>
						5 <div class="range-container" style="display: inline-block;">
                          <div class="range-progress" style="width: <?php echo $width5;?>%;"></div>
                        </div><br>
						<?php $rate4="SELECT * FROM rating WHERE product_id='$product_id' AND rating_rate=4";
						      $run_rate4=mysqli_query($connect, $rate4);
							  $total_rate4=mysqli_num_rows($run_rate4);
							  $width4=number_format(($total_rate4/$total_rates)*100, 1);
						?>
						4 <div class="range-container" style="display: inline-block;">
                          <div class="range-progress" style="width: <?php echo $width4;?>%;"></div>
                        </div><br>
						<?php $rate3="SELECT * FROM rating WHERE product_id='$product_id' AND rating_rate=3";
						      $run_rate3=mysqli_query($connect, $rate3);
							  $total_rate3=mysqli_num_rows($run_rate3);
							  $width3=number_format(($total_rate3/$total_rates)*100, 1);
						?>
						3 <div class="range-container" style="display: inline-block;">
                          <div class="range-progress" style="width: <?php echo $width3;?>%;"></div>
                        </div><br>
						<?php $rate2="SELECT * FROM rating WHERE product_id='$product_id' AND rating_rate=2";
						      $run_rate2=mysqli_query($connect, $rate2);
							  $total_rate2=mysqli_num_rows($run_rate2);
							  $width2=number_format(($total_rate2/$total_rates)*100, 1);
						?>
						2 <div class="range-container" style="display: inline-block;">
                          <div class="range-progress" style="width: <?php echo $width2;?>%;"></div>
                        </div><br>
						<?php $rate1="SELECT * FROM rating WHERE product_id='$product_id' AND rating_rate=1";
						      $run_rate1=mysqli_query($connect, $rate1);
							  $total_rate1=mysqli_num_rows($run_rate1);
							  $width1=number_format(($total_rate1/$total_rates)*100, 1);
						?>
						1 <div class="range-container" style="display: inline-block;">
                          <div class="range-progress" style="width: <?php echo $width1;?>%;"></div>
                        </div>
					  </div>
			     </div>
				 <?php $all_rates="SELECT rating.*, customer.* FROM rating LEFT JOIN customer ON rating.customer_id = customer.customer_id WHERE product_id='$product_id' ORDER BY rating_rate DESC, rating_date DESC";
					   $runall_rates=mysqli_query($connect, $all_rates); $allrates_row=0;
				 ?>
				 <div class="container" style="display: flex; flex-wrap: wrap; margin-left: 90px; margin-top: 300px;">
					<?php
					while($rows_allrates=mysqli_fetch_assoc($runall_rates))
					{ $user_profile=$rows_allrates["customer_profile_picture"];
					  $user_name=$rows_allrates["customer_name"];
					  $user_id=$rows_allrates["customer_id"];
					  if(isset($_SESSION["id"]))
					  {
						if($_SESSION["id"]==$user_id)
						{
							$user_name="You";
						}
					  }
					  $rate_star=$rows_allrates["rating_rate"];
					  $user_rating_date=$rows_allrates["rating_date"];
					  $formatted_ratedate = date('d/m/Y', strtotime($user_rating_date));
					  $user_comments=$rows_allrates["comments"];
					 ?>
                     <div class="review_box">
					    <img src="images/cus_profile/<?php echo $user_profile; ?>" style="width: 40px; height: 40px; border-radius: 50%;">  <?php echo $user_name; ?><br>
						<?php
						$star_num=0; $count_rates=$rate_star;
					     while($count_rates>=1)
						 {?><span style="color: #f1cf23; font-size: 23px;">&#9733; </span>
						 <?php $count_rates--; $star_num++;
						 }
						 if($count_rates!=0)
						 {?><span class="half-yellow-black-star">&#9733; </span>
                          <?php $star_num++;
						 }
						 while($star_num!=5)
						 {?><span style="font-size: 23px;">&#9733; </span>
							<?php $star_num++;
						 }
						?>
						<?php echo $formatted_ratedate; ?><br>
						<?php
						if($user_comments!="")
						{?><span id="wrap-comments"><?php echo $user_comments; ?></span>
						<?php
						}?>
					 </div>
                    <?php $allrates_row++;
					  if($allrates_row==3)
					  {break; }
					}
					?>
                 </div><br>
				 <?php
				 if(isset($_GET["view"]))
				 {   if (isset($_GET['cat']) && !isset($_GET['cart']))
					{?><span style="font-size: 20px; text-decoration: none; margin-left: 140px; "><a href="user_ratings.php?vr&id=<?php echo $product_id; ?>&cat=<?php echo $category_id; ?>&num=<?php echo $num_page; ?>&sort_opt=<?php echo $sort_opt; ?>&typ=all">More Ratings</a></span>
				    <?php
					}
					else if(isset($_GET['cart']))
					{?><span style="font-size: 20px; text-decoration: none; margin-left: 140px; "><a href="user_ratings.php?vr&id=<?php echo $product_id; ?>&typ=all">More Ratings</a></span>
					<?php
					}
					else if(isset($_GET['sh']))
					{?><span style="font-size: 20px; text-decoration: none; margin-left: 140px; "><a href="user_ratings.php?vr&id=<?php echo $product_id; ?>&typ=all&sw=<?php echo $keyword; ?>&num=<?php echo $num_page; ?>">More Ratings</a></span>
						<?php
					}
				 }
				 else
				 {?><span style="font-size: 20px; text-decoration: none; margin-left: 140px; "><a href="user_ratings.php?vr&id=<?php echo $product_id; ?>&typ=all&hvw=1">More Ratings</a></span>
				<?php
				 }
				 ?>
				 <br><br>
				</div>
              </div>
             <?php
			}
            }
			?>
		</div>
	</div>
</section>


<footer id="footer" style="background-color: #f3e7be;">
	<div class="container">
		<div class="row">

			<div class="col-md-4" style="width: 40%;">

				<div class="footer-item">
					<div class="company-brand">
						<img src="images/icon/logo.png" alt="logo" class="footer-logo" style="height: 180px; width: 200px; margin-left: 70px;">
						<p>Welcome to Knowledge Bookstore, your gateway to a vast world of literary treasures, where words come alive and imagination knows no bounds.</p>
					</div>
				</div>

			</div>

			<div class="col-md-2" style="margin-top: 80px;">

				<div class="footer-menu">
					<h5><a href="about_us.php">About Us</a></h5>
					<ul class="menu-list">
						<li class="menu-item">
							Phone: 06 – 252 3253
						</li>
						<!--<li class="menu-item">
							<a href="#">articles </a>
						</li>
						<li class="menu-item">
							<a href="#">careers</a>
						</li>
						<li class="menu-item">
							<a href="#">service terms</a>
						</li>
						<li class="menu-item">
							<a href="#">donate</a>
						</li>-->
					</ul>
				</div>

			</div>
			<!--<div class="col-md-2">

				<div class="footer-menu">
					<h5>Discover</h5>
					<ul class="menu-list">
						<li class="menu-item">
							<a href="#">Home</a>
						</li>
						<li class="menu-item">
							<a href="#">Books</a>
						</li>
						<li class="menu-item">
							<a href="#">Authors</a>
						</li>
						<li class="menu-item">
							<a href="#">Subjects</a>
						</li>
						<li class="menu-item">
							<a href="#">Advanced Search</a>
						</li>
					</ul>
				</div>

			</div>-->
			<div class="col-md-2" style="padding-left: 30px; margin-top: 80px;">

				<div class="footer-menu">
					<h5>Quick Links</h5>
					<ul class="menu-list">
						<li class="menu-item">
							<a href="index.php">Home</a>
						</li>
						<li class="menu-item">
							<a href="shop.php">Shop</a>
						</li>
					</ul>
				</div>

			</div>
			<div class="col-md-2" style="padding-left: 100px; margin-top: 80px;">

				<div class="footer-menu">
					<h5>Services</h5>
					<ul class="menu-list">
						<!--<li class="menu-item">
							<a href="#">Help center</a>
						</li>
						<li class="menu-item">
							<a href="#">Report a problem</a>
						</li>
						<li class="menu-item">
							<a href="#">Suggesting edits</a>
						</li>-->
						<li class="menu-item">
							<a href="contact.php">Contact us</a>
						</li>
						<li class="menu-item">
							<a href="faq.php">FAQ</a>
						</li>
					</ul>
				</div>

			</div>

		</div>
		<!-- / row -->

	</div>
</footer>

<div id="footer-bottom">
	<div class="container">
		<div class="row">
			<div class="col-md-12">

				<div class="copyright">
					<div class="row">

						<div class="col-md-6">
							<p>© 2023 All rights reserved.</p>
						</div>

						<div class="col-md-6">

						</div>

					</div>
				</div><!--grid-->

			</div><!--footer-bottom-content-->
		</div>
	</div>
</div>

<script src="js/jquery-1.11.0.min.js"></script>
<script src="js/plugins.js"></script>
<script src="js/script.js"></script>

</body>
</html>

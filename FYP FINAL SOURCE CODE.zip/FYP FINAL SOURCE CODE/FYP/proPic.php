<?php
session_start();
	require_once 'dataconnection.php';
	if(!isset($_SESSION['id']) || !isset($_SESSION['name']) || !isset($_SESSION['email']) || !isset($_SESSION['vemail'])){
		echo "<script>window.location.href='clogin.php';</script>";
	 }else if(isset($_SESSION['id']) &&  isset($_SESSION['name']) && isset($_SESSION['email']) && isset($_SESSION['vemail'])){
		   $vemail = $_SESSION['vemail'];
		   if($vemail == false){
			echo "<script>window.location.href='sentOTP.php';</script>";
			  exit();
		   }else{
			//variable $id $name $email
			$id = $_SESSION['id'];
	$name = $_SESSION['name'];
	$email = $_SESSION['email'];
		   }
		}

if(isset($_POST['upload'])){
	$picture = $_FILES['picture'];


	if(!empty($_FILES['picture'])){
$pictureName = $_FILES['picture']['name'];
	$pictureTmpName = $_FILES['picture']['tmp_name'];
	$pictureSize = $_FILES['picture']['size'];
	$pictureError = $_FILES['picture']['error'];
	$pictureType = $_FILES['picture']['type'];

	$pictureExtension = explode('.',$pictureName);
	$pictureActualExtension = strtolower(end($pictureExtension));

	$pictureAllowedExtension = array('jpg','jpeg','png');
	if(in_array($pictureActualExtension,$pictureAllowedExtension)){
		if($pictureError === 0){
			if($pictureSize <= 1000000){
				$sql1 = "SELECT customer_profile_picture FROM customer WHERE customer_id='".$id."' && customer_name ='".$name."' && customer_email= '".$email."';";
				$result = mysqli_query($connect,$sql1);
				if($row1 = mysqli_fetch_assoc($result)){
					$databaseProfilePicture= $row1['customer_profile_picture'];
					if($databaseProfilePicture == "default.png"){
						$newPictureName = "cpicture".$id.".".$pictureActualExtension;
						$pictureLocation = "./images/cus_profile/".$newPictureName;
						if(move_uploaded_file($pictureTmpName, $pictureLocation)){
						$sql =  "UPDATE customer SET customer_profile_picture= '".$newPictureName."' WHERE customer_id='".$id."' && customer_name ='".$name."' && customer_email= '".$email."';";
						if(mysqli_query($connect,$sql)){
							echo
			        "
			        <script>
			        alert('Profile picture upload success!');
			        document.location.href='user_profile.php';
			        </script>
			        ";
							exit();
						}else{
							echo
							"
							<script>
							alert('Profile picture upload success but failure to update the database!');
							document.location.href='user_profile.php';
							</script>
							";
							exit();
						}
						}else{
							echo
							"
							<script>
							alert('Profile picture upload fails!');
							document.location.href='user_profile.php';
							</script>
							";
							exit();
						}
					}else{
						$documentCustomerPicture = "./images/cus_profile/".$databaseProfilePicture;
						if(!unlink($documentCustomerPicture)){
							echo
							"
							<script>
							alert('Fail to delete the old profile picture file!');
							document.location.href='user_profile.php';
							</script>
							";
							exit();
						}else{
							$newPictureName = "cpicture".$id.".".$pictureActualExtension;
							$pictureLocation = "./images/cus_profile/".$newPictureName;
							if(move_uploaded_file($pictureTmpName, $pictureLocation)){
							$sql =  "UPDATE customer SET customer_profile_picture= '".$newPictureName."' WHERE customer_id='".$id."' && customer_name ='".$name."' && customer_email= '".$email."';";
							if(mysqli_query($connect,$sql)){
								echo
								"
								<script>
								alert('Profile picture update success!');
								document.location.href='user_profile.php';
								</script>
								";
								exit();
							}else{
								echo
								"
								<script>
								alert('Profile picture upload success but failure to update the database!');
								document.location.href='user_profile.php';
								</script>
								";
								exit();
							}
							}else{
								echo
								"
								<script>
								alert('Profile picture upload fails!');
								document.location.href='user_profile.php';
								</script>
								";
								exit();
							}
						}
					}
				}else{
					echo
					"
					<script>
					alert('Fail to check the database customer profile picture!');
					document.location.href='user_profile.php';
					</script>
					";
					exit();
				}

			}else{
				echo
				"
				<script>
				alert('The profile picture cannot be bigger than 1000000B, 1000KB, or 1MB!');
				document.location.href='user_profile.php';
				</script>
				";
				exit();
			}
		}else{
			echo
			"
			<script>
			alert('Profile picture upload fails!');
			document.location.href='user_profile.php';
			</script>
			";
			exit();
		}
	}else{
		echo
		"
		<script>
		alert('The profile picture type only accepts jpg, jpeg, and png!');
		document.location.href='user_profile.php';
		</script>
		";
		exit();
	}
}else{
	echo
	"
	<script>
	alert('Please select your profile picture to upload!');
	document.location.href='user_profile.php';
	</script>
	";
	exit();
}

}

<?php
session_start();
require_once 'dataconnection.php';
if(!isset($_SESSION['id']) || !isset($_SESSION['name']) || !isset($_SESSION['email']) || !isset($_SESSION['vemail'])){
	echo "<script>window.location.href='clogin.php';</script>";
 }else if(isset($_SESSION['id']) &&  isset($_SESSION['name']) && isset($_SESSION['email']) && isset($_SESSION['vemail'])){
	   $vemail = $_SESSION['vemail'];
	   if($vemail == false){
		echo "<script>window.location.href='sentOTP.php';</script>";
		  exit();
	   }
	}
	if(isset($_SESSION["rname"]))
    {
      unset($_SESSION["rname"]);
    }
    if(isset($_SESSION["remail"]))
    {
      unset($_SESSION["remail"]);
    }
    if(isset($_SESSION["rhp"]))
    {
      unset($_SESSION["rhp"]);
    }
	if(isset($_SESSION["padd1"]))
    {
      unset($_SESSION["padd1"]);
    }
    if(isset($_SESSION["padd2"]))
    {
      unset($_SESSION["padd2"]);
    }
    if(isset($_SESSION["pst"]))
    {
      unset($_SESSION["pst"]);
    }
    if(isset($_SESSION["ppc"]))
    {
      unset($_SESSION["ppc"]);
    }
    if(isset($_SESSION["pct"]))
    {
      unset($_SESSION["pct"]);
    }
    if(isset($_SESSION["ptype"]))
    {
      unset($_SESSION["ptype"]);
    }
    /*if(isset($_SESSION["payment_method"]))
    {
      unset($_SESSION["payment_method"]);
    }*/
    if(isset($_SESSION["cardtype"]))
    {
      unset($_SESSION["cardtype"]);
    }
    if(isset($_SESSION["holder_name"]))
    {
      unset($_SESSION["holder_name"]);
    }
    if(isset($_SESSION["cardnum"]))
    {
      unset($_SESSION["cardnum"]);
    }
    if(isset($_SESSION["cardvv"]))
    {
      unset($_SESSION["cardvv"]);
    }
    if(isset($_SESSION["carddate"]))
    {
      unset($_SESSION["carddate"]);
    }
    /*if(isset($_SESSION["ewallet_types"]))
    {
      unset($_SESSION["ewallet_types"]);
    }
    if(isset($_SESSION["transaction_no"]))
    {
      unset($_SESSION["transaction_no"]);
    }*/
    if(isset($_SESSION["address1"]))
    {
      unset($_SESSION["address1"]);
    }
    if(isset($_SESSION["address2"]))
    {
      unset($_SESSION["address2"]);
    }
    if(isset($_SESSION["city"]))
    {
      unset($_SESSION["city"]);
    }
    if(isset($_SESSION["state"]))
    {
      unset($_SESSION["state"]);
    }
    if(isset($_SESSION["postcode"]))
    {
      unset($_SESSION["postcode"]);
    }
?>
<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Add Address</title>
	<link rel="stylesheet" href="formstyle.css">
    <meta name="format-detection" content="telephone=no">
	    <meta name="apple-mobile-web-app-capable" content="yes">
	    <meta name="author" content="">
	    <meta name="keywords" content="">
	    <meta name="description" content="">

	    <link rel="stylesheet" type="text/css" href="css/normalize.css">
	    <link rel="stylesheet" type="text/css" href="icomoon/icomoon.css">
	    <link rel="stylesheet" type="text/css" href="css/vendor.css">
	    <link rel="stylesheet" type="text/css" href="style.css">
		<!-- script
		================================================== -->
		<script src="http://translate.google.com/translate_a/element.js?cb=loadGoogleTranslate"></script>
		<script src="js/modernizr.js">
			function handle_keyup(event){
				if (event.keyCode === 13) {
                   document.getElementById('search_btn').click();
                }
			}
		</script>
		<script style="text/javascript">
		  function loadGoogleTranslate() {
    const defaultLanguage = "en";

    const translateElement = new google.translate.TranslateElement({
      pageLanguage: defaultLanguage,
      includedLanguages: "en,ms,zh-CN",
      layout: google.translate.TranslateElement.InlineLayout.SIMPLE
    }, "google_element");

    // Get the language select dropdown element
    const languageSelect = document.getElementById("languageSelect");

    // Function to set a cookie
    function setCookie(name, value, days) {
      const expires = new Date();
      expires.setTime(expires.getTime() + days * 24 * 60 * 60 * 1000);
      document.cookie = `${name}=${value};expires=${expires.toUTCString()};path=/`;
    }

    // Function to get a cookie value
    function getCookie(name) {
      const cookieName = `${name}=`;
      const cookies = document.cookie.split(';');
      for (let i = 0; i < cookies.length; i++) {
        let cookie = cookies[i];
        while (cookie.charAt(0) === ' ') {
          cookie = cookie.substring(1);
        }
        if (cookie.indexOf(cookieName) === 0) {
          return cookie.substring(cookieName.length, cookie.length);
        }
      }
      return null;
    }

    // Set the initial language selection
    const storedLanguage = getCookie("selectedLanguage");
    if (storedLanguage) {
      languageSelect.value = storedLanguage;
      translateElement.update({
        includedLanguages: storedLanguage
      });
    }

    // Add event listener for change event
    languageSelect.addEventListener("change", function() {
      const selectedLanguage = this.value;
      translateElement.update({
        includedLanguages: selectedLanguage
      });
      setCookie("selectedLanguage", selectedLanguage, 30); // Set the cookie for 30 days
    });
  }
		</script>

</head>

<body>
<div id="header-wrap">

<div class="top-content">
	<div class="container">
		<div class="row">
		<div class="col-md-6" style="width: 25%;">

			</div>
			<div class="col-md-6" style="width: 75%;">
				<div class="right-element">

					<?php
					if(isset($_SESSION['id']) &&  isset($_SESSION['name']) && isset($_SESSION['email']) && isset($_SESSION['vemail'])){
						$vemail = $_SESSION['vemail'];
						if($vemail == false){
							echo "<script>window.location.href='sentOTP.php';</script>";
							exit();
						}
						// else{
						// 	header("Location:./index.php");
						// 	exit();
						// }
					}
					if(isset($_SESSION["id"]))
					{   $cust_id=$_SESSION["id"];
						$cartsql="SELECT * FROM cart WHERE customer_id=$cust_id";
						$run_cartsql=mysqli_query($connect, $cartsql);
						$num_rows_cartsql=mysqli_num_rows($run_cartsql);
						$rows_cartsql=mysqli_fetch_assoc($run_cartsql);
						if($num_rows_cartsql==0)
						{
							$cartitem_rows=0;
						}
						else
						{   $cartid=$rows_cartsql["cart_id"];
							$cartitemsql="SELECT * FROM cart_item WHERE cart_id=$cartid";
							$run_cartitemsql=mysqli_query($connect, $cartitemsql);
							$cartitem_rows=mysqli_num_rows($run_cartitemsql);
							$del_val=0;
							while($rows_cartitemsql=mysqli_fetch_assoc($run_cartitemsql))
							{
							  $prodid=$rows_cartitemsql["product_id"];
							  $itemqty=$rows_cartitemsql["item_quantity"];
							  $stocksql="SELECT * FROM stock WHERE product_id='$prodid'";
							  $run_stocksql=mysqli_query($connect, $stocksql);
							  $stockrows=mysqli_fetch_assoc($run_stocksql);
							  $stocklevel=$stockrows['stock_level'];
							  $prodsql="SELECT * FROM product WHERE product_id='$prodid' AND availability=0";
							  $run_prodsql=mysqli_query($connect, $prodsql);
							  $prodrows=mysqli_num_rows($run_prodsql);
							  if($prodrows==0)
							  {
								$del_cartitem="DELETE FROM cart_item WHERE cart_id=$cartid AND product_id='$prodid'";
								$run_del_cartitem=mysqli_query($connect, $del_cartitem);
								if($run_del_cartitem)
								  $del_val++;
							  }
							  else if($stocklevel==0)
							  {
								$del_cartitem="DELETE FROM cart_item WHERE cart_id=$cartid AND product_id='$prodid'";
								$run_del_cartitem=mysqli_query($connect, $del_cartitem);
								if($run_del_cartitem)
								  $del_val++;
							  }
							  else if($itemqty>$stocklevel)
							  {
								$update_cartitem="UPDATE cart_item SET item_quantity=$stocklevel WHERE cart_id=$cartid AND product_id='$prodid'";
								$run_update_cartitem=mysqli_query($connect, $update_cartitem);
							  }
							}
							if($del_val==$cartitem_rows)
							{
								$del_cart="DELETE FROM cart WHERE cart_id=$cartid";
								$run_del_cart=mysqli_query($connect, $del_cart);
							}
							$cartitem_rows-=$del_val;
						}
						$select_cust="SELECT * FROM customer WHERE customer_id=$cust_id";
						$run_select_cust=mysqli_query($connect, $select_cust);
						$row_select_cust=mysqli_fetch_assoc($run_select_cust);
						$user_profile=$row_select_cust["customer_profile_picture"];
						?>
						<a href="cart.php" class="cart for-buy"><img src="images/icon/carts.png" style="width: 50px; height: 50px; opacity: 70%; margin-bottom: 5px;"><span>Cart: <?php echo $cartitem_rows; ?> item(s)</span></a>
						<a href="order_history.php" class="cart for-buy"><i class="icon icon-clipboard"></i> <span>Order History</span></a>
					<nav id="navbar" style="display: inline-block; margin-left: -40px; position: relative; z-index: 3;">
					<div class="main-menu stellarnav">
					<ul class="menu-list">
					<li class="menu-item has-sub">
					<a href="./user_profile.php" class="nav-link" data-effect="Pages"><img src="images/cus_profile/<?php echo $user_profile; ?>" style="width: 40px; height: 40px; border-radius: 50%; margin-right: 10px;" alt="user_profile" title="user_profile">Account</a>
						<ul style="font-size: 16px;">
							<li><a href="./user_profile.php">My Profile</a></li>
							<li><a href="./logoutaction.php">Logout</a></li>
						 </ul>
					</li>
					</ul>
					</div>
					</nav>
					<?php
					}
					else
					{?><i class="icon icon-user"></i> <span>
					   <a href="./clogin.php">Login</a> | <a href="./cregister.php">Register</a>
					</span>
					<?php
					}?>

					<div class="action-menu" style="margin-left: 10px;">

						<div class="search-bar">
							<a href="#" class="search-button search-toggle" data-selector="#header-wrap">
								<i class="icon icon-search"></i>
							</a>
							<form role="search" method="get" class="search-box" action="search_products.php">
								<input class="search-field text search-input" placeholder="Search products" type="text" name="search_keyword" onkeyup="handle_keyup(event)">
								<input type="submit" id="search_btn" style="display: none;">
							</form>
						</div>
					</div>
					<div id="google_element" style="display: inline-block;"></div>
				</div><!--top-right-->
			</div>

		</div>
	</div>
</div><!--top-content-->

<header id="header" style="background-color: #f3e7be;">
	<div class="container">
		<div class="row">

			<div class="col-md-2">
				<!--<div class="main-logo">-->
					<a href="index.php"><img src="images/icon/logo.png" alt="logo" style="height: 140px; margin:-60px 0px -30px 0px;"></a>
				<!--</div>-->
			</div>

			<div class="col-md-10">

				<nav id="navbar" style="position: relative; z-index: 1;">
					<div class="main-menu stellarnav">
						<ul class="menu-list">
							<li class="menu-item"><a href="index.php" data-effect="Home" style="font-size: 17px;">Home</a></li>
							<li class="menu-item active"><a href="about_us.php" class="nav-link" data-effect="About" style="font-size: 17px;">About</a></li>
							<!--<li class="menu-item has-sub">
								<a href="#pages" class="nav-link" data-effect="Pages">Pages</a>

								<ul>
									<li><a href="styles.html">Styles</a></li>
									<li><a href="blog.html">Blog</a></li>
									<li><a href="single-post.html">Post Single</a></li>
									<li><a href="shop.php">Products</a></li>
									<li><a href="thank-you.html">Thank You</a></li>
								 </ul>

							</li>-->
							<li class="menu-item"><a href="shop.php" class="nav-link" data-effect="Shop" style="font-size: 17px;">Shop</a></li>
							<li class="menu-item"><a href="contact.php" class="nav-link" data-effect="Contact" style="font-size: 17px;">Contact Us</a></li>
						</ul>

						<div class="hamburger">
							<span class="bar"></span>
							<span class="bar"></span>
							<span class="bar"></span>
						</div>

					</div>
				</nav>

			</div>

		</div>
	</div>
</header>
	<form action="addaddreaction.php" method="post" style="border:1px solid #ccc">
		<div class="container">
			<h1>Add new address</h1>
			<p>Please fill in this form to add your address.</p>
<!--		//error handling message-->
<?php
		if(!isset($_GET['status'])){

		}else if(isset($_GET['status'])){
			$status = $_GET['status'];
			//all empty
			if($status == "emptyinput"){
				echo '<h1 style="color:red;">Please enter all inputs! &#128581;&#8205;&#9794;&#65039;</h1>';
			}
			//all invalid input
			else if($status == "invalidinput"){
				echo '<h1 style="color:red;">Please enter all inputs in the correct format! &#128581;&#8205;&#9794;&#65039;</h1>';
			}
			//add success
			else if($status == "addsuccess"){
				// echo '<script>alert("Address added!");
				// 							window.location.href="user_profile.php";</script>';
			}
			//postCode invalid
			else if($status == "invalidpostalCode"){
				echo '<h1 style="color:red;">Invalid postal code! &#128581;&#8205;&#9794;&#65039;</h1>';
			}
			//invalid state
			else if($status == "invalidstate"){
				echo '<h1 style="color:red;">Invalid state! &#128581;&#8205;&#9794;&#65039;</h1>';
			}
			//invalid city
			else if($status == "invalidcity"){
				echo '<h1 style="color:red;">Invalid city! &#128581;&#8205;&#9794;&#65039;</h1>';
			}

			//adderess 2 invalid
			else if($status == "invalidadd2"){
				echo '<h1 style="color:red;">Invalid address2! &#128581;&#8205;&#9794;&#65039;</h1>';
			}

			//address 1 invalid
			else if($status == "invalidadd1"){
				echo '<h1 style="color:red;">Invalid address1! &#128581;&#8205;&#9794;&#65039;</h1>';
			}


			//invalid postal code and state
			else if($status == "postcodeandstate"){
				echo '<h1 style="color:red;">Invalid state and postal code! &#128581;&#8205;&#9794;&#65039;</h1>';
			}
			//invalid postal code and city
			else if($status == "postcodeandcity"){
				echo '<h1 style="color:red;">Invalid city and postal code! &#128581;&#8205;&#9794;&#65039;</h1>';
			}
			//invalid postal code and add2
			else if($status == "postcodeandadd2"){
				echo '<h1 style="color:red;">Invalid address2 and postal code! &#128581;&#8205;&#9794;&#65039;</h1>';
			}
			//invalid postal code and add1
			else if($status == "postcodeandadd1"){
				echo '<h1 style="color:red;">Invalid address1 and postal code! &#128581;&#8205;&#9794;&#65039;</h1>';
			}

			//invalid city and state
			else if($status == "stateandcity"){
				echo '<h1 style="color:red;">Invalid city and state! &#128581;&#8205;&#9794;&#65039;</h1>';
			}
			//invalid add1 and state
			else if($status == "stateandadd1"){
				echo '<h1 style="color:red;">Invalid address1 and state! &#128581;&#8205;&#9794;&#65039;</h1>';
			}
			//invalid add2 and state
			else if($status == "stateandadd2"){
				echo '<h1 style="color:red;">Invalid address2 and state! &#128581;&#8205;&#9794;&#65039;</h1>';
			}

			//invalid add 1 and add 2
			else if($status == "add1andadd2"){
				echo '<h1 style="color:red;">Invalid address1 and address2! &#128581;&#8205;&#9794;&#65039;</h1>';
			}
			//invalid add 1 and city
			else if($status == "add1andcity"){
				echo '<h1 style="color:red;">Invalid address1 and city! &#128581;&#8205;&#9794;&#65039;</h1>';
			}
			// invalid add 2 and city
			else if($status == "add2andcity"){
				echo '<h1 style="color:red;">Invalid address2 and city! &#128581;&#8205;&#9794;&#65039;</h1>';
			}

			//invalid add1 add2 city
			else if($status == "add1add2andcity"){
				echo '<h1 style="color:red;">Invalid address1, adderss2 and city! &#128581;&#8205;&#9794;&#65039;</h1>';
			}
			//invalid  add1 add2 state
			else if($status == "add1add2andstate"){
				echo '<h1 style="color:red;">Invalid address1, adderess2 and state! &#128581;&#8205;&#9794;&#65039;</h1>';
			}
			//invalid add1 add2 postal code
			else if($status == "add1add2andpostCode"){
				echo '<h1 style="color:red;">Invalid address1, adderss2 and postal code! &#128581;&#8205;&#9794;&#65039;</h1>';
			}
			//invalid add1 city state
			else if($status == "add1cityandstate"){
				echo '<h1 style="color:red;">Invalid address1, city and state! &#128581;&#8205;&#9794;&#65039;</h1>';
			}
			//invalid add1 city postal code
			else if($status == "add1cityandpostCode"){
				echo '<h1 style="color:red;">Invalid address1,city and postal code! &#128581;&#8205;&#9794;&#65039;</h1>';
			}
			//invalid add1 state postal code
			else if($status == "add1stateandpostCode"){
				echo '<h1 style="color:red;">Invalid address1, state and postal code! &#128581;&#8205;&#9794;&#65039;</h1>';
			}
			//invalid add2 city state
			else if($status == "add2cityandstate"){
				echo '<h1 style="color:red;">Invalid address2, city and state! &#128581;&#8205;&#9794;&#65039;</h1>';
			}
			//invalid add2 city postal code
			else if($status == "add2cityandpostCode"){
				echo '<h1 style="color:red;">Invalid address2, city and postal code! &#128581;&#8205;&#9794;&#65039;</h1>';
			}
			//invalid add2 state postal code
			else if($status == "add2stateandpostCode"){
				echo '<h1 style="color:red;">Invalid address2, state and postal code! &#128581;&#8205;&#9794;&#65039;</h1>';
			}
			//invalid city state and postal code
			else if($status == "citystateandpostCode"){
				echo '<h1 style="color:red;">Invalid city, state and postal code! &#128581;&#8205;&#9794;&#65039;</h1>';
			}
			//not check yet
			//only add1
			else if($status == "onlyadd1"){
				echo '<h1 style="color:red;">Invalid address2, city, state and postal code! &#128581;&#8205;&#9794;&#65039;</h1>';
			}
			//only add2
			else if($status == "onlyadd2"){
				echo '<h1 style="color:red;">Invalid address1, city, state and postal code! &#128581;&#8205;&#9794;&#65039;</h1>';
			}
			//only city
			else if($status == "onlycity"){
				echo '<h1 style="color:red;">Invalid address1, address2, state and postal code! &#128581;&#8205;&#9794;&#65039;</h1>';
			}
			//only state
			else if($status == "onlystate"){
				echo '<h1 style="color:red;">Invalid address1, address2, city and postal code! &#128581;&#8205;&#9794;&#65039;</h1>';
			}
			//only postal code
			else if($status == "onlypostCode"){
				echo '<h1 style="color:red;">Invalid address1, address2, city, and state! &#128581;&#8205;&#9794;&#65039;</h1>';
			}

			//sql error
			else if($status == "sqlerror"){
				  echo '<h1 style="color:red;">Sorry, add new address got trouble. &#128581;&#8205;&#9794;&#65039;</h1>';
			}





		}
?>
			<hr>

			<label for="address1"><b>Address1</b></label>
			<?php
			if(isset($_GET['add1'])){
				$add1 = $_GET['add1'];
				echo '<input type="text" placeholder="Enter Address1" name="address1" id="address1" value="'.$add1.'" required>';
			}else{
				echo '<input type="text" placeholder="Enter Address1" name="address1" id="address1" required>';
			}
			?>


			<label for="psw"><b>Address2</b></label>
			<?php
			if(isset($_GET['add2'])){
				$add2 = $_GET['add2'];
				echo '<input type="text" placeholder="Enter Address2" name="address2" id="address2" value="'.$add2.'" required>';
			}else{
				echo '<input type="text" placeholder="Enter Address2" name="address2" id="address2" required>';
			}
			?>


			<label for="city"><b>City</b></label>
			<?php
				if(isset($_GET['city'])){
					$city = $_GET['city'];
					echo '<input type="text" placeholder="Enter City" name="city" id="city" value="'.$city.'" required>';
				}else{
					echo '<input type="text" placeholder="Enter City" name="city" id="city" required>';
				}
			?>


			<label for="state"><b>State</b></label>
				<select class="selection" name="state" id="state" style="height: 50px; required>
			<?php
			if(isset($_GET['state'])){
				$state = $_GET['state'];
				if($state == ""){
					echo '
					<option value="" selected>Empty</option>
					<option value="Johor">Johor</option>
					<option value="Kedah">Kedah</option>
					<option value="Kelantan">Kelantan</option>
					<option value="Melaka">Melaka</option>
					<option value="Negeri Sembilan">Negeri Sembilan</option>
					<option value="Pahang">Pahang</option>
					<option value="Penang">Penang</option>
					<option value="Perak">Perak</option>
					<option value="Perlis">Perlis</option>
					<option value="Sabah">Sabah</option>
					<option value="Sarawak">Sarawak</option>
					<option value="Selangor">Selangor</option>
					<option value="Terengganu">Teregganu</option>
					';
				}else if($state == "Johor"){
					echo '
					<option value="">Empty</option>
					<option value="Johor" selected>Johor</option>
					<option value="Kedah">Kedah</option>
					<option value="Kelantan">Kelantan</option>
					<option value="Melaka">Melaka</option>
					<option value="Negeri Sembilan">Negeri Sembilan</option>
					<option value="Pahang">Pahang</option>
					<option value="Penang">Penang</option>
					<option value="Perak">Perak</option>
					<option value="Perlis">Perlis</option>
					<option value="Sabah">Sabah</option>
					<option value="Sarawak">Sarawak</option>
					<option value="Selangor">Selangor</option>
					<option value="Terengganu">Teregganu</option>
					';
				}else if($state == "Kedah"){
					echo '
					<option value="">Empty</option>
					<option value="Johor">Johor</option>
					<option value="Kedah" selected>Kedah</option>
					<option value="Kelantan">Kelantan</option>
					<option value="Melaka">Melaka</option>
					<option value="Negeri Sembilan">Negeri Sembilan</option>
					<option value="Pahang">Pahang</option>
					<option value="Penang">Penang</option>
					<option value="Perak">Perak</option>
					<option value="Perlis">Perlis</option>
					<option value="Sabah">Sabah</option>
					<option value="Sarawak">Sarawak</option>
					<option value="Selangor">Selangor</option>
					<option value="Terengganu">Teregganu</option>
					';
				}else if($state == "Kelantan"){
					echo '
					<option value="">Empty</option>
					<option value="Johor">Johor</option>
					<option value="Kedah">Kedah</option>
					<option value="Kelantan" selected>Kelantan</option>
					<option value="Melaka">Melaka</option>
					<option value="Negeri Sembilan">Negeri Sembilan</option>
					<option value="Pahang">Pahang</option>
					<option value="Penang">Penang</option>
					<option value="Perak">Perak</option>
					<option value="Perlis">Perlis</option>
					<option value="Sabah">Sabah</option>
					<option value="Sarawak">Sarawak</option>
					<option value="Selangor">Selangor</option>
					<option value="Terengganu">Teregganu</option>
					';
				}else if($state == "Melaka"){
					echo '
					<option value="">Empty</option>
					<option value="Johor">Johor</option>
					<option value="Kedah">Kedah</option>
					<option value="Kelantan">Kelantan</option>
					<option value="Melaka" selected>Melaka</option>
					<option value="Negeri Sembilan">Negeri Sembilan</option>
					<option value="Pahang">Pahang</option>
					<option value="Penang">Penang</option>
					<option value="Perak">Perak</option>
					<option value="Perlis">Perlis</option>
					<option value="Sabah">Sabah</option>
					<option value="Sarawak">Sarawak</option>
					<option value="Selangor">Selangor</option>
					<option value="Terengganu">Teregganu</option>
					';
				}else if($state == "Negeri Sembilan"){
					echo '
					<option value="">Empty</option>
					<option value="Johor">Johor</option>
					<option value="Kedah">Kedah</option>
					<option value="Kelantan">Kelantan</option>
					<option value="Melaka">Melaka</option>
					<option value="Negeri Sembilan" selected>Negeri Sembilan</option>
					<option value="Pahang">Pahang</option>
					<option value="Penang">Penang</option>
					<option value="Perak">Perak</option>
					<option value="Perlis">Perlis</option>
					<option value="Sabah">Sabah</option>
					<option value="Sarawak">Sarawak</option>
					<option value="Selangor">Selangor</option>
					<option value="Terengganu">Teregganu</option>
					';
				}else if($state == "Pahang"){
					echo '
					<option value="">Empty</option>
					<option value="Johor">Johor</option>
					<option value="Kedah">Kedah</option>
					<option value="Kelantan">Kelantan</option>
					<option value="Melaka">Melaka</option>
					<option value="Negeri Sembilan">Negeri Sembilan</option>
					<option value="Pahang" selected>Pahang</option>
					<option value="Penang">Penang</option>
					<option value="Perak">Perak</option>
					<option value="Perlis">Perlis</option>
					<option value="Sabah">Sabah</option>
					<option value="Sarawak">Sarawak</option>
					<option value="Selangor">Selangor</option>
					<option value="Terengganu">Teregganu</option>
					';
				}else if($state == "Penang"){
					echo '
					<option value="">Empty</option>
					<option value="Johor">Johor</option>
					<option value="Kedah">Kedah</option>
					<option value="Kelantan">Kelantan</option>
					<option value="Melaka">Melaka</option>
					<option value="Negeri Sembilan">Negeri Sembilan</option>
					<option value="Pahang">Pahang</option>
					<option value="Penang" selected>Penang</option>
					<option value="Perak">Perak</option>
					<option value="Perlis">Perlis</option>
					<option value="Sabah">Sabah</option>
					<option value="Sarawak">Sarawak</option>
					<option value="Selangor">Selangor</option>
					<option value="Terengganu">Teregganu</option>
					';
				}else if($state == "Perak"){
					echo '
					<option value="">Empty</option>
					<option value="Johor">Johor</option>
					<option value="Kedah">Kedah</option>
					<option value="Kelantan">Kelantan</option>
					<option value="Melaka">Melaka</option>
					<option value="Negeri Sembilan">Negeri Sembilan</option>
					<option value="Pahang">Pahang</option>
					<option value="Penang">Penang</option>
					<option value="Perak" selected>Perak</option>
					<option value="Perlis">Perlis</option>
					<option value="Sabah">Sabah</option>
					<option value="Sarawak">Sarawak</option>
					<option value="Selangor">Selangor</option>
					<option value="Terengganu">Teregganu</option>
					';
				}else if($state == "Perlis"){
					echo '
					<option value="">Empty</option>
					<option value="Johor">Johor</option>
					<option value="Kedah">Kedah</option>
					<option value="Kelantan">Kelantan</option>
					<option value="Melaka">Melaka</option>
					<option value="Negeri Sembilan">Negeri Sembilan</option>
					<option value="Pahang">Pahang</option>
					<option value="Penang">Penang</option>
					<option value="Perak">Perak</option>
					<option value="Perlis" selected>Perlis</option>
					<option value="Sabah">Sabah</option>
					<option value="Sarawak">Sarawak</option>
					<option value="Selangor">Selangor</option>
					<option value="Terengganu">Teregganu</option>
					';
				}else if($state == "Sabah"){
					echo '
					<option value="">Empty</option>
					<option value="Johor">Johor</option>
					<option value="Kedah">Kedah</option>
					<option value="Kelantan">Kelantan</option>
					<option value="Melaka">Melaka</option>
					<option value="Negeri Sembilan">Negeri Sembilan</option>
					<option value="Pahang">Pahang</option>
					<option value="Penang">Penang</option>
					<option value="Perak">Perak</option>
					<option value="Perlis">Perlis</option>
					<option value="Sabah" selected>Sabah</option>
					<option value="Sarawak">Sarawak</option>
					<option value="Selangor">Selangor</option>
					<option value="Terengganu">Teregganu</option>
					';
				}else if($state == "Sarawak"){
					echo '
					<option value="">Empty</option>
					<option value="Johor">Johor</option>
					<option value="Kedah">Kedah</option>
					<option value="Kelantan">Kelantan</option>
					<option value="Melaka">Melaka</option>
					<option value="Negeri Sembilan">Negeri Sembilan</option>
					<option value="Pahang">Pahang</option>
					<option value="Penang">Penang</option>
					<option value="Perak">Perak</option>
					<option value="Perlis">Perlis</option>
					<option value="Sabah">Sabah</option>
					<option value="Sarawak" selected>Sarawak</option>
					<option value="Selangor">Selangor</option>
					<option value="Terengganu">Teregganu</option>
					';
				}else if($state == "Selangor"){
					echo '
					<option value="">Empty</option>
					<option value="Johor">Johor</option>
					<option value="Kedah">Kedah</option>
					<option value="Kelantan">Kelantan</option>
					<option value="Melaka">Melaka</option>
					<option value="Negeri Sembilan">Negeri Sembilan</option>
					<option value="Pahang">Pahang</option>
					<option value="Penang">Penang</option>
					<option value="Perak">Perak</option>
					<option value="Perlis">Perlis</option>
					<option value="Sabah">Sabah</option>
					<option value="Sarawak">Sarawak</option>
					<option value="Selangor" selected>Selangor</option>
					<option value="Terengganu">Teregganu</option>
					';
				}else if($state == "Terengganu"){
					echo '
					<option value="">Empty</option>
					<option value="Johor">Johor</option>
					<option value="Kedah">Kedah</option>
					<option value="Kelantan">Kelantan</option>
					<option value="Melaka">Melaka</option>
					<option value="Negeri Sembilan">Negeri Sembilan</option>
					<option value="Pahang">Pahang</option>
					<option value="Penang">Penang</option>
					<option value="Perak">Perak</option>
					<option value="Perlis">Perlis</option>
					<option value="Sabah">Sabah</option>
					<option value="Sarawak">Sarawak</option>
					<option value="Selangor">Selangor</option>
					<option value="Terengganu" selected>Teregganu</option>
					';
				}
			}else{
				echo '
				<option value="" selected>Empty</option>
				<option value="Johor">Johor</option>
				<option value="Kedah">Kedah</option>
				<option value="Kelantan">Kelantan</option>
				<option value="Melaka">Melaka</option>
				<option value="Negeri Sembilan">Negeri Sembilan</option>
				<option value="Pahang">Pahang</option>
				<option value="Penang">Penang</option>
				<option value="Perak">Perak</option>
				<option value="Perlis">Perlis</option>
				<option value="Sabah">Sabah</option>
				<option value="Sarawak">Sarawak</option>
				<option value="Selangor">Selangor</option>
				<option value="Terengganu">Teregganu</option>
				';
			}
			?>
			</select>

			<label for="postCode"><b>Postal Code</b></label>
			<?php
				if(isset($_GET['postCode'])){
					$postCode = $_GET['postCode'];
					echo '<input type="number" placeholder="Enter Postal Code" name="postCode" id="postCode" pattern="[0-9]{5}" value="'.$postCode.'" required max="99999">';
				}else{
					echo '<input type="number" placeholder="Enter Postal Code" name="postCode" id="postCode" pattern="[0-9]{5}" required max="99999">';
				}
			?>



			<br>


			<div class="clearfix">
			<button type="submit" class="signupbtn" name="addaddre">Add Address</button>
			<button type="button" class="cancelbtn" name="cancel" onclick="user_profile()">Cancel</button>

			</div>
		</div>
	</form>
	<footer id="footer" style="background-color: #f3e7be;">
	<div class="container">
		<div class="row">

			<div class="col-md-4" style="width: 40%;">

				<div class="footer-item">
					<div class="company-brand">
						<img src="images/icon/logo.png" alt="logo" class="footer-logo" style="height: 180px; width: 200px; margin-left: 70px;">
						<p>Welcome to Knowledge Bookstore, your gateway to a vast world of literary treasures, where words come alive and imagination knows no bounds.</p>
					</div>
				</div>

			</div>

			<div class="col-md-2" style="margin-top: 80px;">

				<div class="footer-menu">
					<h5><a href="about_us.php">About Us</a></h5>
					<ul class="menu-list">
						<li class="menu-item">
							Phone: 06 – 252 3253
						</li>
						<!--<li class="menu-item">
							<a href="#">articles </a>
						</li>
						<li class="menu-item">
							<a href="#">careers</a>
						</li>
						<li class="menu-item">
							<a href="#">service terms</a>
						</li>
						<li class="menu-item">
							<a href="#">donate</a>
						</li>-->
					</ul>
				</div>

			</div>
			<!--<div class="col-md-2">

				<div class="footer-menu">
					<h5>Discover</h5>
					<ul class="menu-list">
						<li class="menu-item">
							<a href="#">Home</a>
						</li>
						<li class="menu-item">
							<a href="#">Books</a>
						</li>
						<li class="menu-item">
							<a href="#">Authors</a>
						</li>
						<li class="menu-item">
							<a href="#">Subjects</a>
						</li>
						<li class="menu-item">
							<a href="#">Advanced Search</a>
						</li>
					</ul>
				</div>

			</div>-->
			<div class="col-md-2" style="padding-left: 30px; margin-top: 80px;">

				<div class="footer-menu">
					<h5>Quick Links</h5>
					<ul class="menu-list">
						<li class="menu-item">
							<a href="index.php">Home</a>
						</li>
						<li class="menu-item">
							<a href="shop.php">Shop</a>
						</li>
					</ul>
				</div>

			</div>
			<div class="col-md-2" style="padding-left: 100px; margin-top: 80px;">

				<div class="footer-menu">
					<h5>Services</h5>
					<ul class="menu-list">
						<!--<li class="menu-item">
							<a href="#">Help center</a>
						</li>
						<li class="menu-item">
							<a href="#">Report a problem</a>
						</li>
						<li class="menu-item">
							<a href="#">Suggesting edits</a>
						</li>-->
						<li class="menu-item">
							<a href="contact.php">Contact us</a>
						</li>
						<li class="menu-item">
							<a href="faq.php">FAQ</a>
						</li>
					</ul>
				</div>

			</div>

		</div>
		<!-- / row -->

	</div>
</footer>

<div id="footer-bottom">
	<div class="container">
		<div class="row">
			<div class="col-md-12">

				<div class="copyright">
					<div class="row">

						<div class="col-md-6">
							<p>© 2023 All rights reserved.</p>
						</div>

						<div class="col-md-6">

						</div>

					</div>
				</div><!--grid-->

			</div><!--footer-bottom-content-->
		</div>
	</div>
</div>

<script src="js/jquery-1.11.0.min.js"></script>
<script src="js/plugins.js"></script>
<script src="js/script.js"></script>
	<script type="text/javascript">

		function user_profile(){
			window.location.href="./user_profile.php";
		}

	</script>
</body>

</html>

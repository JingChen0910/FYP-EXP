<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Recovery Password OTP</title>
	<link rel="stylesheet" href="formstyle.css">
</head>

<body>
	<form action="OTPcheckRecovery.php" method="post" style="border:1px solid #ccc">
		<div class="container">
			<h1>Recovery Password OTP</h1>
			<p>Please fill in this form to recover your password.</p>
			<p style="color:red;">The OTP will expire in 5 minutes.</p>
			<?php
			/*
			emptyinput
newpassrisnotsamewithnewpass
sqlerror
incorrectotp
ALLinvalid
invalidotp
invalidnewpass
invalidnewpassr
invalidnewpassandnewpassr
invalidotpandnewpassr
invalidotpandnewpass
			*/
			if(isset($_GET['status'])){
				$status = $_GET['status'];
				if($status == "emptyinput"){
					echo '<h1 style="color:red;">Please enter all inputs! &#128581;&#8205;&#9794;&#65039;</h1>';
				}else if($status == "newpassrisnotsamewithnewpass"){
		echo '<h1 style="color:red;">The confirm new password does not match the new password! &#128581;&#8205;&#9794;&#65039;</h1>';
				}else if($status == "sqlerror"){
  echo '<h1 style="color:red;">Sorry, recovery password got trouble. &#129301;</h1>';
				}else if($status == "incorrectotp"){
	echo '<h1 style="color:red;">Incorrect OTP! &#128581;&#8205;&#9794;&#65039;</h1>';
				}else if($status == "invalidnewpass"){
	echo '<h1 style="color:red;">Invalid new password! &#128581;&#8205;&#9794;&#65039;</h1>';
				}else if($status == "invalidnewpassandnewpassr"){
	echo '<h1 style="color:red;">Invalid new password and comfirm new password! &#128581;&#8205;&#9794;&#65039;</h1>';
				}
				else if($status == "invalidotpandnewpassr"){
	echo '<h1 style="color:red;">Invalid OTP and comfirm new password! &#128581;&#8205;&#9794;&#65039;</h1>';
				}
				else if($status == "invalidotpandnewpass"){
	echo '<h1 style="color:red;">Invalid OTP and new password! &#128581;&#8205;&#9794;&#65039;</h1>';
				}
				else if($status == "ALLinvalid"){
	echo '<h1 style="color:red;">Please enter all inputs in the correct format! &#128581;&#8205;&#9794;&#65039;</h1>';
}else if($status == "invalidotp"){
	echo '<h1 style="color:red;">Invalid OTP! &#128581;&#8205;&#9794;&#65039;</h1>';
				}
				else if($status == "invalidnewPassR"){
					echo '<h1 style="color:red;">Invalid comfirm new password! &#128581;&#8205;&#9794;&#65039;</h1>';
								}




			}

			?>
			<hr>

			<label for="otp"><b>Recovery Password OTP</b></label>
			<input type="number" placeholder="Enter OTP" name="otp" id="otp" min="0" required>

      <label for="psw-repeat"><b>New Password (Password must be at least 12 characters long, and it must include at least one uppercase, lowercase,special chracter, and numeric)</b></label>
      <input type="password" placeholder="Enter New Password" name="newPass" id="psw2" required>

      <label for="show2">
        <input type="checkbox" onclick="showPassword2()" name="show" id="show2" style="margin-bottom:15px">Show New Password
      </label>

      <br>
  		<br>

      <label for="psw-repeat"><b>Comfirm New Password</b></label>
      <input type="password" placeholder="Repeat New Password" name="newPassR" id="psw3" required>

      <label for="show3">
        <input type="checkbox" onclick="showPassword3()" name="show" id="show3" style="margin-bottom:15px">Show Repeat New Password
      </label>




			<div class="clearfix">

				<button type="submit" class="signupbtn" name="otp-check">Submit</button>
            <button type="button" class="cancelbtn" name="cancel" onclick="recovery1()">Cancel</button>
			</div>

		</div>
	</form>
  <script type="text/javascript">
    function showPassword2() {
      var show2 = document.getElementById("psw2");
      if (show2.type == "password") {
        show2.type = "text";
      } else if(show2.type == "text"){
        show2.type = "password";
      }
    }
    function showPassword3() {
      var show3 = document.getElementById("psw3");
      if (show3.type == "password") {
        show3.type = "text";
      } else if(show3.type == "text"){
        show3.type = "password";
      }
    }
    function recovery1(){
      window.location.href="./recovery1.php";
    }
  </script>
</body>

</html>
<?php

    if(isset($_POST['otp-check'])){
      session_start();
			require_once 'dataconnection.php';

			if(time() <= $_SESSION['vExpiredTime']){
				$otp = mysqli_real_escape_string($connect,$_POST['otp']);
        $newPass = mysqli_real_escape_string($connect,$_POST['newPass']);
        $newPassR = mysqli_real_escape_string($connect,$_POST['newPassR']);
				if(empty($otp) || empty($newPass) || empty(  $newPassR) ){
						header("Location:./OTPcheckRecovery.php?status=emptyinput");
						exit();
				}else{

						$vOTP = preg_match('/^\d{6}$/',$otp);
              $vNewPass = preg_match('/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^\w\s]).{12,}$/',$newPass);
                $vNewPassR = preg_match('/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^\w\s]).{12,}$/',$newPassR);
								//ALL valid
							if($vOTP && $vNewPass && $vNewPassR){
									// header("Location:./recovery1.php?success");
									if(password_verify($otp,$_SESSION['OTP'])){
										if($newPassR != $newPass){
												//new passwrod repeat is not same with new password
												header("Location:./OTPcheckRecovery.php?status=newpassrisnotsamewithnewpass");
												exit();
										}else{
											//new pass r same with new pass
											$sql = "UPDATE customer SET customer_password = ? WHERE customer_email = ?";
											$stmt = mysqli_stmt_init($connect);
											if(!mysqli_stmt_prepare($stmt,$sql)){
												header("Location:./OTPcheckRecovery.php?status=sqlerror");
												exit();
											}else {
												if(isset($_SESSION["recoveryEmail"])){
													$hashedNewPass = password_hash($newPass,PASSWORD_DEFAULT);
													mysqli_stmt_bind_param($stmt, "ss",$hashedNewPass,$_SESSION['recoveryEmail']);
													mysqli_stmt_execute($stmt);
													echo
													'
													<script>
													alert("Your password was successfully reset!");
													window.location.href="./clogin.php";
													</script>
													';

												}else{
																header("Location:./OTPcheckRecovery.php?status=sqlerror");
																exit();
												}

											}
										}
									}else if(!password_verify($otp,$_SESSION['OTP'])){
										//otp incorrect
										header("Location:./OTPcheckRecovery.php?status=incorrectotp");
										exit();
									}

							}
							//ALL INVALID
							else if(!$vOTP && !$vNewPass && !$vNewPassR){
							header("Location:./OTPcheckRecovery.php?status=ALLinvalid");
							exit();
							}
							//Only otp invalid
							else if(!$vOTP && $vNewPass && $vNewPassR){
								header("Location:./OTPcheckRecovery.php?status=invalidotp");
								exit();
							}
							//Only new password invalid
							else if($vOTP && !$vNewPass && $vNewPassR){
								header("Location:./OTPcheckRecovery.php?status=invalidnewpass");
								exit();
							}
							//Only new repeat password invalid
							else if(!$vOTP && !$vNewPass && $vNewPassR){
								header("Location:./OTPcheckRecovery.php?status=invalidnewpassr");
								exit();
							}
							//Only OTP valid
							else if($vOTP && !$vNewPass && !$vNewPassR){
								header("Location:./OTPcheckRecovery.php?status=invalidnewpassandnewpassr");
								exit();
							}
							//Only new password valid
							else if(!$vOTP && $vNewPass && !$vNewPassR){
								header("Location:./OTPcheckRecovery.php?status=invalidotpandnewpassr");
								exit();
							}
							//Only new repeat passwod valid
							else if(!$vOTP && !$vNewPass && $vNewPassR){
								header("Location:./OTPcheckRecovery.php?status=invalidotpandnewpass");
								exit();
							}



				}


			}else if(time() > $_SESSION['vExpiredTime']){
				//alert user
				echo
				'
				<script>
				alert("The OTP has expired! Please click the "Reapply" button to reapply again to recover your password.");
				</script>
				';

				//clear session
				unset($_SESSION["OTP"]);
				unset($_SESSION["recoveryEmail"]);

				//output the resend button
				echo '
				<br>
				<br>
				';
				echo '<a href="./recovery1.php" style="display: inline-block; padding: 10px 20px; background-color: #4CAF50; color: white; text-decoration: none; border-radius: 4px; border: none; text-align: center; cursor: pointer;">Reapply</a>';

			}

















    }
?>

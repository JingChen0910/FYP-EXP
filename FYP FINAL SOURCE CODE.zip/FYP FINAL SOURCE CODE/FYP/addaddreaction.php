<?php
session_start();
require_once 'dataconnection.php';
if(!isset($_SESSION['id']) || !isset($_SESSION['name']) || !isset($_SESSION['email']) || !isset($_SESSION['vemail'])){
	echo "<script>window.location.href='clogin.php';</script>";
 }else if(isset($_SESSION['id']) &&  isset($_SESSION['name']) && isset($_SESSION['email']) && isset($_SESSION['vemail'])){
	   $vemail = $_SESSION['vemail'];
	   if($vemail == false){
		echo "<script>window.location.href='sentOTP.php';</script>";
		  exit();
	   }
	}

if(isset($_POST['addaddre'])){
	$add1 = mysqli_real_escape_string($connect,$_POST['address1']);
    $add2 = mysqli_real_escape_string($connect,$_POST['address2']);
    $city = mysqli_real_escape_string($connect,$_POST['city']);
    $state = mysqli_real_escape_string($connect,$_POST['state']);
    $postCode = mysqli_real_escape_string($connect, $_POST['postCode']);

    //all empty input
    if(empty($add1) || empty($add2) || empty($city) || empty($state) || empty($postCode)){
        header("Location:./addaddre.php?status=emptyinput&add1=".$add1."&add2=".$add2."&city=".$city."&state=".$state."&postCode=".$postCode);
    }else{
     //validation
     $vadd1 = preg_match('/^(?=.*[A-Za-z])[A-Za-z0-9 .,\/-]{0,99}$/',$add1);
     $vadd2 = preg_match('/^(?=.*[A-Za-z])[A-Za-z0-9 .,\/-]{0,99}$/',$add2);
     $vcity = preg_match('/^(?=.{1,50}$)[A-Za-z\s\',.]+$/',$city);
     $vstate = preg_match('/^[A-Za-z ,]{1,20}$/',$state);
     $vpostCode = preg_match('/^\d{5}$/',$postCode);

     //* invalid
     if(!$vadd1 && !$vadd2 && !$vcity && !$vstate && !$vpostCode){
        header("Location:./addaddre.php?status=invalidinput");
        exit();
     }
     //all valid input
     else if($vadd1 && $vadd2 && $vcity && $vstate && $vpostCode){
			 //start
			 //lowercase city name
			 $lcity = strtolower($city);
			 if($state == "Johor"){
				 if($lcity == "johor bahru" || $lcity == "mersing" || $lcity == "batu pahat" || $lcity == "segamat district" || $lcity == "labis" || $lcity == "senai" || $lcity == "endau" || $lcity == "panchor" || $lcity == "pontian kechil" || $lcity == "ayer hitam" || $lcity == "sri gading" || $lcity == "kahang" || $lcity == "layang-layang" || $lcity == "semerah" || $lcity == "bandar tenggara" || $lcity == "renggam" || $lcity == "buloh kasap" || $lcity == "tangkak" || $lcity == "kulai" || $lcity == "kluang" || $lcity == "chaah" || $lcity == "pekan nanas" || $lcity == "kota tinggi" || $lcity == "parit jawa" || $lcity == "pengerang" || $lcity == "iskandar puteri" || $lcity == "senggarang" || $lcity == "batu anam" || $lcity == "sungai mati" || $lcity == "benut" || $lcity == "gelang patah" || $lcity == "bekok" || $lcity == "pagoh" || $lcity == "kelapa sawit" || $lcity == "muar" || $lcity == "ulu tiram" || $lcity == "yong peng" || $lcity == "parit raja" || $lcity == "simpang renggam" || $lcity == "parit sulong" || $lcity == "kota tinggi" || $lcity == "ayer baloi" || $lcity == "bukit pasir" || $lcity == "rengit" || $lcity == "jementah" || $lcity == "sri medan" || $lcity == "bukit gambir" || $lcity == "paloh" || $lcity == "kukup" || $lcity == "bukit bakri" || $lcity == "bandar penawar"){
					 if(($postCode >= 79000 && $postCode <= 86900) || $postCode == 73400){
						 	 $sql = "INSERT INTO address(customer_id,address1,address2,city,state,postalCode) VALUES (?,?,?,?,?,?)";
		 					$stmt = mysqli_stmt_init($connect);
		 					if(!mysqli_stmt_prepare($stmt,$sql)){
			 				header("Location:./addaddre.php?status=sqlerror");
						    exit();
		 					}else{
			 				mysqli_stmt_bind_param($stmt,"ssssss",$_SESSION['id'],$add1,$add2,$city,$state,$postCode);
			 				mysqli_stmt_execute($stmt);
							// mysqli_stmt_store_result($stmt);
			 				// header("Location:./addaddre.php?status=addsuccess");
			 				echo '<script>alert("Address added!");
							window.location.href="user_profile.php";</script>';
			 				exit();
							}

						   mysqli_stmt_close($stmt);
						   mysqli_close($connect);
					 }else{

						   header("Location:./addaddre.php?status=invalidpostalCode&add1=".$add1."&add2=".$add2."&city=".$city."&state=".$state);
						 	exit();
					 }
				 }else{
					 header("Location:./addaddre.php?status=invalidcity&add1=".$add1."&add2=".$add2."&state=".$state."&postCode=".$postCode);
        				exit();
				 }



			 }else if($state == "Kedah"){
				 if($lcity == "alor setah" || $lcity == "gurun" || $lcity == "bedong" || $lcity == "changlun" || $lcity == "pendang" || $lcity == "bandar baharu" || $lcity == "padang serai" || $lcity == "kota sarang semut" || $lcity == "kuah" || $lcity == "ayer hangat" || $lcity == "parit buntar" || $lcity == "jitra" || $lcity == "pokok sena" || $lcity == "baling" || $lcity == "kodiang" || $lcity == "yan" || $lcity == "langgar" || $lcity == "kota kuala muda" || $lcity == "merbok" || $lcity == "simpang ampat" || $lcity == "padang matsirat" || $lcity == "kuala perlis" || $lcity == "sungai petani" || $lcity == "kuala kedah" || $lcity == "serdang" || $lcity == "kulim district" || $lcity == "kuala nerang" || $lcity == "kuala ketil" || $lcity == "bukit kayu hitam" || $lcity == "jeniang" || $lcity == "kupang" || $lcity == "anak bukit"){
					 if($postCode >= 5000 && $postCode <= 9810){
						 	 	 $sql = "INSERT INTO address(customer_id,address1,address2,city,state,postalCode) VALUES (?,?,?,?,?,?)";
		 					$stmt = mysqli_stmt_init($connect);
		 					if(!mysqli_stmt_prepare($stmt,$sql)){
			 				header("Location:./addaddre.php?status=sqlerror");
						    exit();
		 					}else{
			 				mysqli_stmt_bind_param($stmt,"ssssss",$_SESSION['id'],$add1,$add2,$city,$state,$postCode);
			 				mysqli_stmt_execute($stmt);
							// mysqli_stmt_store_result($stmt);
			 				// header("Location:./addaddre.php?status=addsuccess");
			 				echo '<script>alert("Address added!");
							window.location.href="user_profile.php";</script>';
			 				exit();
							}

						   mysqli_stmt_close($stmt);
						   mysqli_close($connect);
					 }else{
						   header("Location:./addaddre.php?status=invalidpostalCode&add1=".$add1."&add2=".$add2."&city=".$city."&state=".$state);
						 	exit();
					 }
				 }else{
					  header("Location:./addaddre.php?status=invalidcity&add1=".$add1."&add2=".$add2."&state=".$state."&postCode=".$postCode);
        				exit();
				 }
			 }else if($state == "Kelantan"){
				 	if($lcity == "kota bharu" || $lcity == "tumpat" || $lcity == "machang" || $lcity == "jeli" || $lcity == "dabong" || $lcity == "peringat" || $lcity == "gua musang" || $lcity == "tanah merah" || $lcity == "bachok" || $lcity == "pasir puteh" || $lcity == "wakaf bharu" || $lcity == "lojing" ||$lcity == "pasir mas" || $lcity == "ketereh" || $lcity == "kuala krai" || $lcity == "melor" || $lcity == "rantau panjang" || $lcity == "machang"){
						if($postCode >= 15000 && $postCode <= 18500){
								 	 	 $sql = "INSERT INTO address(customer_id,address1,address2,city,state,postalCode) VALUES (?,?,?,?,?,?)";
		 					$stmt = mysqli_stmt_init($connect);
		 					if(!mysqli_stmt_prepare($stmt,$sql)){
			 				header("Location:./addaddre.php?status=sqlerror");
						    exit();
		 					}else{
			 				mysqli_stmt_bind_param($stmt,"ssssss",$_SESSION['id'],$add1,$add2,$city,$state,$postCode);
			 				mysqli_stmt_execute($stmt);
							// mysqli_stmt_store_result($stmt);
			 				// header("Location:./addaddre.php?status=addsuccess");
			 				echo '<script>alert("Address added!");
							window.location.href="user_profile.php";</script>';
			 				exit();
							}

						   mysqli_stmt_close($stmt);
						   mysqli_close($connect);
						}else{
							   header("Location:./addaddre.php?status=invalidpostalCode&add1=".$add1."&add2=".$add2."&city=".$city."&state=".$state);
						 	exit();
						}
					}else{
						 header("Location:./addaddre.php?status=invalidcity&add1=".$add1."&add2=".$add2."&state=".$state."&postCode=".$postCode);
        				exit();
					}
			 }else if($state == "Melaka"){
				 if($lcity == "melaka city" || $lcity == "bandar melaka" || $lcity == "alor gajah" || $lcity == "jasin" || $lcity == "masjid tanah" || $lcity == "merlimau" || $lcity == "sungai udang" || $lcity == "batu berendam" || $lcity == "bukit rambai" || $lcity == "ayer keroh" || $lcity == "klebang" || $lcity == "pulau sebang" || $lcity == "tampin" || $lcity == "durian tunggal" || $lcity == "krubong" || $lcity == "cheng" || $lcity == "bukit katil" || $lcity == "durian daun" || $lcity == "melaka tengah"){
					 if($postCode >= 75000 && $postCode <= 78309 ){
						  	 $sql = "INSERT INTO address(customer_id,address1,address2,city,state,postalCode) VALUES (?,?,?,?,?,?)";
		 					$stmt = mysqli_stmt_init($connect);
		 					if(!mysqli_stmt_prepare($stmt,$sql)){
			 				header("Location:./addaddre.php?status=sqlerror");
						    exit();
		 					}else{
			 				mysqli_stmt_bind_param($stmt,"ssssss",$_SESSION['id'],$add1,$add2,$city,$state,$postCode);
			 				mysqli_stmt_execute($stmt);
							// mysqli_stmt_store_result($stmt);
			 				// header("Location:./addaddre.php?status=addsuccess");
			 				echo '<script>alert("Address added!");
							window.location.href="user_profile.php";</script>';
			 				exit();
							}

						   mysqli_stmt_close($stmt);
						   mysqli_close($connect);
					 }else{
						  header("Location:./addaddre.php?status=invalidpostalCode&add1=".$add1."&add2=".$add2."&city=".$city."&state=".$state);
						 	exit();
					 }
				 }else{
					 	 header("Location:./addaddre.php?status=invalidcity&add1=".$add1."&add2=".$add2."&state=".$state."&postCode=".$postCode);
        				exit();
				 }
			 }
			 else if($state == "Negeri Sembilan"){
				 if($lcity == "seremban" || $lcity == "kuala pilah" || $lcity == "port dickson" || $lcity == "simpang durian" || $lcity == "labu" || $lcity == "simpang pertang" || $lcity == "linggi" || $lcity == "east belgium" || $lcity == "jelebu district" || $lcity == "legong llir" || $lcity == "kundor" || $lcity == "gadong" || $lcity == "langkap" || $lcity == "serting" || $lcity == "titian bintangor" || $lcity == "selemak" || $lcity == "sikamat" || $lcity == "bahau" || $lcity == "kuala klawang" || $lcity == "tanjung ipoh" || $lcity == "baut kikir" || $lcity == "rantau" || $lcity == "mantin" || $lcity == "rembau" || $lcity == "ampangan" || $lcity == "pasir panjang" || $lcity == "chengkau" || $lcity == "kampung keru" || $lcity == "kampung nerasau" || $lcity == "pantai" || $lcity == "rasah" || $lcity == "kampung mahsan" || $lcity == "ampang tinggi" || $lcity == "broga" || $lcity == "nilai" || $lcity == "tampin" || $lcity == "kota" || $lcity == "gemas" || $lcity == "gemencheh" || $lcity == "johol" || $lcity == "bandar seri jempol" || $lcity == "siliau" || $lcity == "bongkek" || $lcity == "tanjung ipoh" || $lcity == "terachi" || $lcity == "seri menanti" || $lcity == "air kuning selatan" || $lcity == "ulu triang" || $lcity == "repah" || $lcity == "tanjong kling" || $lcity == "lukut"){
					 if($postCode >= 70000 && $postCode <= 73509){
						 		  	 $sql = "INSERT INTO address(customer_id,address1,address2,city,state,postalCode) VALUES (?,?,?,?,?,?)";
		 					$stmt = mysqli_stmt_init($connect);
		 					if(!mysqli_stmt_prepare($stmt,$sql)){
			 				header("Location:./addaddre.php?status=sqlerror");
						    exit();
		 					}else{
			 				mysqli_stmt_bind_param($stmt,"ssssss",$_SESSION['id'],$add1,$add2,$city,$state,$postCode);
			 				mysqli_stmt_execute($stmt);
							// mysqli_stmt_store_result($stmt);
			 				// header("Location:./addaddre.php?status=addsuccess");
			 				echo '<script>alert("Address added!");
							window.location.href="user_profile.php";</script>';
			 				exit();
							}

						   mysqli_stmt_close($stmt);
						   mysqli_close($connect);
					 }else{
						   header("Location:./addaddre.php?status=invalidpostalCode&add1=".$add1."&add2=".$add2."&city=".$city."&state=".$state);
						 	exit();
					 }

				 }else{
					 header("Location:./addaddre.php?status=invalidcity&add1=".$add1."&add2=".$add2."&state=".$state."&postCode=".$postCode);
        				exit();
				 }
			 }
			 else if($state == "Pahang"){
				 if($lcity == "bentong" || $lcity == "kuala lipis" || $lcity == "raub district" || $lcity == "mentakad" || $lcity == "brinchang" || $lcity == "kemayan" || $lcity == "kuala rompin" || $lcity == "gambang" || $lcity == "lurah bilut" || $lcity == "cherating" || $lcity == "batu talam" || $lcity == "sebertak" || $lcity == "belimbing" || $lcity == "rompin district" || $lcity == "penor" || $lcity == "endau" || $lcity == "kuala tahan" || $lcity == "kuantan" || $lcity == "pekan" || $lcity == "maran" || $lcity == "benta" || $lcity == "muadzam shah" || $lcity == "bandar tun abdul razak" || $lcity == "bukit tinggi" || $lcity == "teriang" || $lcity == "lanchang" || $lcity == "lubuk paku" || $lcity == "bukit ibam" || $lcity == "blue valley" || $lcity == "jerantut" || $lcity == "bertam valley" || $lcity == "kuala tembeling" || $lcity == "sri jaya" || $lcity == "kuantan district locality plan" || $lcity == "temerloh" || $lcity == "tanah rata" || $lcity == "bandar tun razak" || $lcity == "sungai lembing" || $lcity == "ringlet" || $lcity == "fraser's hill" || $lcity == "chenor" || $lcity == "karak" || $lcity == "nenasi" || $lcity == "beserah" || $lcity == "kamping paloh hinai" || $lcity == "jerantut district" || $lcity == "cheroh" || $lcity == "hulu tembeling" || $lcity == "mengkarak" || $lcity == "kampung merapuh lama" || $lcity == "kampung raja"){
					 if(($postCode >=25000 && $postCode <=28800) || ($postCode >= 39000 && $postCode <= 39200) || $postCode == 49000 || $postCode == 69000){
						 	$sql = "INSERT INTO address(customer_id,address1,address2,city,state,postalCode) VALUES (?,?,?,?,?,?)";
		 					$stmt = mysqli_stmt_init($connect);
		 					if(!mysqli_stmt_prepare($stmt,$sql)){
			 				header("Location:./addaddre.php?status=sqlerror");
						    exit();
		 					}else{
			 				mysqli_stmt_bind_param($stmt,"ssssss",$_SESSION['id'],$add1,$add2,$city,$state,$postCode);
			 				mysqli_stmt_execute($stmt);
							// mysqli_stmt_store_result($stmt);
			 				// header("Location:./addaddre.php?status=addsuccess");
			 				echo '<script>alert("Address added!");
							window.location.href="user_profile.php";</script>';
			 				exit();
							}

						   mysqli_stmt_close($stmt);
						   mysqli_close($connect);
					 }else{
						    header("Location:./addaddre.php?status=invalidpostalCode&add1=".$add1."&add2=".$add2."&city=".$city."&state=".$state);
						 	exit();
					 }
				 }else{
					 					 header("Location:./addaddre.php?status=invalidcity&add1=".$add1."&add2=".$add2."&state=".$state."&postCode=".$postCode);
        				exit();
				 }
			 }
			 else if($state == "Penang"){
				 if($lcity == "george town" || $lcity == "tesek gelugor" || $lcity == "butterworth" || $lcity == "batu maung" || $lcity == "gelugor" || $lcity == "tanjung bungah" || $lcity == "simpang ampat" || $lcity == "gertak sanggul" || $lcity == "batu uban" || $lcity == "teluk bahang" || $lcity == "south seberang perai district" || $lcity == "bayan baru" || $lcity == "mount erskine" || $lcity == "kepala batas" ||$lcity == "nibong tebal" || $lcity == "perai" || $lcity == "air itam" || $lcity == "permatang pauh" || $lcity == "batu ferringhi" || $lcity == "sungai ara" || $lcity == "parit buntar" || $lcity == "sungai pinang" || $lcity == "teluk kumbar" ||$lcity == "kangar" || $lcity == "seberang jaya" || $lcity == "kulim district" || $lcity == "bukit mertajam" || $lcity == "bayan lepas" || $lcity == "balik pulau" || $lcity == "jelutong" || $lcity == "juru" || $lcity == "tanjung tokong" ||$lcity == "val d'or" || $lcity == "southwest penang island district" || $lcity == "sungai dua" || $lcity == "permatang pasir" || $lcity == "mak mandin" || $lcity == "sungai petani" || $lcity == "serdang"){
					 if($postCode >= 10000 && $postCode <= 14400){
						 	$sql = "INSERT INTO address(customer_id,address1,address2,city,state,postalCode) VALUES (?,?,?,?,?,?)";
		 					$stmt = mysqli_stmt_init($connect);
		 					if(!mysqli_stmt_prepare($stmt,$sql)){
			 				header("Location:./addaddre.php?status=sqlerror");
						    exit();
		 					}else{
			 				mysqli_stmt_bind_param($stmt,"ssssss",$_SESSION['id'],$add1,$add2,$city,$state,$postCode);
			 				mysqli_stmt_execute($stmt);
							// mysqli_stmt_store_result($stmt);
			 				// header("Location:./addaddre.php?status=addsuccess");
			 				echo '<script>alert("Address added!");
							window.location.href="user_profile.php";</script>';
			 				exit();
							}

						   mysqli_stmt_close($stmt);
						   mysqli_close($connect);
					 }else{
						  header("Location:./addaddre.php?status=invalidpostalCode&add1=".$add1."&add2=".$add2."&city=".$city."&state=".$state);
						 	exit();
					 }
				 }else{
					 		 header("Location:./addaddre.php?status=invalidcity&add1=".$add1."&add2=".$add2."&state=".$state."&postCode=".$postCode);
        				exit();
				 }
			 }
			 else if($state == "Perak"){
				 if($lcity == "kuala kangsar" || $lcity == "teluk intan" || $lcity == "batu gajah" || $lcity == "bangan serai" || $lcity == "sitiawan" || $lcity == "gerik" || $lcity == "chemor" || $lcity == "parit" || $lcity == "enggor" || $lcity == "terong" || $lcity == "kamunting" || $lcity == "chenderong balai" || $lcity == "pangkalan hulu" || $lcity == "changkat jering" || $lcity == "selekoh" || $lcity == "pusing" || $lcity == "kuala sepetang" || $lcity == "ipoh" || $lcity == "lumut" || $lcity == "parit buntar" || $lcity == "pantai remis" || $lcity == "simpang empat semanggp;" || $lcity == "gopeng" || $lcity == "larut, matang and selama district" || $lcity == "kampung gajah" || $lcity == "batu kurau" || $lcity == "manong" || $lcity == "ayer tawar" || $lcity == "hutan melintang" || $lcity == "teronoh" || $lcity == "behrang stesen" || $lcity == "kuala kurau" || $lcity == "slim river" || $lcity == "tanjung rambutan" || $lcity == "taiping" || $lcity == "kampar" || $lcity == "bidor" || $lcity == "tapah road" || $lcity == "tapah" || $lcity == "sungai siput" || $lcity == "kampung kepayang" || $lcity == "chikus" || $lcity == "lenggong" || $lcity == "bangan datuk" || $lcity == "chenderiang" || $lcity == "beruas" || $lcity == "tanjung tualang" || $lcity == "" || $lcity == "temoh" || $lcity == "changkat keruing" || $lcity == "tanjung piandang" || $lcity == "trolak"){
					 if($postCode >= 30000 && $postCode <= 36810){
						  	$sql = "INSERT INTO address(customer_id,address1,address2,city,state,postalCode) VALUES (?,?,?,?,?,?)";
		 					$stmt = mysqli_stmt_init($connect);
		 					if(!mysqli_stmt_prepare($stmt,$sql)){
			 				header("Location:./addaddre.php?status=sqlerror");
						    exit();
		 					}else{
			 				mysqli_stmt_bind_param($stmt,"ssssss",$_SESSION['id'],$add1,$add2,$city,$state,$postCode);
			 				mysqli_stmt_execute($stmt);
							// mysqli_stmt_store_result($stmt);
			 				// header("Location:./addaddre.php?status=addsuccess");
			 				echo '<script>alert("Address added!");
							window.location.href="user_profile.php";</script>';
			 				exit();
							}

						   mysqli_stmt_close($stmt);
						   mysqli_close($connect);
					 }else{
						 						  header("Location:./addaddre.php?status=invalidpostalCode&add1=".$add1."&add2=".$add2."&city=".$city."&state=".$state);
						 	exit();
					 }
				 }else{
					 					 		 header("Location:./addaddre.php?status=invalidcity&add1=".$add1."&add2=".$add2."&state=".$state."&postCode=".$postCode);
        				exit();
				 }
			 }
			 else if($state == "Perlis"){
				 if($lcity == "kangar" || $lcity == "arau" || $lcity == "kechor" || $lcity == "wang kelian" || $lcity == "kuala perlis" || $lcity == "simpang ampat" || $lcity == "jejawi" || $lcity == "kampung mata ayer" || $lcity == "changlun" || $lcity == "kaki bukit" || $lcity == "chuping" || $lcity == "sanglang" || $lcity == "abi, perlis"){
					 if($postCode >= 1000 && $postCode <= 2999){
						   	$sql = "INSERT INTO address(customer_id,address1,address2,city,state,postalCode) VALUES (?,?,?,?,?,?)";
		 					$stmt = mysqli_stmt_init($connect);
		 					if(!mysqli_stmt_prepare($stmt,$sql)){
			 				header("Location:./addaddre.php?status=sqlerror");
						    exit();
		 					}else{
			 				mysqli_stmt_bind_param($stmt,"ssssss",$_SESSION['id'],$add1,$add2,$city,$state,$postCode);
			 				mysqli_stmt_execute($stmt);
							// mysqli_stmt_store_result($stmt);
			 				// header("Location:./addaddre.php?status=addsuccess");
			 				echo '<script>alert("Address added!");
							window.location.href="user_profile.php";</script>';
			 				exit();
							}

						   mysqli_stmt_close($stmt);
						   mysqli_close($connect);
					 }else{
						   header("Location:./addaddre.php?status=invalidpostalCode&add1=".$add1."&add2=".$add2."&city=".$city."&state=".$state);
					 }
				 }else{
					  header("Location:./addaddre.php?status=invalidcity&add1=".$add1."&add2=".$add2."&state=".$state."&postCode=".$postCode);
        				exit();
				 }
			 }
			 else if($state == "Sabah"){
				 if($lcity == "kota kinabalu" || $lcity == "keningau" || $lcity == "papar" || $lcity == "putatan" || $lcity == "tuaran" || $lcity == "tenghilan" || $lcity == "tambunan" || $lcity == "slipitang" || $lcity == "kunak" || $lcity == "pekan donggongon" || $lcity == "victoria" || $lcity == "sook" || $lcity == "kalabakan" || $lcity == "tawau" || $lcity == "kudat" || $lcity == "lahad datu" || $lcity == "beafort" || $lcity == "penampang district" || $lcity == "nabawan" || $lcity == "tenom" || $lcity == "kuala penyu" || $lcity == "bongawan" || $lcity == "kinarut" || $lcity == "pitas" || $lcity == "ranau district" || $lcity == "kundasang" || $lcity == "sandakan" || $lcity == "kota belud" || $lcity == "semporna" || $lcity == "tamparuli" || $lcity == "membakut" || $lcity == "kinabatangan" || $lcity == "kota marudu" || $lcity == "beluran" || $lcity == "inanam" || $lcity == "telupid" || $lcity == "long pasia" || $lcity == "kelabakan district" || $lcity == "" || $lcity == "lawas"){
					 if($postCode >= 88000 && $postCode <= 91309){
						 	   	$sql = "INSERT INTO address(customer_id,address1,address2,city,state,postalCode) VALUES (?,?,?,?,?,?)";
		 					$stmt = mysqli_stmt_init($connect);
		 					if(!mysqli_stmt_prepare($stmt,$sql)){
			 				header("Location:./addaddre.php?status=sqlerror");
						    exit();
		 					}else{
			 				mysqli_stmt_bind_param($stmt,"ssssss",$_SESSION['id'],$add1,$add2,$city,$state,$postCode);
			 				mysqli_stmt_execute($stmt);
							// mysqli_stmt_store_result($stmt);
			 				// header("Location:./addaddre.php?status=addsuccess");
			 				echo '<script>alert("Address added!");
							window.location.href="user_profile.php";</script>';
			 				exit();
							}

						   mysqli_stmt_close($stmt);
						   mysqli_close($connect);
					 }else{
						    header("Location:./addaddre.php?status=invalidpostalCode&add1=".$add1."&add2=".$add2."&city=".$city."&state=".$state);
					 }
				 }else{
					 		  header("Location:./addaddre.php?status=invalidcity&add1=".$add1."&add2=".$add2."&state=".$state."&postCode=".$postCode);
        				exit();
				 }
			}
			else if($state == "Sarawak"){
				if($lcity == "kuching" || $lcity == "sibu" || $lcity == "kapit" || $lcity == "kota samarahan" || $lcity == "mukah" || $lcity == "kanowit" || $lcity == "saratok" || $lcity == "song" || $lcity == "matu" || $lcity == "spoah" || $lcity == "lundu" || $lcity == "balingian" || $lcity == "debak" || $lcity == "engkilili" || $lcity == "tebedu" || $lcity == "bahagian samarahan" || $lcity == "lingga" || $lcity == "miri" || $lcity == "simanggang" || $lcity == "serian" || $lcity == "daro" || $lcity == "sebuyau" || $lcity == "lawas" || $lcity == "sebauh" || $lcity == "bintangor" || $lcity == "pusa" || $lcity == "belawai" || $lcity == "limbang district" || $lcity == "lubok antu" || $lcity == "bahangian betong" || $lcity == "siburan" || $lcity == "balai ringin" || $lcity == "pandawan" || $lcity == "oya" || $lcity == "bintulu" || $lcity == "sarikei" || $lcity == "bau" || $lcity == "simunjan" || $lcity == "limbang" || $lcity == "long lama" || $lcity == "julau" || $lcity == "asajaya" || $lcity == "bekenu" || $lcity == "belaga" || $lcity == "dalat" || $lcity == "tatau" || $lcity == "lutong" || $lcity == "bahagian sri aman" || $lcity == "betong" || $lcity == "bario" || $lcity == "meradong district"){
					if($postCode >= 93000 && $postCode <= 98859){
						   	$sql = "INSERT INTO address(customer_id,address1,address2,city,state,postalCode) VALUES (?,?,?,?,?,?)";
		 					$stmt = mysqli_stmt_init($connect);
		 					if(!mysqli_stmt_prepare($stmt,$sql)){
			 				header("Location:./addaddre.php?status=sqlerror");
						    exit();
		 					}else{
			 				mysqli_stmt_bind_param($stmt,"ssssss",$_SESSION['id'],$add1,$add2,$city,$state,$postCode);
			 				mysqli_stmt_execute($stmt);
							// mysqli_stmt_store_result($stmt);
			 				// header("Location:./addaddre.php?status=addsuccess");
			 				echo '<script>alert("Address added!");
							window.location.href="user_profile.php";</script>';
			 				exit();
							}

						   mysqli_stmt_close($stmt);
						   mysqli_close($connect);
					}else{
						  header("Location:./addaddre.php?status=invalidpostalCode&add1=".$add1."&add2=".$add2."&city=".$city."&state=".$state);
					}
				}else{
					 header("Location:./addaddre.php?status=invalidcity&add1=".$add1."&add2=".$add2."&state=".$state."&postCode=".$postCode);
        				exit();
				}
			}
			else if($state == "Selangor"){
				if($lcity == "kuala lumpur" || $lcity == "shah alam" || $lcity == "jenjarom" || $lcity == "klang" || $lcity == "batu arang" || $lcity == "tanjong sepat" || $lcity == "semenyih" || $lcity == "tanjung karang" || $lcity == "beranang" || $lcity == "puchong" || $lcity == "sekinchan" || $lcity == "rasa" || $lcity == "bukit rotan" || $lcity == "port klang" || $lcity == "kundang" || $lcity == "sungai tengi" || $lcity == "bandar baru bangi" || $lcity == "jeram" || $lcity == "rawang" || $lcity == "subang jaya" || $lcity == "banting" || $lcity == "kuang" || $lcity == "cyberjaya" || $lcity == "ampang jaya" || $lcity == "sabak" || $lcity == "kajang" || $lcity == "seri kembangan" || $lcity == "belakong" || $lcity == "dengkil" || $lcity == "sungai buloh" ||$lcity == "puncak alam" || $lcity == "sungai pelong" || $lcity == "assam jawa" || $lcity == "cheras" || $lcity == "putra heights" || $lcity == "putrajaya"){
					if(($postCode >= 40000 && $postCode <= 48300) || ($postCode >= 62300 && $postCode <= 68100) || ($postCode >= 50000 && $postCode <= 60000)) {
								   	$sql = "INSERT INTO address(customer_id,address1,address2,city,state,postalCode) VALUES (?,?,?,?,?,?)";
		 					$stmt = mysqli_stmt_init($connect);
		 					if(!mysqli_stmt_prepare($stmt,$sql)){
			 				header("Location:./addaddre.php?status=sqlerror");
						    exit();
		 					}else{
			 				mysqli_stmt_bind_param($stmt,"ssssss",$_SESSION['id'],$add1,$add2,$city,$state,$postCode);
			 				mysqli_stmt_execute($stmt);
							// mysqli_stmt_store_result($stmt);
			 				// header("Location:./addaddre.php?status=addsuccess");
			 				echo '<script>alert("Address added!");
							window.location.href="user_profile.php";</script>';
			 				exit();
							}

						   mysqli_stmt_close($stmt);
						   mysqli_close($connect);
					}else{
						  header("Location:./addaddre.php?status=invalidpostalCode&add1=".$add1."&add2=".$add2."&city=".$city."&state=".$state);
					}
				}else{
							 header("Location:./addaddre.php?status=invalidcity&add1=".$add1."&add2=".$add2."&state=".$state."&postCode=".$postCode);
        				exit();
				}
			}
			else if($state == "Terengganu"){
				if($lcity == "kuala teregganu" || $lcity == "kerteh" || $lcity == "kuala besut" || $lcity == "kuala dungun" || $lcity == "kijal" || $lcity == "kemaman" || $lcity == "bukit peteri" || $lcity == "jenagur" || $lcity == "kampung sungai bari" || $lcity == "pangkalan nangka" || $lcity == "bukit besar" || $lcity == "ruslia" || $lcity == "wakaf mempelam" || $lcity == "kampung raja" || $lcity == "gua musang" || $lcity == "marang" || $lcity == "jerteh" || $lcity == "bukit payong" || $lcity == "kemasik" || $lcity == "ketengah jaya" || $lcity == "bandar permaisuri" || $lcity == "manir" || $lcity == "jerangau" || $lcity == "padang midin" || $lcity == "kuala paka" || $lcity == "jabi" || $lcity == "batu rakit" || $lcity == "rantau abang" || $lcity == "tenang" || $lcity == "gong balai" || $lcity == "paka" || $lcity == "kuala berang" || $lcity == "chukai" || $lcity == "ajil" || $lcity == "bukit besi" || $lcity == "kubang bemban" || $lcity == "kerandang" || $lcity == "kampung jenang" || $lcity == "kulau ibai" || $lcity == "bukit kenak" || $lcity == "tembila" || $lcity == "teluk kalong" || $lcity == "sekayu" || $lcity == "sungai bari"){
					if($postCode >= 20000 && $postCode <= 24300){
										   	$sql = "INSERT INTO address(customer_id,address1,address2,city,state,postalCode) VALUES (?,?,?,?,?,?)";
		 					$stmt = mysqli_stmt_init($connect);
		 					if(!mysqli_stmt_prepare($stmt,$sql)){
			 				header("Location:./addaddre.php?status=sqlerror");
						    exit();
		 					}else{
			 				mysqli_stmt_bind_param($stmt,"ssssss",$_SESSION['id'],$add1,$add2,$city,$state,$postCode);
			 				mysqli_stmt_execute($stmt);
							// mysqli_stmt_store_result($stmt);
			 				// header("Location:./addaddre.php?status=addsuccess");
			 				echo '<script>alert("Address added!");
							window.location.href="user_profile.php";</script>';
			 				exit();
							}

						   mysqli_stmt_close($stmt);
						   mysqli_close($connect);
					}else{
						header("Location:./addaddre.php?status=invalidpostalCode&add1=".$add1."&add2=".$add2."&city=".$city."&state=".$state);
					}
				}else{
					 header("Location:./addaddre.php?status=invalidcity&add1=".$add1."&add2=".$add2."&state=".$state."&postCode=".$postCode);
        				exit();
				}
			}


	//end
     }
     //vpostCode invalid
     else if($vadd1 && $vadd2 && $vcity && $vstate && !$vpostCode){
        header("Location:./addaddre.php?status=invalidpostalCode&add1=".$add1."&add2=".$add2."&city=".$city."&state=".$state);
        exit();
      }
     //state invalid
     else if($vadd1 && $vadd2 && $vcity && !$vstate && $vpostCode){
        header("Location:./addaddre.php?status=invalidstate&add1=".$add1."&add2=".$add2."&city=".$city."&postCode=".$postCode);
        exit();
      }
     //vcity invalid
     else if($vadd1 && $vadd2 && !$vcity && $vstate && $vpostCode){
        header("Location:./addaddre.php?status=invalidcity&add1=".$add1."&add2=".$add2."&state=".$state."&postCode=".$postCode);
        exit();
      }
     //add 2 invalid
     else if($vadd1 && !$vadd2 && $vcity && $vstate && $vpostCode){
        header("Location:./addaddre.php?status=invalidadd2&add1=".$add1."&city=".$city."&state=".$state."&postCode=".$postCode);
        exit();
      }
     //add 1 invalid
     else if(!$vadd1 && $vadd2 && $vcity && $vstate && $vpostCode){
        header("Location:./addaddre.php?status=invalidadd1&add2=".$add2."&city=".$city."&state=".$state."&postCode=".$postCode);
        exit();
      }
     //testing 2
		 //invalid postCode and state
      else if($vadd1 && $vadd2 && $vcity && !$vstate && !$vpostCode){
         header("Location:./addaddre.php?status=postcodeandstate&add1=".$add1."add2=".$add2."&city=".$city);
         exit();
      }
		 //invalid postCode and city
       else if($vadd1 && $vadd2 && !$vcity && $vstate && !$vpostCode){
         header("Location:./addaddre.php?status=postcodeandcity&add1=".$add1."&add2=".$add2."&state=".$state);
         exit();
      }
		 //invalid postCode and add2
       else if($vadd1 && !$vadd2 && $vcity && $vstate && !$vpostCode){
         header("Location:./addaddre.php?status=postcodeandadd2&add1=".$add1."&city=".$city."&state=".$state);
         exit();
      }
		 //invalid postCode and add1
       else if(!$vadd1 && $vadd2 && $vcity && $vstate && !$vpostCode){
         header("Location:./addaddre.php?status=postcodeandadd1&add2=".$add2."&city=".$city."&state=".$state);
         exit();
      }
		 //invalid state and city
       else if($vadd1 && $vadd2 && !$vcity && !$vstate && $vpostCode){
         header("Location:./addaddre.php?status=stateandcity&add1=".$add1."add2=".$add2."&postCode=".$postCode);
         exit();
      }
		 //invalid state and add1
       else if(!$vadd1 && $vadd2 && $vcity && !$vstate && $vpostCode){
         header("Location:./addaddre.php?status=stateandadd1&add2=".$add2."&city=".$city."&postCode=".$postCode);
         exit();
      }
		 //invalid state and add2
       else if($vadd1 && !$vadd2 && $vcity && !$vstate && $vpostCode){
         header("Location:./addaddre.php?status=stateandadd2&add1=".$add1."&city=".$city."&postCode=".$postCode);
         exit();
      }
		 //invalid add1 and add2
       else if(!$vadd1 && !$vadd2 && $vcity && $vstate && $vpostCode){
         header("Location:./addaddre.php?status=add1andadd2&city=".$city."&state=".$state."&postCode=".$postCode);
         exit();
      }
		 //invalid add1 and city
       else if(!$vadd1 && $vadd2 && !$vcity && $vstate && $vpostCode){
         header("Location:./addaddre.php?status=add1andcity&add2=".$add2."&state=".$state."&postCode=".$postCode);
         exit();
      }
       //invalid add2 and city
       else if($vadd1 && !$vadd2 && !$vcity && $vstate && $vpostCode){
         header("Location:./addaddre.php?status=add2andcity&add1=".$add1."&state=".$state."&postCode=".$postCode);
         exit();
      }
      //testing
      //invalid add1, add2 and city
      else if(!$vadd1 && !$vadd2 && !$vcity && $vstate && $vpostCode){
         header("Location:./addaddre.php?status=add1add2andcity&state=".$state."&postCode=".$postCode);
         exit();
      }
      //invalid add1, add2 and state
      else if(!$vadd1 && !$vadd2 && $vcity && !$vstate && $vpostCode){
         header("Location:./addaddre.php?status=add1add2andstate&city=".$city."&postCode=".$postCode);
         exit();
      }
      //invalid add1, add2 and postal code
      else if(!$vadd1 && !$vadd2 && $vcity && $vstate && !$vpostCode){
         header("Location:./addaddre.php?status=add1add2andpostCode&city=".$city."&state=".$state);
         exit();
      }
      //invalid add1, city and state
      else if(!$vadd1 && $vadd2 && !$vcity && !$vstate && $vpostCode){
         header("Location:./addaddre.php?status=add1cityandstate&add2=".$add2."&postCode=".$postCode);
         exit();
      }
      //invalid add1, city and postal code
      else if(!$vadd1 && $vadd2 && !$vcity && $vstate && !$vpostCode){
         header("Location:./addaddre.php?status=add1cityandpostCode&add2=".$add2."&state=".$state);
         exit();
      }
      //invalid add1, state and postal code
      else if(!$vadd1 && $vadd2 && $vcity && !$vstate && !$vpostCode){
         header("Location:./addaddre.php?status=add1stateandpostCode&city=".$city."&state=".$state);
         exit();
      }
      //invalid add2, city and state
      else if($vadd1 && !$vadd2 && !$vcity && !$vstate && $vpostCode){
         header("Location:./addaddre.php?status=add2cityandstate&add1=".$add1."&postCode=".$postCode);
         exit();
      }
      //invalid add2, city and postal code
      else if($vadd1 && !$vadd2 && !$vcity && $vstate && !$vpostCode){
         header("Location:./addaddre.php?status=add2cityandpostCode&add1=".$add1."&state=".$state);
         exit();
      }
      //invalid add2, state and postal code
      else if($vadd1 && !$vadd2 && $vcity && !$vstate && !$vpostCode){
         header("Location:./addaddre.php?status=add2stateandpostCode&add1=".$add1."&city=".$city);
         exit();
      }
      //invalid city, state and postal code
      else if($vadd1 && $vadd2 && !$vcity && !$vstate && !$vpostCode){
         header("Location:./addaddre.php?status=citystateandpostCode&add1=".$add1."&add2=".$add2);
         exit();
      }

      //only add1 correct
      else if($vadd1 && !$vadd2 && !$vcity && !$vstate && !$vpostCode){
         header("Location:./addaddre.php?status=onlyadd1&add1=".$add1);
         exit();
      }
      //only add2 correct
      else if(!$vadd1 && $vadd2 && !$vcity && !$vstate && !$vpostCode){
         header("Location:./addaddre.php?status=onlyadd2&add2=".$add2);
         exit();
      }
      //only city correct
      else if(!$vadd1 && !$vadd2 && $vcity && !$vstate && !$vpostCode){
         header("Location:./addaddre.php?status=onlycity&city=".$city);
         exit();
      }
      //only state correct
      else if(!$vadd1 && !$vadd2 && !$vcity && $vstate && !$vpostCode){
         header("Location:./addaddre.php?status=onlystate&state=".$state);
         exit();
      }
      //only postal code correct
      else if(!$vadd1 && !$vadd2 && !$vcity && !$vstate && $vpostCode){
         header("Location:./addaddre.php?status=onlypostCode&postCode=".$postCode);
         exit();
      }











    }

}

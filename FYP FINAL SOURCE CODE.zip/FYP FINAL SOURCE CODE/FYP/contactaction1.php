<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPmailer/src/Exception.php';
require 'PHPmailer/src/PHPMailer.php';
require 'PHPmailer/src/SMTP.php';

 //recaptcha
 $secret ="6Lcfkl8mAAAAADYvd9vzdhNkkgUV7CqUmvLPK0Df";
 $response = $_POST['g-recaptcha-response'];
 $remoteip = $_SERVER['REMOTE_ADDR'];
 $URL = "https://www.google.com/recaptcha/api/siteverify?secret=$secret&response=$response&remoteip=$remoteip";
 $data = file_get_contents($URL);
 $Recaptcha = json_decode($data,true);

if($_SERVER["REQUEST_METHOD"] == "POST"){

    //customer name
    $name = htmlspecialchars($_POST["name"]);
    //customer email
    $cemail = htmlspecialchars($_POST["email"]);
    //customer subject
    $subject = htmlspecialchars($_POST["subject"]);
    //customer message
    $message = htmlspecialchars($_POST["message"]);

    //DEFAULT Subject
    $Dsubject = htmlspecialchars("Customer Service");

    if($Recaptcha['success'] == true){
    //all empty input
    if(empty($name) || empty($cemail) || empty($subject) || empty($message)){
        header("Location:contact.php?status=ALLemptyinput");
        exit();
    }else{

        //validate
        $vname = preg_match('/^(?=[a-zA-Z])[a-zA-Z0-9 ._-]{8,60}$/',$name);
        $vemail = filter_var($cemail,FILTER_VALIDATE_EMAIL);
        $vemailRegex = preg_match('/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/',$cemail);
        if(strlen($subject) <= 998){
            $vsubject = true;
        }else{
            $vsubject = false;
        }

        if(strlen($message) <= 1000){
            $vmessage = true;
        }else{
            $vmessage = false;
        }

        //all invalid
        if(!$vname && (!$vemail || !$vemailRegex) && $vsubject == false && $vmessage == false){
        header("Location:contact.php?status=ALLinvalidinput");
        exit();
        }

        //all valid
        else if($vname && ($vemail && $vemailRegex) && $vsubject == true && $vmessage == true){
        //my email
        $email="knowledgemain1991@gmail.com";

        //my app password
        $appPass="bsbddqyahqsshvdf";

        $body =
        '
        <!DOCTYPE html>
      <html>
      <body style="font-family: Arial, sans-serif; background-color: #f5f5f5;">
        <div style="max-width: 600px; margin: 0 auto; padding: 20px; background-color: #fff; border: 1px solid #ddd; border-radius: 4px; box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);">
        <h2 style="color: #333;">Email Details</h2>
        <p style="font-weight: bold;">From:</p>
        <p>'.$name.'</p>
        <p style="font-weight: bold;">Customer Email:</p>
      <p>'.$cemail.'</p>
        <p style="font-weight: bold;">Customer Subject:</p>
        <p>'.$subject.'</p>
        <p style="font-weight: bold;">Customer Message:</p>
        <p style="margin-top: 10px;">'.$message.'</p>
        </div>
      </body>
      </html>
        ';

        $mail = new PHPMailer();

        $mail -> isSMTP();
        $mail -> Host = 'smtp.gmail.com';
        $mail -> SMTPAuth = true;
        $mail -> Username = $email; //Your email
        $mail -> Password = $appPass; //Your email app password
        $mail -> SMTPSecure = 'ssl';
        $mail -> Port = 465;

        $mail -> setFrom($email);

        $mail -> addAddress("shengxian.staff@proton.me");

        $mail -> isHTML(true);

        $mail -> Subject = $Dsubject;
        $mail -> Body = $body;

        $mail -> send();
        header("Location:contact.php?status=success");
        exit();
        }

        //invalid name email subject
        else if(!$vname && (!$vemail || !$vemailRegex) && $vsubject == false && $vmessage == true){
        header("Location:contact.php?status=invalidnameemailsubject&message=".$message);
        exit();
        }

        //invalid name email message
        else if(!$vname && (!$vemail || !$vemailRegex) && $vsubject == true && $vmessage == false){
            header("Location:contact.php?status=invalidnameemailmessage&subject=".$subject);
            exit();
        }

        //invalid name subject message
        else if(!$vname && ($vemail && $vemailRegex) && $vsubject == false && $vmessage == false){
            header("Location:contact.php?status=invalidnamesubjectmessage&email=".$cemail);
            exit();
        }

        //invalid email subject message
        else if($vname && (!$vemail || !$vemailRegex) && $vsubject == false && $vmessage == false){
            header("Location:contact.php?status=invalidemailsubjectmessage&name=".$name);
            exit();
        }

        //invalid name email
        else if(!$vname && (!$vemail || !$vemailRegex) && $vsubject == true && $vmessage == true){
            header("Location:contact.php?status=invalidnameemail&subject=".$subject."&message=".$message);
            exit();
        }
        //invalid name message
        else if(!$vname && ($vemail && $vemailRegex) && $vsubject == true && $vmessage == false){
            header("Location:contact.php?status=invalidnamemessage&email=".$cemail."&subject=".$subject);
            exit();
        }
        //invalid name subject
        else if(!$vname && ($vemail && $vemailRegex) && $vsubject == false && $vmessage == true){
            header("Location:contact.php?status=invalidnamesubject&email=".$cemail."&message=".$message);
            exit();
        }
        //invalid email message
        else if($vname && (!$vemail || !$vemailRegex) && $vsubject == true && $vmessage == false){
            header("Location:contact.php?status=invalidemailmessage&name=".$name."&subject=".$subject);
            exit();
        }
        //invalid email subject
        else if($vname && (!$vemail || !$vemailRegex) && $vsubject == false && $vmessage == true){
            header("Location:contact.php?status=invalidemailsubject&name=".$name."&message=".$message);
            exit();
        }
        //invalid subject message
        else if($vname && ($vemail && $vemailRegex) && $vsubject == false && $vmessage == false){
            header("Location:contact.php?status=invalidsubjectmessage&name=".$name."&email=".$cemail);
            exit();
        }
        //invalid name
        else if(!$vname && ($vemail && $vemailRegex) && $vsubject == true && $vmessage == true){
            header("Location:contact.php?status=invalidname&email=".$cemail."&subject=".$subject."&message=".$message);
            exit();
        }
        //invalid email
        else if($vname && (!$vemail || !$vemailRegex) && $vsubject == true && $vmessage == true){
            header("Location:contact.php?status=invalidemail&name=".$name."&subject=".$subject."&message=".$message);
            exit();
        }
        //invalid subject
        else if($vname && ($vemail && $vemailRegex) && $vsubject == false && $vmessage == true){
            header("Location:contact.php?status=invalidsubject&name=".$name."&email=".$cemail."&message=".$message);
            exit();
        }
        //invalid message
        else if($vname && ($vemail && $vemailRegex) && $vsubject == true && $vmessage == false){
            header("Location:contact.php?status=invalidmessage&name=".$name."&email=".$cemail."&subject=".$subject);
            exit();
        }
    }

    }else{//recaptcha
		header("Location:contact.php?status=emptyrecaptcha&name=".$name."&email=".$cemail."&subject=".$subject."&message=".$message);
		exit();
	}

}

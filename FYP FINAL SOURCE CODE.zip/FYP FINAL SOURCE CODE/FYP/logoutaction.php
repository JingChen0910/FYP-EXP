<?php
session_start();
unset($_SESSION['id']);
unset($_SESSION['name']);
unset($_SESSION['email']);
unset($_SESSION['vemail']);
unset($_SESSION['gender']);
unset($_SESSION['birthyear']);
unset($_SESSION['pNumber']);
unset($_SESSION['picture']);

if(isset($_SESSION['addressID'])){
    unset($_SESSION['addressID']);
}

if(isset($_SESSION['OTP'])){
    unset($_SESSION['OTP']);
}

if(isset($_SESSION['vExpiredTime'])){
    unset($_SESSION['vExpiredTime']);
}


if(isset($_SESSION['theNewEmailIS'])){
    unset($_SESSION['theNewEmailIS']);
}







header("Location:./index.php");

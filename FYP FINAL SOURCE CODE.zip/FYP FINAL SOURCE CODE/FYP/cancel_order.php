<?php include("dataconnection.php"); 
  session_start();
  if(!isset($_SESSION['id']) || !isset($_SESSION['name']) || !isset($_SESSION['email']) || !isset($_SESSION['vemail'])){
	echo "<script>window.location.href='clogin.php';</script>";
 }else if(isset($_SESSION['id']) &&  isset($_SESSION['name']) && isset($_SESSION['email']) && isset($_SESSION['vemail'])){
	   $vemail = $_SESSION['vemail'];
	   if($vemail == false){
		echo "<script>window.location.href='sentOTP.php';</script>";
		  exit();
	   }
	   // else{
	   // 	header("Location:./index.php");
	   // 	exit();
	   // }
 }
  if(isset($_POST["cancel_orderbtn"]))
		{   date_default_timezone_set('Asia/Kuala_Lumpur');
            $date=date('Y-m-d H:i:s');
			$oid=$_POST["corder_id"];
			$cancel_order="UPDATE orders SET order_status='Cancelled', cancellation_date='$date' WHERE order_id=$oid";
			$runcancel_order=mysqli_query($connect, $cancel_order);
			$refund_pay="UPDATE payment SET payment_status='Refund Approved', refund_date='$date' WHERE order_id=$oid";
			$runrefund_pay=mysqli_query($connect, $refund_pay);
			$cancel_odetails="SELECT * FROM order_details WHERE order_id=$oid";
			$runcancel_odetails=mysqli_query($connect, $cancel_odetails);
			while($row_codetails=mysqli_fetch_assoc($runcancel_odetails))
			{
               $pid=$row_codetails["product_id"];
			   $pqty=$row_codetails["quantity"];
			   $sel_stock="SELECT * FROM stock WHERE product_id='$pid'";
			   $runsel_stock=mysqli_query($connect, $sel_stock);
			   $row_sel_stock=mysqli_fetch_assoc($runsel_stock);
			   $original_stock=$row_sel_stock["stock_level"];
			   $total_stock=$pqty+$original_stock;
			   $update_stock="UPDATE stock SET stock_level=$total_stock WHERE product_id='$pid'";
			   $runupdate_stock=mysqli_query($connect, $update_stock);
			}
			if($runcancel_odetails && $runrefund_pay)
			{
				echo "<script>alert('Order Cancelled...'); history.go(-1);</script>";
			}
		}
?>
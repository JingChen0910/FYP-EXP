<?php
session_start();
unset($_SESSION['mid']);
unset($_SESSION['mname']);
unset($_SESSION['memail']);
unset($_SESSION['mgender']);
unset($_SESSION['mbirthyear']);
unset($_SESSION['mpNumber']);
unset($_SESSION['mPicture']);

header("Location:./login.php");

<?php
session_start();
require_once 'dataconnection.php';
if(!isset($_SESSION['mid']) || !isset($_SESSION['mname']) || !isset($_SESSION['memail'])){
 echo '
 <script>
 alert("Please sign in your account!");
 window.location.href="./login.php";
 </script>
 ';
}

if(isset($_POST['delete'])){
    $id = $_POST['delete'];
    $sql1 = "SELECT master_profile_picture FROM master WHERE master_id='".$id."';";
    $result = mysqli_query($connect,$sql1);
    if($row = mysqli_fetch_array($result)){
        $databaseProfilePicture = $row["master_profile_picture"];
        if($databaseProfilePicture == "default.png"){
          echo
"
<script>
alert('You cannot delete the default profile picture!');
document.location.href='user_profile.php';
</script>
";
exit();

        }else if($databaseProfilePicture != "default.png"){
            $documentCustomerPicture = "./master_propic/".$databaseProfilePicture;
            if(!unlink($documentCustomerPicture)){
              echo
          "
          <script>
          alert('Fail to delete the current profile picture file!');
          document.location.href='user_profile.php';
          </script>
          ";
          exit();
            }else{
                $sql2 = "UPDATE master SET master_profile_picture='default.png' WHERE master_id = '".$id."';";
                if(mysqli_query($connect,$sql2)){
                  echo
      "
      <script>
      alert('Profile picture successfully deleted!');
      document.location.href='user_profile.php';
      </script>
      ";
      exit();
                }
            }
        }
    }else{
      echo
    "
    <script>
    alert('Sorry, SQL error!');
    document.location.href='user_profile.php';
    </script>
    ";
    exit();
	}
}

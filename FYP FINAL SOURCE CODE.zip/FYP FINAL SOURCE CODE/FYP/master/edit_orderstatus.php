<!DOCTYPE html>
<?php
session_start();
if(!isset($_SESSION['mid']) || !isset($_SESSION['mname']) || !isset($_SESSION['memail'])){
   echo '
   <script>
   alert("Please sign in your account!");
   window.location.href="./login.php";
   </script>
   ';
}else{
	include("dataconnection.php");
}




if(isset($_GET['id']) && isset($_POST['status'])){
    $order_id = $_GET['id'];
    $order_status = $_POST['status'];
    $query = "UPDATE orders SET order_status = '$order_status' WHERE order_id = $order_id";
    mysqli_query($connect, $query);

    header("Location: order.php");
    exit();
}else{
    echo "<script>alert('Error: Invalid. );</script>";
    echo "<script>window.location.href='order.php';</script>";
}
?>

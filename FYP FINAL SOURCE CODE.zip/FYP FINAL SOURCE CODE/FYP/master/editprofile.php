<?php
session_start();
require_once 'dataconnection.php';
if(!isset($_SESSION['mid']) || !isset($_SESSION['mname']) || !isset($_SESSION['memail'])){
 echo '
 <script>
 alert("Please sign in your account!");
 window.location.href="./login.php";
 </script>
 ';
}
  ?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Update Profile</title>
    <link rel="stylesheet" href="formstyle.css">
  </head>
  <body>
    <form action="editproaction.php" method="post" style="border:1px solid #ccc">
  <div class="container">
    <h1>Update Profile</h1>
    <p>Please fill in this form to update your account.</p>
    <?php
    if(isset($_GET['status'])){
      $status = $_GET['status'];
      //empty input
      if($status == "emptyinput"){
        echo '<h1 style="color:red;">Please enter all inputs! &#128581;&#8205;&#9794;&#65039;</h1>';
      }
      //invalid input
      else if($status == "invalidinput"){
          echo '<h1 style="color:red;">Please enter all inputs in the correct format! &#128581;&#8205;&#9794;&#65039;</h1>';
      }
      //all valid
      else if($status == "allvalid"){
            echo '<h1 style="color:red;">User profile updated successfully! &#128521;</h1>';
      }
      //testing
      //invalid name
      else if($status == "invalidname"){
          echo '<h1 style="color:red;">Invalid fullname &#128581;&#8205;&#9794;&#65039;</h1>';
      }
      //invalid gender
      else if($status == "invalidgender"){
          echo '<h1 style="color:red;">Invalid gender &#128581;&#8205;&#9794;&#65039;</h1>';
      }
      //invalid year
      else if($status == "invalidyear"){
          echo '<h1 style="color:red;">Invalid birth year &#128581;&#8205;&#9794;&#65039;</h1>';
      }
      //invalid phone Number
      else if($status == "invalidphonenumber"){
          echo '<h1 style="color:red;">Invalid phone number &#128581;&#8205;&#9794;&#65039;</h1>';
      }
      //invalid name gender
      else if($status == "invalidnamegender"){
          echo '<h1 style="color:red;">Invalid fullname and gender &#128581;&#8205;&#9794;&#65039;</h1>';
      }
      //invalid name Year
      else if($status == "invalidnameyear"){
          echo '<h1 style="color:red;">Invalid fullname and birth year &#128581;&#8205;&#9794;&#65039;</h1>';
      }
      //invalid name phone
      else if($status == "invalidnamephone"){
          echo '<h1 style="color:red;">Invalid fullname and phone number &#128581;&#8205;&#9794;&#65039;</h1>';
      }
      //invalid year Gender
      else if($status == "invalidyeargender"){
          echo '<h1 style="color:red;">Invalid birth year and gender &#128581;&#8205;&#9794;&#65039;</h1>';
      }
      //invalid year phone
      else if($status == "invalidyearphone"){
          echo '<h1 style="color:red;">Invalid birth year and phone number &#128581;&#8205;&#9794;&#65039;</h1>';
      }
     //invalid gender phone
     else if($status == "invalidgenderphone"){
         echo '<h1 style="color:red;">Invalid gender and phone number &#128581;&#8205;&#9794;&#65039;</h1>';
     }
     //only name
     else if($status == "onlyname"){
         echo '<h1 style="color:red;">Invalid gender, year and phone number &#128581;&#8205;&#9794;&#65039;</h1>';
     }
     //only Gender
     else if($status == "onlygender"){
         echo '<h1 style="color:red;">Invalid name, year and phone number &#128581;&#8205;&#9794;&#65039;</h1>';
     }
     //only birth Year
     else if($status == "onlyyear"){
         echo '<h1 style="color:red;">Invalid name, gender and phone number &#128581;&#8205;&#9794;&#65039;</h1>';
     }
     //only phone
     else if($status == "onlyphone"){
         echo '<h1 style="color:red;">Invalid name, gender and birth year &#128581;&#8205;&#9794;&#65039;</h1>';
     }

    }
    ?>
    <hr>

    <label for="name"><b>Fullname (The username must begin with an alphabet and may contain a space/number/-/_/.)</b></label>
<?php
	if(isset($_GET['name']) || isset($_SESSION['mname'])){
		if(!isset($_GET['name'])){
		$name = $_SESSION['mname'];
    echo '<input type="text" placeholder="Enter Name" name="name" id="name" value="'.$name.'" required>';
  }else if(!isset($_SESSION['mname'])){
			$name = $_GET['name'];
    echo '<input type="text" placeholder="Enter Name" name="name" id="name" value="'.$name.'" required>';
  }else if(isset($_SESSION['mname']) && isset($_GET['name'])){
				$name = $_SESSION['mname'];
      echo '<input type="text" placeholder="Enter Name" name="name" id="name" value="'.$name.'" required>';
		}
	}else{
		   echo '<input type="text" placeholder="Enter Name" name="name" id="name" required>';
	}
?>



    <label for="gender"><b>Gender</b></label>
      <select name="gender" id="gender" class="selection">

				<?php
        if(isset($_SESSION['mgender']) || isset($_GET['gender'])){
        if($_SESSION['mgender'] == NULL || $_SESSION['mgender'] == "none" || $_GET['gender'] == "none"){
        echo '
        <option value="none" selected>None</option>
        <option value="male">Male</option>
        <option value="female">Female</option>
        ';
      }else if($_SESSION['mgender'] != NULL && $_SESSION['mgender'] != "none" || $_GET['gender'] != "none"){
       if($_SESSION['mgender'] == "male" || $_GET['gender'] == "male"){
         echo '
         <option value="none">None</option>
         <option value="male" selected>Male</option>
         <option value="female">Female</option>
         ';
       }else if($_SESSION['mgender'] == "female" || $_GET['gender'] == "female"){
         echo '
         <option value="none">None</option>
         <option value="male">Male</option>
         <option value="female" selected>Female</option>
         ';
       }

      }

    }else{
      echo '
      <option value="none" selected>None</option>
      <option value="male">Male</option>
      <option value="female">Female</option>
      ';
    }
				?>

      </select>


    <label for="birth-year"><b><?php $currentYear = date("Y");
		 $maxYear = $currentYear - 4;
		 $minYear = $currentYear - 100;
		 echo 'Birth Year ('.$minYear.' - '.$maxYear.')';
		 ?></b></label>

		 <?php
		 $currentYear = date("Y");
		 $maxYear = $currentYear - 4;
		 $minYear = $currentYear - 100;
		 if(isset($_SESSION['mbirthyear']) || isset($_GET['year'])){
			 if(!isset($_GET['year'])){
         if($_SESSION['mbirthyear'] == 0 || $_SESSION['mbirthyear'] == NULL){
           echo
          '
          <input type="number" placeholder="Birth Year" name="year" id="birth-year" min="'.$minYear.'" max="'.$maxYear.'">
          ';
         }else{
           $year = $_SESSION['mbirthyear'];
           echo
           '
           <input type="number" placeholder="Birth Year" name="year" id="birth-year" min="'.$minYear.'" max="'.$maxYear.'" value="'.$year.'">
           ';
         }

			 }else if(!isset($_SESSION['mbirthyear'])){
				 	 $year = $_GET['year'];
				 echo
				'
				<input type="number" placeholder="Birth Year" name="year" id="birth-year" min="'.$minYear.'" max="'.$maxYear.'" value="'.$year.'">
				';
			}else if(isset($_SESSION['mbirthyear']) && isset($_GET['year'])){
        if($_SESSION['mbirthyear'] == 0 || $_SESSION['mbirthyear'] == NULL){
          echo
         '
         <input type="number" placeholder="Birth Year" name="year" id="birth-year" min="'.$minYear.'" max="'.$maxYear.'">
         ';
       }else{
				$year = $_SESSION['mbirthyear'];
			echo
		 '
		 <input type="number" placeholder="Birth Year" name="year" id="birth-year" min="'.$minYear.'" max="'.$maxYear.'" value="'.$year.'">
		 ';
   }
			}
		 }else{
			 echo
			'
			<input type="number" placeholder="Birth Year" name="year" id="birth-year" min="'.$minYear.'" max="'.$maxYear.'">
			';
		 }
		 ?>







    <label for="phoneNumber"><b>Phone Number (Phone number must be in Malaysian format, etc. 60xx-xxxxxxx)</b></label>
		<?php
		if(isset($_GET['phoneNumber']) || isset($_SESSION['mpNumber'])){
			if(!isset($_GET['phoneNumber'])){
				$pNumber = $_SESSION['mpNumber'];
				echo '<input type="text" name="phoneNumber" id="phoneNumber" placeholder="Enter Phone Number" required value="'.$pNumber.'">';
			}else if(!isset($_SESSION['mpNumber'])){
				$pNumber = $_GET['phoneNumber'];
				echo '<input type="text" name="phoneNumber" id="phoneNumber" placeholder="Enter Phone Number" required value="'.$pNumber.'">';
			}else if(isset($_GET['phoneNumber']) && isset($_SESSION['mpNumber'])){
				$pNumber = $_SESSION['mpNumber'];
				echo '<input type="text" name="phoneNumber" id="phoneNumber" placeholder="Enter Phone Number" required value="'.$pNumber.'">';
			}
		}else{
			  echo '<input type="text" name="phoneNumber" id="phoneNumber" placeholder="Enter Phone Number" required>';
		}

		?>



    <div class="clearfix">
      <button type="submit" class="signupbtn" name="update">Update Profile</button>
      <button type="button" class="cancelbtn" onclick="user_profile()">Cancel</button>

    </div>
  </div>
</form>

<script type="text/javascript">
  function user_profile(){
    window.location.href="./user_profile.php";
  }
</script>
  </body>
</html>

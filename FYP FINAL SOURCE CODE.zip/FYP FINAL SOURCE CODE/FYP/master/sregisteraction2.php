<?php

    if(isset($_POST['register'])){ //start1
    require_once 'dataconnection.php';

    $name = mysqli_real_escape_string($connect,$_POST['name']);
    $email = mysqli_real_escape_string($connect,$_POST['email']);
    $pNumber = mysqli_real_escape_string($connect,$_POST['phoneNumber']);
    $password = mysqli_real_escape_string($connect,$_POST['password']);
    $password2 = mysqli_real_escape_string($connect,$_POST['password2']);

	//recaptcha variable
	$secret ="6Lcfkl8mAAAAADYvd9vzdhNkkgUV7CqUmvLPK0Df";
	$response = $_POST['g-recaptcha-response'];
	$remoteip = $_SERVER['REMOTE_ADDR'];
	$URL = "https://www.google.com/recaptcha/api/siteverify?secret=$secret&response=$response&remoteip=$remoteip";
	$data = file_get_contents($URL);
	$Recaptcha = json_decode($data,true);

	if($Recaptcha['success'] == true){

    //all empty
    if(empty($name) || empty($email) || empty($pNumber) || empty($password) || empty($password2)){//start2
        header("Location:./sregister.php?status=ALLemptyinput&name=".$name."&email=".$email."&phoneNumber=".$pNumber);
        exit();
/*end2*/}else{ //start3

		//v == valid;
		$vname = preg_match('/^(?=[a-zA-Z])[a-zA-Z0-9 ._-]{8,60}$/',$name);
		$vemail = filter_var($email,FILTER_VALIDATE_EMAIL);
		$vemailRegex = preg_match('/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/',$email);
		$vpNumber = preg_match('/^60\d{2}-\d{7,8}$/',$pNumber);
		$vpassword = preg_match('/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^\w\s]).{12,}$/',$password);
    $vpassword2 = preg_match('/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^\w\s]).{12,}$/',$password2);
        //all invalid
        if(!$vname && (!$vemail || !$vemailRegex) && !$vpNumber && !$vpassword){
        header("Location:./sregister.php?status=ALLinvalidinput");
        exit();
        }

        //all valid
        else if($vname && ($vemail && $vemailRegex) && $vpNumber && $vpassword){
          if(!$vpassword2 || $password2 != $password){
            header("Location:./sregister.php?status=thepassword2isnotsamewithpassword&name=".$name."&email=".$email."&phoneNumber=".$pNumber);
            exit();
          }else{
            //prepare statement
            $sql = "SELECT staff_email FROM staff WHERE staff_email =?";
            $stmt = mysqli_stmt_init($connect);
            if(!mysqli_stmt_prepare($stmt,$sql)){
              header("Location:./sregister.php?status=sqlerror");
              exit();
            }else{
              mysqli_stmt_bind_param($stmt, "s", $email);
              mysqli_stmt_execute($stmt);
              mysqli_stmt_store_result($stmt);
              $emailRow = mysqli_stmt_num_rows($stmt);
              if($emailRow > 0){
                header("Location:./sregister.php?status=emailtaken&name=".$name."&phoneNumber=".$pNumber);
                //The email address has been taken!
                exit();
              }else{
                $sql1 = "INSERT INTO staff(staff_name,staff_email,staff_phoneNumber,staff_password) VALUES (?,?,?,?)";
                $stmt1 = mysqli_stmt_init($connect);
                if(!mysqli_stmt_prepare($stmt1,$sql1)){
                  header("Location:./sregister.php?status=sqlerror");
                  exit();
                }else{

                  $hashPass = password_hash($password,PASSWORD_DEFAULT);
                  mysqli_stmt_bind_param($stmt1,"ssss",$name,$email,$pNumber,$hashPass);
                  mysqli_stmt_execute($stmt1);
                  mysqli_stmt_store_result($stmt1);
                  header("Location:./sregister.php?status=registered");
                }
                mysqli_stmt_close($stmt1);
              }

            }

                  mysqli_stmt_close($stmt);
            mysqli_close($connect);

            //prepare end
          }



        }

        //invalid username email phone
        else if(!$vname && (!$vemail || !$vemailRegex) && !$vpNumber && $vpassword){
	    header("Location:./sregister.php?status=invalidusernameemailphone");
        exit();
		}
		//invalid username email password
		else if(!$vname && (!$vemail || !$vemailRegex) && $vpNumber && !$vpassword){
		header("Location:./sregister.php?status=invalidusernameemailpassword&phoneNumber=".$pNumber);
        exit();
		}
		//invalid username phone password
		else if(!$vname && ($vemail && $vemailRegex) && !$vpNumber && !$vpassword){
		header("Location:./sregister.php?status=invalidusernamephonepassword&email=".$email);
        exit();
		}
		//invalid email phone password
		else if($vname && (!$vemail || !$vemailRegex) && !$vpNumber && !$vpassword){
		header("Location:./sregister.php?status=invalidemailphonepassword&name=".$name);
        exit();
		}
		//invalid username email
		else if(!$vname && (!$vemail || !$vemailRegex) && $vpNumber && $vpassword){
		header("Location:./sregister.php?status=invalidusernameemail&phoneNumber=".$pNumber);
        exit();
		}
		//invalid username password
		else if(!$vname && ($vemail && $vemailRegex) && $vpNumber && !$vpassword){
		header("Location:./sregister.php?status=invalidusernamepassword&email=".$email."&phoneNumber=".$pNumber);
        exit();
		}
		//invalid username phone
		else if(!$vname && ($vemail && $vemailRegex) && !$vpNumber && $vpassword){
			header("Location:./sregister.php?status=invalidusernamephone&email=".$email);
		}
		//invalid phone password
		else if($vname && ($vemail && $vemailRegex) && !$vpNumber && !$vpassword){
		header("Location:./sregister.php?status=invalidphonepassword&name=".$name."&email=".$email);
        exit();
		}
		//invalid email phone
		else if($vname && (!$vemail || !$vemailRegex) && !$vpNumber && $vpassword){
		header("Location:./sregister.php?status=invalidemailphone&name=".$name);
        exit();
		}
		//invalid email password
		else if($vname && (!$vemail || !$vemailRegex) && $vpNumber && !$vpassword){
		header("Location:./sregister.php?status=invalidemailpassword&name=".$name."&phoneNumber=".$pNumber);
        exit();
		}

		//invalid username
		else if(!$vname && ($vemail && $vemailRegex) && $vpNumber && $vpassword){
		header("Location:./sregister.php?status=invalidusername&email=".$email."&phoneNumber=".$pNumber);
        exit();
		}
		//invalid password
		else if($vname && ($vemail && $vemailRegex) && $vpNumber && !$vpassword){
		header("Location:./sregister.php?status=invalidpassword&name=".$name."&email=".$email."&phoneNumber=".$pNumber);
        exit();
		}
		//invalid phone
		else if($vname && ($vemail && $vemailRegex) && !$vpNumber && $vpassword){
		header("Location:./sregister.php?status=invalidphone&name=".$name."&email=".$email);
        exit();
		}
		//invalid email
		else if($vname && (!$vemail || !$vemailRegex) && $vpNumber && $vpassword){
		header("Location:./sregister.php?status=invalidemail&name=".$name."&phoneNumber=".$pNumber);
        exit();
		}

    }//end3
	}else{//recaptcha else
		header("Location:./sregister.php?status=emptyrecaptcha&name=".$name."&email=".$email."&phoneNumber=".$pNumber);
		exit();
	}//recaptcha end
}//end1

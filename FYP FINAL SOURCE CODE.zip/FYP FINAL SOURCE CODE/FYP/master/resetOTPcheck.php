
<?php
session_start();
if(!isset($_SESSION['mid']) || !isset($_SESSION['mname']) || !isset($_SESSION['memail'])){
 echo '
 <script>
 alert("Please sign in your account!");
 window.location.href="./login.php";
 </script>
 ';
}else{
 require_once 'dataconnection.php';

}

?>

<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Reset Password OTP</title>
	<link rel="stylesheet" href="formstyle.css">
</head>

<body>
	<form action="resetOTPcheck.php" method="post" style="border:1px solid #ccc">
		<div class="container">
			<h1>Reset Password OTP</h1>
			<p>Please input the OTP to reset password.</p>
			<p style="color:red;">The OTP will expire in 5 minutes.</p>

			<hr>

			<label for="otp"><b>Reset Password OTP</b></label>
			<input type="number" placeholder="Enter OTP" name="otp" id="otp" min="0" required>

			<div class="clearfix">
				<button type="submit" class="signupbtn" name="otp-check">Submit</button>
			</div>

		</div>
	</form>
</body>

</html>
<?php

    if(isset($_POST['otp-check'])){
			if(time() <= $_SESSION['mResetPassvExpiredTime']){
				$otp = mysqli_real_escape_string($connect,$_POST['otp']);
				if(empty($_POST['otp'])){
						echo
						"
						<script>
						alert('Please input OTP!');
						</script>
						";
				}else{
						$vOTP = preg_match('/^\d{6}$/',$otp);
						if($vOTP){
								if(password_verify($otp,$_SESSION["mResetPassOTP"])){
									if(isset($_SESSION['mtheHashedNewPasswordis'])){
											$theHashedNewPasswordis = $_SESSION['mtheHashedNewPasswordis'];
											$sql = "UPDATE master SET master_password = ? WHERE master_id = ? && master_email = ?";
										$stmt = mysqli_stmt_init($connect);
										if(!mysqli_stmt_prepare($stmt,$sql)){
												echo
												"
												<script>
												alert('Sorry SQL error!');
												</script>
												";
										}else{

				mysqli_stmt_bind_param($stmt, "sss", $theHashedNewPasswordis ,$_SESSION['mid'],$_SESSION['memail']);
				mysqli_stmt_execute($stmt);

												echo
												"
												<script>
												alert('Reset password successfully!');
												  document.location.href='user_profile.php';
												</script>
												";

				}
					mysqli_stmt_close($stmt);
					mysqli_close($connect);
									}else{
				echo
					'
				<script>
				alert("Sorry, the reset password system got into trouble. Please try it later.");
				</script>
				';
									}




				}else if(!password_verify($vOTP,$_SESSION['mResetPassOTP'])){
				 echo
				"
				<script>
				alert('Invalid OTP!');
				</script>
				";
				}

			}else{
				echo
				"
				<script>
				alert('Invalid OTP!');
				</script>
				";
			}
				}



			}else if(time() > $_SESSION['mResetPassvExpiredTime']){
				//alert user
				echo
				'
				<script>
				alert("The OTP has expired! Please click the "Reapply" button to reapply again to reset your password.");
				</script>
				';

				//clear session
				unset($_SESSION["mResetPassOTP"]);
				unset($_SESSION["mtheHashedNewPasswordis"]);

				//output the resend button
				echo '
				<br>
				<br>
				';
				echo '<a href="./resetPass.php" style="display: inline-block; padding: 10px 20px; background-color: #4CAF50; color: white; text-decoration: none; border-radius: 4px; border: none; text-align: center; cursor: pointer;">Reapply</a>';

			}

















    }
?>

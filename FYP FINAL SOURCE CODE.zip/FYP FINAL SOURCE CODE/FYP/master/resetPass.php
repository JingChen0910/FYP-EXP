<?php
session_start();
 if(!isset($_SESSION['mid']) || !isset($_SESSION['mname']) || !isset($_SESSION['memail'])){
	echo '
	<script>
	alert("Please sign in your account!");
	window.location.href="./login.php";
	</script>
	';
 }else{
	require_once 'dataconnection.php';
 }
?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
    <link rel="stylesheet" href="formstyle.css">
  </head>
  <body>
    <form action="./resetPassAct.php" method="post" style="border:1px solid #ccc">
  <div class="container">
    <h1>Reset Password</h1>
    <p>Please fill in this form to reset password.</p>
		<?php
			if(!isset($_GET['status'])){

			}else if(isset($_GET['status'])){
				$status = $_GET['status'];

				//all empty
				if($status == "emptyinput"){
					echo '<h1 style="color:red;">Please enter all inputs! &#128581;&#8205;&#9794;&#65039;</h1>';
				}

				//all invalid
				else if($status == "allinvalid"){
				    echo '<h1 style="color:red;">Please enter all inputs in the correct format! &#128581;&#8205;&#9794;&#65039;</h1>';
				}
				//all valid
				// else if($status == "valid"){
				// 	echo '<h1 style="color:red;">Please enter all inputs! &#128581;&#8205;&#9794;&#65039;</h1>';
				// }
				//only current pass invalid
				else if($status == "invalidcurrentpass"){
					echo '<h1 style="color:red;">Invalid current password! &#128581;&#8205;&#9794;&#65039;</h1>';
				}
				//invalid new pass
				else if($status == "invalidnewpass"){
					echo '<h1 style="color:red;">Invalid new password! &#128581;&#8205;&#9794;&#65039;</h1>';
				}
				//invalid new pass repeat
				else if($status == "invalidnewpassrepeat"){
					echo '<h1 style="color:red;">Invalid comfirm new password! &#128581;&#8205;&#9794;&#65039;</h1>';
				}
				//only password valid
				else if($status == "onlypassvalid"){
					echo '<h1 style="color:red;">Invalid new password and comfirm new password! &#128581;&#8205;&#9794;&#65039;</h1>';
				}
				//only new pass valid
				else if($status == "onlynewpassvalid"){
					echo '<h1 style="color:red;">Invalid current password and comfirm new password! &#128581;&#8205;&#9794;&#65039;</h1>';
				}
				//only new password repeat valid
				else if($status == "onlynewpassrvalid"){
					echo '<h1 style="color:red;">Invalid current password and new password! &#128581;&#8205;&#9794;&#65039;</h1>';
				}

				//sql error
				else if($status == "sqlerror"){
						echo '<h1 style="color:red;">Sorry, reset password got trouble. &#128581;&#8205;&#9794;&#65039;</h1>';
				}
				//new pass same with current passs
				else if($status == "newpasssamewithcurrentpass"){
						echo '<h1 style="color:red;">The new password is the same as the current password! &#128581;&#8205;&#9794;&#65039;</h1>';
				}
				//new pass  is not same with repeat new pass
				else if($status == "newpassisnotsamewithnewpassr"){
					echo '<h1 style="color:red;">The confirm new password does not match the new password! &#128581;&#8205;&#9794;&#65039;</h1>';
				}
				//new pass is same with current pass and new pass is not same with repeat new password
				else if($status == "newpassissamewithcurrentpassandnewpassisnotsamewithnewpassr"){
						echo '<h1 style="color:red;">The new password is the same as the current password, and the confirm new password does not match the new password! &#128581;&#8205;&#9794;&#65039;</h1>';
				}

				//incorrectcurrentpass
				else if($status == "incorrectcurrentpass"){
						echo '<h1 style="color:red;">The current password is wrong! &#128581;&#8205;&#9794;&#65039;</h1>';
				}

			}
		 ?>
    <hr>


    <label for="psw"><b>Current Password</b></label>
    <input type="password" placeholder="Enter Password" name="pass" id="psw1" required>

    <label for="show1">
      <input type="checkbox" onclick="showPassword1()" name="show" id="show1" style="margin-bottom:15px">Show Current Password
    </label>

    <br>
		<br>

    <label for="psw-repeat"><b>New Password (Password must be at least 12 characters long, and it must include at least one uppercase, lowercase,special chracter, and numeric)</b></label>
    <input type="password" placeholder="Enter New Password" name="newPass" id="psw2" required>

    <label for="show2">
      <input type="checkbox" onclick="showPassword2()" name="show" id="show2" style="margin-bottom:15px">Show New Password
    </label>

    <br>
		<br>

    <label for="psw-repeat"><b>Comfirm New Password</b></label>
    <input type="password" placeholder="Comfirm New Password" name="newPassR" id="psw3" required>

    <label for="show3">
      <input type="checkbox" onclick="showPassword3()" name="show" id="show3" style="margin-bottom:15px">Show Repeat New Password
    </label>

    <div class="clearfix">
      <button type="submit" class="signupbtn" name="reset">Reset Password</button>
      <button type="button" class="cancelbtn" name="cancel" onclick="user_profile()">Cancel</button>

    </div>
  </div>
</form>
<script type="text/javascript">
  function showPassword1() {
    var show1 = document.getElementById("psw1");
    if (show1.type == "password") {
      show1.type = "text";
    } else if(show1.type == "text"){
      show1.type = "password";
    }
  }
  function showPassword2() {
    var show2 = document.getElementById("psw2");
    if (show2.type == "password") {
      show2.type = "text";
    } else if(show2.type == "text"){
      show2.type = "password";
    }
  }
  function showPassword3() {
    var show3 = document.getElementById("psw3");
    if (show3.type == "password") {
      show3.type = "text";
    } else if(show3.type == "text"){
      show3.type = "password";
    }
  }
  function user_profile(){
    window.location.href="./user_profile.php";
  }
</script>
  </body>
</html>

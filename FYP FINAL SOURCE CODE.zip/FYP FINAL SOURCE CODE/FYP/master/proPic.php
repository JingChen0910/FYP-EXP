<?php
session_start();
require_once 'dataconnection.php';
if(!isset($_SESSION['mid']) || !isset($_SESSION['mname']) || !isset($_SESSION['memail'])){
 echo '
 <script>
 alert("Please sign in your account!");
 window.location.href="./login.php";
 </script>
 ';
}


if(isset($_POST['upload'])){
	$picture = $_FILES['picture'];


	if(!empty($_FILES['picture'])){
$pictureName = $_FILES['picture']['name'];
	$pictureTmpName = $_FILES['picture']['tmp_name'];
	$pictureSize = $_FILES['picture']['size'];
	$pictureError = $_FILES['picture']['error'];
	$pictureType = $_FILES['picture']['type'];

	$pictureExtension = explode('.',$pictureName);
	$pictureActualExtension = strtolower(end($pictureExtension));

	$pictureAllowedExtension = array('jpg','jpeg','png');
	if(in_array($pictureActualExtension,$pictureAllowedExtension)){
		if($pictureError === 0){
			if($pictureSize <= 1000000){
				$sql1 = "SELECT master_profile_picture FROM master WHERE master_id='".$_SESSION['mid']."';";
				$result = mysqli_query($connect,$sql1);
				if($row1 = mysqli_fetch_assoc($result)){
					$databaseProfilePicture= $row1['master_profile_picture'];
					if($databaseProfilePicture == "default.png"){
						$newPictureName = "spicture".$_SESSION['mid'].".".$pictureActualExtension;
						$pictureLocation = "./master_propic/".$newPictureName;
						if(move_uploaded_file($pictureTmpName, $pictureLocation)){
						$sql =  "UPDATE master SET master_profile_picture= '".$newPictureName."' WHERE master_id='".$_SESSION['mid']."';";
						if(mysqli_query($connect,$sql)){
              echo
  "
  <script>
  alert('Profile picture upload success!');
  document.location.href='user_profile.php';
  </script>
  ";
  exit();
						}else{
              echo
        "
        <script>
        alert('Profile picture upload success but failure to update the database!');
        document.location.href='user_profile.php';
        </script>
        ";
        exit();
						}
						}else{
              echo
      "
      <script>
      alert('Profile picture upload fails!');
      document.location.href='user_profile.php';
      </script>
      ";
      exit();
						}
					}else{
						$documentCustomerPicture = "./master_propic/".$databaseProfilePicture;
						if(!unlink($documentCustomerPicture)){
              echo
        "
        <script>
        alert('Fail to delete the old profile picture file!');
        document.location.href='user_profile.php';
        </script>
        ";
        exit();
						}else{
							$newPictureName = "spicture".$_SESSION['mid'].".".$pictureActualExtension;
							$pictureLocation = "./master_propic/".$newPictureName;
							if(move_uploaded_file($pictureTmpName, $pictureLocation)){
							$sql =  "UPDATE master SET master_profile_picture= '".$newPictureName."' WHERE master_id='".$_SESSION['mid']."';";
							if(mysqli_query($connect,$sql)){
                echo
          "
          <script>
          alert('Profile picture update success!');
          document.location.href='user_profile.php';
          </script>
          ";
          exit();
							}else{
                echo
              "
              <script>
              alert('Profile picture upload success but failure to update the database!');
              document.location.href='user_profile.php';
              </script>
              ";
              exit();
							}
							}else{
                echo
      "
      <script>
      alert('Profile picture upload fails!');
      document.location.href='user_profile.php';
      </script>
      ";
      exit();
							}
						}
					}
				}else{
          echo
    "
    <script>
    alert('Fail to check the database customer profile picture!');
    document.location.href='user_profile.php';
    </script>
    ";
    exit();
				}

			}else{
        echo
      "
      <script>
      alert('The profile picture cannot be bigger than 1000000B, 1000KB, or 1MB!');
      document.location.href='user_profile.php';
      </script>
      ";
      exit();
			}
		}else{
      echo
  "
  <script>
  alert('Profile picture upload fails!');
  document.location.href='user_profile.php';
  </script>
  ";
  exit();
		}
	}else{
    echo
  "
  <script>
  alert('The profile picture type only accepts jpg, jpeg, and png!');
  document.location.href='user_profile.php';
  </script>
  ";
  exit();
	}
}else{
  echo
"
<script>
alert('Please select your profile picture to upload!');
document.location.href='user_profile.php';
</script>
";
exit();
}

}

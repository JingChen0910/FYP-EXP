<?php

$connect= mysqli_connect("localhost","root","","online_bookstore");// fill out database name

if (!$connect) {
    die("Connection failed: " . mysqli_connect_error());
  }
  
?>


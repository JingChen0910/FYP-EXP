<?php
if(isset($_POST['login'])){
    require_once './dataconnection.php';

    $email = mysqli_real_escape_string($connect,$_POST['email']);
    $password = mysqli_real_escape_string($connect,$_POST['password']);

    //recaptcha
    $secret ="6Lcfkl8mAAAAADYvd9vzdhNkkgUV7CqUmvLPK0Df";
	$response = $_POST['g-recaptcha-response'];
	$remoteip = $_SERVER['REMOTE_ADDR'];
	$URL = "https://www.google.com/recaptcha/api/siteverify?secret=$secret&response=$response&remoteip=$remoteip";
	$data = file_get_contents($URL);
	$Recaptcha = json_decode($data,true);

    if($Recaptcha['success'] == true){
        if(empty($email) || empty($password)){
            header("Location:./login.php?status=ALLemptyinput");
        }else{
            $vemail = filter_var($email,FILTER_VALIDATE_EMAIL);
            $vemailRegex = preg_match('/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/',$email);
            $vpassword = preg_match('/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^\w\s]).{12,}$/',$password);

            //all invalid
            if((!$vemail || !$vemailRegex) && !$vpassword){
                header("Location:./login.php?status=ALLinvalidformat");
                exit();
                }
            //invalid email
			else if((!$vemail || !$vemailRegex)){
				header("Location:./login.php?status=wrongemailorpassword");
                exit();
			}
			//invalid password
			else if(!$vpassword){
				header("Location:./login.php?status=wrongemailorpassword");
				exit();
			}
            //all valid
            else if(($vemail && $vemailRegex) && $vpassword){
            $sqlS = "SELECT * FROM staff WHERE staff_email=?;";
            $stmtS = mysqli_stmt_init($connect);
            if(!mysqli_stmt_prepare($stmtS,$sqlS)){
              header("Location:./login.php?status=sqlerror");
            }else{
              mysqli_stmt_bind_param($stmtS,"s",$email);
              mysqli_stmt_execute($stmtS);
              $resultS = mysqli_stmt_get_result($stmtS);
              if($rowS = mysqli_fetch_assoc($resultS)){
                $checkStaffPass = password_verify($password,$rowS['staff_password']);
                //login staff
                if($checkStaffPass == true){
                  session_start();
                  $_SESSION['Staffid'] = $rowS['staff_id'];
                  $_SESSION['Staffname'] = $rowS['staff_name'];
                  $_SESSION['Staffemail'] = $rowS['staff_email'];
                  header("Location:../staff/index.php");
                  exit();
                }else if($checkStaffPass == false){
                  header("Location:./login.php?status=wrongemailorpassword");
                  exit();
                }else{
                  header("Location:./login.php?status=wrongemailorpassword");
                  exit();
                }
              }else{
                //if staff account not found check master
                $sqlM = "SELECT * FROM master WHERE master_email = ?;";
                $stmtM = mysqli_stmt_init($connect);
                if(!mysqli_stmt_prepare($stmtM,$sqlM)){
                  header("Location:./login.php?status=sqlerror");
                  exit();
                }else{
                  mysqli_stmt_bind_param($stmtM,"s",$email);
                  mysqli_stmt_execute($stmtM);
                  $resultM = mysqli_stmt_get_result($stmtM);
                  if($rowM = mysqli_fetch_assoc($resultM)){
                    $checkMasterPass = password_verify($password,$rowM['master_password']);
                    if($checkMasterPass == true){
                      //login master
                      session_start();
                      $_SESSION['mid'] = $rowM['master_id'];
                      $_SESSION['mname'] = $rowM['master_name'];
                      $_SESSION['memail'] = $rowM['master_email'];
                      header("Location:./index.php");
                    }else if($checkMasterPass == false){
                      header("Location:./login.php?status=wrongemailorpassword");
                      exit();
                    }else{
                      header("Location:./login.php?status=wrongemailorpassword");
                      exit();
                    }

                  }else{
					  //account not found
                    header("Location:./login.php?status=accountnotfound");
                    exit();
                  }

                }
              }
            }
    mysqli_stmt_close($stmtS);
    mysqli_stmt_close($stmtM);
    mysqli_close($connect);
   }




  }
 }else{//recaptcha else
		header("Location:./login.php?status=emptyrecaptcha");
		exit();
}
}

<?php

session_start();
 if(!isset($_SESSION['mid']) || !isset($_SESSION['mname']) || !isset($_SESSION['memail'])){
	echo '
	<script>
	alert("Please sign in your account!");
	window.location.href="./login.php";
	</script>
	';
 }else{
    // Include the database connection file
	include("dataconnection.php");
 }


// Check if product ID was provided
if(isset($_GET['id'])) {
    $id = $_GET['id'];

    // Delete the product from the database
    $query = "UPDATE product SET availability = 1 WHERE product_id = '$id'";
    mysqli_query($connect, $query);

    header("Location: manage_product.php");
} else {

    header("Location: manage_product.php");
}
?>

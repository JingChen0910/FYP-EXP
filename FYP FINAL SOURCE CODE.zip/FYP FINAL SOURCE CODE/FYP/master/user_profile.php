<?php
session_start();
require_once 'dataconnection.php';
if(!isset($_SESSION['mid']) || !isset($_SESSION['mname']) || !isset($_SESSION['memail'])){
 echo '
 <script>
 alert("Please sign in your account!");
 window.location.href="./login.php";
 </script>
 ';
}
//customer information
$sql = "SELECT * FROM master WHERE master_id = '".$_SESSION['mid']."';";
$result = mysqli_query($connect,$sql);
if($row = mysqli_fetch_assoc($result)){
	$_SESSION['mid'] = $row['master_id'];
	$_SESSION['memail'] = $row['master_email'];
	$_SESSION['mname'] = $row['master_name'];
	$_SESSION['mgender'] = $row['master_gender'];
	$_SESSION['mbirthyear'] = $row['master_birthyear'];
	$_SESSION['mpNumber'] = $row['master_phoneNumber'];
	$_SESSION['mpicture'] = $row['master_profile_picture'];

}else{
	echo "<script>alert('Database error!');</script>";
}

//customer addresss
// $sql2 = "SELECT * FROM address WHERE customer_id = '".$_SESSION['id']."';";
// $result2 = mysqli_query($connect, $sql2);
// $Checkresult = mysqli_num_rows($result2);
//
//
//
// if($Checkresult > 0 ){
// 		if($row2 = mysqli_fetch_assoc($result2)){
// 		$_SESSION['addressID'] = $row2['address_id'];
// 		$address1 = $row2['address1'];
// 		$address2 =  $row2['address2'];
// 		$state =  $row2['state'];
// 		$city =  $row2['city'];
// 		$postCode =  $row2['postalCode'];
//
// 		}else{
// 			echo "<script>alert('Database error!');</script>";
// 		}
//
// }else{
//
// 	$address1 = "--";
// 	$address2 = "--";
// 	$state = "--";
// 	$city = "--";
// 	$postCode = "--";
// }

?>
<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>User Profile</title>
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
	<link rel="stylesheet" href="profilestyle.css">
</head>

<body>
	<!-- Breadcrumb -->
	<!-- <nav aria-label="breadcrumb" class="main-breadcrumb">
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="index.html">Home</a></li>
              <li class="breadcrumb-item"><a href="javascript:void(0)">User</a></li>
              <li class="breadcrumb-item active" aria-current="page">User Profile</li>
            </ol>
          </nav> -->
	<!-- /Breadcrumb -->

	<div class="row gutters-sm">
		<div class="col-md-4 mb-3">
			<div class="card">
				<div class="card-body">
					<div class="d-flex flex-column align-items-center text-center">
						<img src="./master_propic/<?php echo $_SESSION['mpicture']; ?>" alt="Profile Picture" class="rounded-circle" width="150">
						<div class="mt-3">
							<h4><?php echo $_SESSION['mname']; ?></h4>
							<!-- <p class="text-secondary mb-1">Full Stack Developer</p>
                      <p class="text-muted font-size-sm">Bay Area, San Francisco, CA</p> -->
							<form action="proPic.php" method="post" enctype="multipart/form-data">
								<input type="file" class="btn btn-info" name="picture">
								<br>
								<br>
								<input type="submit" name="upload" class="btn btn-info" value="Upload Profile Picture">
							</form>
							<hr>
							<?php
							if($_SESSION['mpicture'] == "default.png"){

							}else{
								echo '
								<form action="deletePic.php" method="POST" enctype="multipart/form-data">
									<button class="btn btn-outline-danger" value="'.$_SESSION['mid'].'" name="delete">Delete Profile Picture</button>
								</form>
								';
							}
							?>


						</div>
					</div>
				</div>
			</div>

			<!-- addrees start -->

			<!-- address end -->
		</div>

		<div class="col-md-8">
			<div class="card mb-3">
				<div class="card-body">
					<div class="row">
						<div class="col-sm-3">
							<h6 class="mb-0">ID</h6>
						</div>
						<div class="col-sm-9 text-secondary">
							<?php echo $_SESSION['mid']; ?>
						</div>
					</div>
					<hr>
					<div class="row">
						<div class="col-sm-3">
							<h6 class="mb-0">Name</h6>
						</div>
						<div class="col-sm-9 text-secondary">
							<?php echo $_SESSION['mname']; ?>
						</div>
					</div>
					<hr>
					<div class="row">
						<div class="col-sm-3">
							<h6 class="mb-0">Gender</h6>
						</div>
						<div class="col-sm-9 text-secondary">
							<?php
						if($_SESSION['mgender'] == null || $_SESSION['mgender'] == "none"){
							echo "-";
						}else{
							echo $_SESSION['mgender'];
							} ?>
						</div>
					</div>
					<hr>
					<div class="row">
						<div class="col-sm-3">
							<h6 class="mb-0">Birth Year</h6>
						</div>
						<div class="col-sm-9 text-secondary">
							<?php if($_SESSION['mbirthyear'] == NULL || $_SESSION['mbirthyear'] == 0){
							echo "-";
						}else{
							echo $_SESSION['mbirthyear'];
						}
						?>
						</div>
					</div>
					<hr>
					<div class="row">
						<div class="col-sm-3">
							<h6 class="mb-0">Phone Number</h6>
						</div>
						<div class="col-sm-9 text-secondary">
							<?php echo $_SESSION['mpNumber']; ?>
						</div>
					</div>
					<hr>
					<div class="row">
						<div class="col-sm-3">
							<h6 class="mb-0">Email</h6>
						</div>
						<div class="col-sm-9 text-secondary">
							<?php echo $_SESSION['memail']; ?>
						</div>
					</div>
					<hr>
					<div class="row">
						<div class="col-sm-12">
							<br>
							<a class="btn btn-info " href="./editprofile.php">Edit</a>
							<a class="btn btn-info " href="./resetPass.php">Reset Password</a>
							<a class="btn btn-info " href="resetEmail.php">Reset Email</a>
							<a href="./index.php" class="btn btn-info">Back</a>
						</div>
					</div>
				</div>
			</div>

			<!--
              <div class="row gutters-sm">
                <div class="col-sm-6 mb-3">
                  <div class="card h-100">
                    <div class="card-body">
                      <h6 class="d-flex align-items-center mb-3"><i class="material-icons text-info mr-2">assignment</i>Project Status</h6>
                      <small>Web Design</small>
                      <div class="progress mb-3" style="height: 5px">
                        <div class="progress-bar bg-primary" role="progressbar" style="width: 80%" aria-valuenow="80" aria-valuemin="0" aria-valuemax="100"></div>
                      </div>
                      <small>Website Markup</small>
                      <div class="progress mb-3" style="height: 5px">
                        <div class="progress-bar bg-primary" role="progressbar" style="width: 72%" aria-valuenow="72" aria-valuemin="0" aria-valuemax="100"></div>
                      </div>
                      <small>One Page</small>
                      <div class="progress mb-3" style="height: 5px">
                        <div class="progress-bar bg-primary" role="progressbar" style="width: 89%" aria-valuenow="89" aria-valuemin="0" aria-valuemax="100"></div>
                      </div>
                      <small>Mobile Template</small>
                      <div class="progress mb-3" style="height: 5px">
                        <div class="progress-bar bg-primary" role="progressbar" style="width: 55%" aria-valuenow="55" aria-valuemin="0" aria-valuemax="100"></div>
                      </div>
                      <small>Backend API</small>
                      <div class="progress mb-3" style="height: 5px">
                        <div class="progress-bar bg-primary" role="progressbar" style="width: 66%" aria-valuenow="66" aria-valuemin="0" aria-valuemax="100"></div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="col-sm-6 mb-3">
                  <div class="card h-100">
                    <div class="card-body">
                      <h6 class="d-flex align-items-center mb-3"><i class="material-icons text-info mr-2">assignment</i>Project Status</h6>
                      <small>Web Design</small>
                      <div class="progress mb-3" style="height: 5px">
                        <div class="progress-bar bg-primary" role="progressbar" style="width: 80%" aria-valuenow="80" aria-valuemin="0" aria-valuemax="100"></div>
                      </div>
                      <small>Website Markup</small>
                      <div class="progress mb-3" style="height: 5px">
                        <div class="progress-bar bg-primary" role="progressbar" style="width: 72%" aria-valuenow="72" aria-valuemin="0" aria-valuemax="100"></div>
                      </div>
                      <small>One Page</small>
                      <div class="progress mb-3" style="height: 5px">
                        <div class="progress-bar bg-primary" role="progressbar" style="width: 89%" aria-valuenow="89" aria-valuemin="0" aria-valuemax="100"></div>
                      </div>
                      <small>Mobile Template</small>
                      <div class="progress mb-3" style="height: 5px">
                        <div class="progress-bar bg-primary" role="progressbar" style="width: 55%" aria-valuenow="55" aria-valuemin="0" aria-valuemax="100"></div>
                      </div>
                      <small>Backend API</small>
                      <div class="progress mb-3" style="height: 5px">
                        <div class="progress-bar bg-primary" role="progressbar" style="width: 66%" aria-valuenow="66" aria-valuemin="0" aria-valuemax="100"></div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
-->



		</div>
	</div>

	</div>
	</div>










	<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
	<script type=text/javascript>
		function editAddre(){
			window.href.location.href="./editaddre.php";
		}
	</script>
</body>

</html>

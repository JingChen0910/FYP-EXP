<?php
session_start();
if(!isset($_SESSION['mid']) || !isset($_SESSION['mname']) || !isset($_SESSION['memail'])){
 echo '
 <script>
 alert("Please sign in your account!");
 window.location.href="./login.php";
 </script>
 ';
}else{
 require_once 'dataconnection.php';

}


	if(isset($_POST['update'])){
		$name = mysqli_real_escape_string($connect,$_POST['name']);
		$gender = mysqli_real_escape_string($connect,$_POST['gender']);
		$gender = strtolower($gender);
		$year = mysqli_real_escape_string($connect,$_POST['year']);
		$pNumber = mysqli_real_escape_string($connect,$_POST['phoneNumber']);

		//all empty
		if(empty($name) || empty($pNumber) || empty($gender)){  //|| empty($year)
			header("Location:./editprofile.php?status=emptyinput");
			exit();
		}else{
			$vname = preg_match('/^(?=[a-zA-Z])[a-zA-Z0-9 ._-]{8,60}$/',$name);
			$vgender = preg_match('/^(male|female|none)$/',$gender);
			$currentYear = date ("Y");
			$maxYear = $currentYear-4;
			$minYear = $currentYear-100;
			$vYear = null;
      if(empty($year)){
        $vYear = true;
      }else if($year >= $minYear && $year <= $maxYear){
				$vYear = true;
			}else{
				$vYear = false;
			}
			$vpNumber = preg_match('/^60\d{2}-\d{7,8}$/',$pNumber);

			//all invalid input
			if(!$vname && !$vgender && $vYear == false && !$vpNumber){
				header("Location:./editprofile.php?status=invalidinput");
				exit();
			}
			//all valid input
			else if($vname && $vgender && $vYear == true && $vpNumber){
				$sql = "UPDATE master SET master_name = ?, master_gender = ?, master_birthyear = ?, master_phoneNumber = ? where master_id = ?";
				$stmt = mysqli_stmt_init($connect);
				if(!mysqli_stmt_prepare($stmt,$sql)){
								header("Location:./editprofile.php?status=sqlerror");
								exit();
				}else{
					mysqli_stmt_bind_param($stmt , "ssiss", $name, $gender, $year, $pNumber, $_SESSION['mid']);
					mysqli_stmt_execute($stmt);
					$_SESSION['mname'] = $name;
					$_SESSION['mgender'] = $gender;
					$_SESSION['mbirthyear'] = $year;
					$_SESSION['mpNumber'] = $pNumber;
							header("Location:./editprofile.php?status=allvalid");
							exit();
				}
				mysqli_stmt_close($stmt);
				mysqli_close($connect);
			}

			//invalid name
			else if(!$vname && $vgender && $vYear == true && $vpNumber){
					header("Location:./editprofile.php?status=invalidname&gender=".$gender."year=".$year."&phoneNumber=".$pNumber);
					exit();
			}
			//invalid Gender
			else if($vname && !$vgender && $vYear == true && $vpNumber){
					header("Location:./editprofile.php?status=invalidgender&name=".$name."&year=".$year."&phoneNumber=".$pNumber);
					exit();
			}
			//invalid birth Year
			else if($vname && $vgender && $vYear == false && $vpNumber){
					header("Location:./editprofile.php?status=invalidyear&name=".$name."&gender=".$gender."&phoneNumber=".$pNumber);
					exit();
			}
			//invalid phone number
			else if($vname && $vgender && $vYear == true && !$vpNumber){
					header("Location:./editprofile.php?status=invalidphonenumber&name=".$name."&gender=".$gender."&year=".$year);
					exit();
			}

			//invalid name gender
			else if(!$vname && !$vgender && $vYear == true && $vpNumber){
				header("Location:./editprofile.php?status=invalidnamegender&year=".$year."&phoneNumber=".$pNumber);
				exit();
			}
			//invalid name Year
			else if(!$vname && $vgender && $vYear == false && $vpNumber){
				header("Location:./editprofile.php?status=invalidnameyear&gender=".$gender."&phoneNumber=".$pNumber);
				exit();
			}
			//invalid name phone
			else if(!$vname && $vgender && $vYear == true && !$vpNumber){
				header("Location:./editprofile.php?status=invalidnamephone&name=".$name."&year=".$year);
				exit();
			}
			//invalid year Gender
			else if($vname && !$vgender && $vYear == false && $vpNumber){
				header("Location:./editprofile.php?status=invalidyeargender&name=".$name."&phoneNumber=".$phoneNumber);
				exit();
			}
			//invalid year phone
			else if($vname && $vgender && $vYear == false && !$vpNumber){
					header("Location:./editprofile.php?status=invalidyearphone&name=".$name."&gender=".$gender);
					exit();
			}
			//invalid gender phone
			else if($vname && !$vgender && $vYear == true && !$vpNumber){
					header("Location:./editprofile.php?status=invalidgenderphone&name=".$name."&year=".$year);
					exit();
			}
			//only name valid
			else if($vname && !$vgender && $vYear == false && !$vpNumber){
					header("Location:./editprofile.php?status=onlyname&name=".$name);
					exit();
			}
			//only gender valid
			else if(!$vname && $vgender && $vYear == false && !$vpNumber){
					header("Location:./editprofile.php?status=onlygender&gender=".$gender);
					exit();
			}
			//only birth Year
			else if(!$vname && !$vgender && $vYear == true && !$vpNumber){
					header("Location:./editprofile.php?status=onlyyear&year=".$year);
					exit();
			}
			//only phone number valid
			else if(!$vname && !$vgender && $vYear == false && $vpNumber){
					header("Location:./editprofile.php?status=onlyphone&phoneNumber=".$pNumber);
					exit();
			}




		}
	}

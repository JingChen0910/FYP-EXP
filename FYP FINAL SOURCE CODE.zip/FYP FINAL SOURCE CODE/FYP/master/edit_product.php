<?php
session_start();
if(!isset($_SESSION['mid']) || !isset($_SESSION['mname']) || !isset($_SESSION['memail'])){
   echo '
   <script>
   alert("Please sign in your account!");
   window.location.href="./login.php";
   </script>
   ';
}else{
	include("dataconnection.php");
}

if(isset($_GET["id"])){
$id = $_GET["id"];
$_SESSION['TangShengXian'] = $_GET["id"];
$result = mysqli_query($connect, "SELECT * FROM product
                                  JOIN stock ON product.product_id = stock.product_id
                                  WHERE product.product_id = '$id'");
$row = mysqli_fetch_assoc($result);
$category_id=$row["category_id"];
$publisher_id=$row["publisher_id"];
$author_id=$row["author_id"];
$currentStockLevel = $row['stock_level'];
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<!-- <meta name="description" content="">
    <meta name="author" content="Dashboard">
    <meta name="keyword" content="Dashboard, Bootstrap, Admin, Template, Theme, Responsive, Fluid, Retina"> -->

	<title>Knowledge Sdn Bhd</title>

	<!-- Bootstrap core CSS -->
	<link href="./assets/css/bootstrap.css" rel="stylesheet">
	<!--external css-->
	<link href="./assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
	<!-- <link rel="stylesheet" type="text/css" href="assets/css/zabuto_calendar.css"> -->
	<!-- <link rel="stylesheet" type="text/css" href="assets/js/gritter/css/jquery.gritter.css" /> boleh-->
	<link rel="stylesheet" type="text/css" href="./assets/lineicons/style.css">

	<!-- Custom styles for this template -->
	<link href="./assets/css/style.css" rel="stylesheet">
	<link href="./assets/css/style-responsive.css" rel="stylesheet">

	<script src="./assets/js/chart-master/Chart.js"></script>
	<script src="https://kit.fontawesome.com/2a7abdb60f.js" crossorigin="anonymous"></script>

	<!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
	<!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>

<body>

	<section id="container">
		<!-- **********************************************************************************************************************************************************
      TOP BAR CONTENT & NOTIFICATIONS
      *********************************************************************************************************************************************************** -->
		<!--header start-->
		<header class="header black-bg">
			<div class="sidebar-toggle-box">
				<div class="fa fa-bars tooltips" data-placement="right" data-original-title="Toggle Navigation"></div>
			</div>
			<!--logo start-->
		<a href="index.php" class="logo"><b>Knowledge</b></a>
			<!--logo end-->
			<div class="top-menu">
				<ul class="nav pull-right top-menu">
					<li><a class="logout" href="./logoutaction.php">Logout</a></li>
				</ul>
			</div>
		</header>
		<!--header end-->

		<!-- **********************************************************************************************************************************************************
      MAIN SIDEBAR MENU
      *********************************************************************************************************************************************************** -->
		<!--sidebar start-->
		<aside>
			<div id="sidebar" class="nav-collapse ">
				<!-- sidebar menu start-->
				<ul class="sidebar-menu" id="nav-accordion">

				<?php
 				$get_profile_stmt = "SELECT * FROM master WHERE master_id ='".$_SESSION['mid']."';";
				$get_profile_result = mysqli_query($connect, $get_profile_stmt);
				if($get_profile_row = mysqli_fetch_assoc($get_profile_result)){
					$name = $get_profile_row['master_name'];
					$picture = $get_profile_row['master_profile_picture'];
				}else{
					echo "<script>alert('Database error!');
						window.location.href='./login.php';
					</script>";
				}
				?>
							<p class="centered"><a href="./user_profile.php"><img src="./master_propic/<?php echo $picture?>" class="img-circle" width="60"></a></p>
					<h5 class="centered"><?php echo $name ?></h5>

					<li class="mt">
						<a href="./index.php">
							<i class="fa fa-dashboard"></i>
							<span>Dashboard</span>
						</a>
					</li>

					<li class="sub-menu">
					<a href="./smasterlist.php">
						<i class="fa-solid fa-user-secret"></i>
							<span>Master</span>
						</a>
					</li>

					<li class="sub-menu">
						<a href="./sstafflist.php">
							<i class="fa-solid fa-helmet-safety"></i>
							<span>Staff</span>
						</a>
					</li>

					<li class="sub-menu">
				<a href="./scustomerlist.php">
							<i class="fa-solid fa-address-book"></i>
							<span>Customer</span>
						</a>
					</li>

					<li class="sub-menu">
						<a class="active" href="#">
							<i class="fa fa-book"></i>
							<span>Product</span>
						</a>
					</li>

					<li class="sub-menu">
						<a href="./order.php">
							<i class="fa-solid fa-cart-arrow-down"></i>
							<span>Order</span>
						</a>
					</li>

					<li class="sub-menu">
						<a href="./payment.php">
							<i class="fa fa-sack-dollar"></i>
							<span>Payment</span>
						</a>
					</li>

					<li class="sub-menu">
						<a href="./customer_review.php">
							<i class="fa-solid fa-comments"></i>
							<span>Customer Review</span>
						</a>
					</li>

					<li class="sub-menu">
						<a href="./faq.php">
                            <i class="fas fa-question-circle"></i>
							<span>FAQ</span>
						</a>
					</li>

				</ul>
				<!-- sidebar menu end-->
			</div>
		</aside>
		<!--sidebar end-->

		<!-- **********************************************************************************************************************************************************
      MAIN CONTENT
      *********************************************************************************************************************************************************** -->
		<!--main content start-->
		<section id="main-content">
			<section class="wrapper">

				<!-- BASIC FORM ELELEMNTS -->
				<div class="row mt">
					<div class="col-lg-12">
						<div class="form-panel">
							<h3 class="mb"><i class="fa fa-angle-right"></i> Edit Product</h3>



              <?php
              $get_Lastest_Product_Image = "SELECT * FROM product WHERE product_id='".$_SESSION['TangShengXian']."';";
              $get_Lastest_Product_Image_Result = mysqli_query($connect,$get_Lastest_Product_Image);
              if($get_Lastest_Product_Image_Result_Row = mysqli_fetch_assoc($get_Lastest_Product_Image_Result)){
                  $product_image = $get_Lastest_Product_Image_Result_Row['product_image'];
              }else{
                echo "<script>alert('Database error!');
                  window.location.href='./edit_product.php';
                </script>";
              }
              ?>
                    <div class="form-group">
                        <label for="product-img" class="col-sm-2 col-sm-2 control-label">Product Image: </label>
                        <div class="col-sm-10">
                          <form class="form-group" action="edit_product.php" method="post" enctype="multipart/form-data">



                    <img src="../staff/product_image/<?php echo $product_image;?>" alt="Product Image" width="90" height="110">
                    <br>
                    <br>
                    <input type="file" name="product-img" value="" class="btn btn-round btn-primary">
                    <br>
                    <button type="submit" name="update-img" class="btn btn-round btn-primary">Update Product Image</button>

                    </form>
                      </div>
                    </div>






							<form name="edit" method="post" enctype="multipart/form-data" action="edit_product.php" class="form-horizontal style-form">
                <br>
								<div class="form-group">
									<label class="col-sm-2 col-sm-2 control-label" for="p_id">Product ID: </label>
									<div class="col-sm-10">
										<input type="text" id="p_id" name="product_id" size="50" required value="<?php echo !empty($row['product_id']) ? $row['product_id'] : ''; ?>" class="form-control" readonly>
									</div>
								</div>

								<div class="form-group">
									<label for="p_name" class="col-sm-2 col-sm-2 control-label">Product Name: </label>
									<div class="col-sm-10">
										<input type="text" id="p_name" name="product_name" size="50" required value="<?php echo !empty($row['product_name']) ? $row['product_name'] : ''; ?>" class="form-control">
									</div>
								</div>

								<div class="form-group">
									<label for="p_description" class="col-sm-2 col-sm-2 control-label">Product Description: </label>
									<div class="col-sm-10">
										<textarea id="p_description" class="form-control" cols="60" rows="3" name="product_description" required><?php echo !empty($row['product_description']) ? $row['product_description'] : ''; ?></textarea>
									</div>
								</div>

								<div class="form-group">
									<label for="category_id" class="col-sm-2 col-sm-2 control-label">Category:</label>
									<div class="col-sm-10">
										<select name="category_id" class="btn btn-theme dropdown-toggle" id="category_id">
											<?php
											$query = mysqli_query($connect, "SELECT * FROM category");
											while($cat_id = mysqli_fetch_assoc($query))
											{
												$c_name=$cat_id['category_name'];
												$c_id=$cat_id['category_id'];
												if ($c_id == $category_id) {
													echo '<option value="'.$c_id. '" selected>'.$c_name.'</option>';
												} else {
													echo '<option value="'.$c_id. '">'.$c_name.'</option>';
												}
											}
											?>
										</select>
									</div>
								</div>


								<div class="form-group">
									<label for="author_id" class="col-sm-2 col-sm-2 control-label">Author Name:</label>
									<div class="col-sm-10">
										<select name="author_id" class="btn btn-theme dropdown-toggle" id="author_id">
											<?php
											$query = mysqli_query($connect, "SELECT * FROM author");
											while($au_id = mysqli_fetch_assoc($query))
											{
												$a_name=$au_id['author_name'];
												$a_id=$au_id['author_id'];
												if ($a_id == $author_id) {
													echo '<option value="'.$a_id.'" selected>'.$a_name.'</option>';
												} else {
													echo '<option value="'.$a_id.'">'.$a_name.'</option>';
												}
											}
											?>
										</select>
									</div>
								</div>


								<div class="form-group">
									<label for="publisher_id" class="col-sm-2 col-sm-2 control-label">Publisher Name:</label>
									<div class="col-sm-10">
										<select name="publisher_id" class="btn btn-theme dropdown-toggle" id="publisher_id">
											<?php
											$query = mysqli_query($connect, "SELECT * FROM publisher");
											while($pbs_id = mysqli_fetch_assoc($query))
											{
												$p_name=$pbs_id['publisher_name'];
												$p_id=$pbs_id['publisher_id'];
												if ($p_id == $publisher_id) {
													echo '<option value="'.$p_id. '" selected>'.$p_name.'</option>';
												}else {
													echo '<option value="'.$p_id. '">'.$p_name.'</option>';
                                                }

											}
											?>
										</select>
									</div>
								</div>

								<div class="form-group">
									<label for="pbs_date" class="col-sm-2 col-sm-2 control-label">Publisher Date:</label>
									<div class="col-sm-10">
										<input type="date" id="pbs_date" class="form-control" name="publisher_date" size="15" required value="<?php echo !empty($row['publisher_date']) ? $row['publisher_date'] : ''; ?>">
									</div>
								</div>

								<script>
								// Get today's date
								var today = new Date().toISOString().split('T')[0];
								// Set the max attribute of the date input to today's date
								document.getElementById("pbs_date").setAttribute("max", today);
								</script>

								<div class="form-group">
									<label for="p_price" class="col-sm-2 col-sm-2 control-label">Product Price(RM): </label>
									<div class="col-sm-10">
										<input type="number" id="p_price" step="0.01" min="1" name="product_price" size="15" required value="<?php echo !empty($row['product_price']) ? $row['product_price'] : ''; ?>" class="form-control">
									</div>
								</div>

								<div class="form-group">
									<label for="dis_price" class="col-sm-2 col-sm-2 control-label">Discount(%): </label>
									<div class="col-sm-10">
										<!-- Input field for discount with PHP code to pre-fill the value -->
										<input type="number" id="dis_price" step="0.01" min="0" max="70" name="discount" size="15" required value="<?php echo !empty($row['discount']) ? $row['discount'] : ''; ?>" class="form-control" onchange="updateDiscountedPrice()">
									</div>
								</div>

								<div class="form-group">
									<label for="discounted_price" class="col-sm-2 col-sm-2 control-label">Discounted Price(RM): </label>
									<div class="col-sm-10">
										<input type="number" id="discounted_price" name="discounted_price" size="15" required value="<?php echo !empty($row['discount_price']) ? $row['discount_price'] : ''; ?>" class="form-control" readonly>
    								</div>
								</div>

								<script>
								function updateDiscountedPrice() {
									var originalPrice = parseFloat(document.getElementById('p_price').value);
									var discountPercentage = parseFloat(document.getElementById('dis_price').value);
									var discountedPrice = originalPrice - (originalPrice * (discountPercentage / 100));
									document.getElementById('discounted_price').value = discountedPrice.toFixed(2);
									}
								</script>


							<div class="form-group">
    							<label for="s_level" class="col-sm-2 col-sm-2 control-label">Stock Level:</label>
    							<div class="col-sm-10">
        						<input type="number" id="s_level" step="1" min="<?php echo $currentStockLevel; ?>" max="500" name="stock_level" required value="<?php echo !empty($row['stock_level']) ? $row['stock_level'] : ''; ?>" class="form-control">
							    </div>
							</div>


                                <div class="form-group">
									<label for="availability" class="col-sm-2 col-sm-2 control-label">Available:</label>
									<div class="col-sm-10">
										<select name="availability" class="btn btn-theme dropdown-toggle" id="availability">
										<option value="0" <?php echo !empty($row['availability']) && $row['availability'] == 0 ? 'selected' : ''; ?>>0</option>
										<option value="1" <?php echo !empty($row['availability']) && $row['availability'] == 1 ? 'selected' : ''; ?>>1</option>
									    </select>
								    </div>
							    </div>



								<div class="form-group">
									<div class="col-sm-10">
										<input type="submit" name="update" value="Update" class="btn btn-rounded btn-success">
									</div>
								</div>
							</form>


							<div>
								<a href="manage_product.php" class="btn btn-rounded btn-primary"> Back to Product List</a>
							</div>
						</div>
					</div><!-- col-lg-12-->
				</div><!-- /row -->




			</section>
			<!--/wrapper -->
		</section><!-- /MAIN CONTENT -->





		<!--main content end-->
		<!--footer start-->
		<footer class="site-footer">
			<div class="text-center">
			2023 - Knowledge
				<!-- <a href="index.html#" class="go-top">
                  <i class="fa fa-angle-up"></i>
              </a> -->
			</div>
		</footer>
		<!--footer end-->
	</section>

	<!-- js placed at the end of the document so the pages load faster -->
	<script src="./assets/js/jquery.js"></script>
	<script src="./assets/js/jquery-1.8.3.min.js"></script>
	<script src="./assets/js/bootstrap.min.js"></script>
	<script class="include" type="text/javascript" src="assets/js/jquery.dcjqaccordion.2.7.js"></script>
	<script src="./assets/js/jquery.scrollTo.min.js"></script>
	<script src="./assets/js/jquery.nicescroll.js" type="text/javascript"></script>
	<script src="./assets/js/jquery.sparkline.js"></script>


	<!--common script for all pages-->
	<script src="./assets/js/common-scripts.js"></script>

	<!-- <script type="text/javascript" src="assets/js/gritter/js/jquery.gritter.js"></script>
    <script type="text/javascript" src="assets/js/gritter-conf.js"></script>  boleh-->

	<!--script for this page-->
	<!-- <script src="assets/js/sparkline-chart.js"></script>
	<script src="assets/js/zabuto_calendar.js"></script>	 -->

	<!-- <script type="text/javascript">
        $(document).ready(function () {
        var unique_id = $.gritter.add({
            // (string | mandatory) the heading of the notification
            title: 'Welcome to Dashgum!',
            // (string | mandatory) the text inside the notification
            text: 'Hover me to enable the Close Button. You can hide the left sidebar clicking on the button next to the logo. Free version for <a href="http://blacktie.co" target="_blank" style="color:#ffd777">BlackTie.co</a>.',
            // (string | optional) the image to display on the left
            image: 'assets/img/ui-sam.jpg',
            // (bool | optional) if you want it to fade out on its own or just sit there
            sticky: true,
            // (int | optional) the time you want it to be alive for before fading out
            time: '',
            // (string | optional) the class name you want to apply to that specific message
            class_name: 'my-sticky-class'
        });

        return false;
        });
	</script> boleh -->

	<script type="application/javascript">
		$(document).ready(function() {
					$("#date-popover").popover({
						html: true,
						trigger: "manual"
					});
					$("#date-popover").hide();
					$("#date-popover").click(function(e) {
						$(this).hide();
					});

					//   boleh  $("#my-calendar").zabuto_calendar({
					//         action: function () {
					//             return myDateFunction(this.id, false);
					//         },
					//         action_nav: function () {
					//             return myNavFunction(this.id);
					//         },
					//         ajax: {
					//             url: "show_data.php?action=1",
					//             modal: true
					//         },
					//         legend: [
					//             {type: "text", label: "Special event", badge: "00"},
					//             {type: "block", label: "Regular event", }
					//         ]
					//     });
					// });


					// function myNavFunction(id) {
					//     $("#date-popover").hide();
					//     var nav = $("#" + id).data("navigation");
					//     var to = $("#" + id).data("to");
					//     console.log('nav ' + nav + ' to: ' + to.month + '/' + to.year);
					// }

	</script>


</body>

</html>
<?php
if(isset($_POST['update']))
{
    $p_id = $_POST["product_id"];
    $p_name = $_POST["product_name"];
    $p_price = $_POST["product_price"];
	$p_discount = $_POST["discount"];
    $p_description = $_POST["product_description"];
    $pbs_date = $_POST["publisher_date"];
    $cat_id = $_POST["category_id"];
    $pbs_id = $_POST["publisher_id"];
    $au_id = $_POST["author_id"];
    $a_code = $_POST["availability"];
	$stock_level = $_POST['stock_level'];
	$p_disprice = $p_price - ($p_price * ($p_discount / 100));

    // Calculate the new stock level
    $new_stock_level = $stock_level;
    mysqli_query($connect, "UPDATE stock SET stock_level = '$stock_level' WHERE product_id = '$p_id'");

	$existingProductQuery = mysqli_query($connect, "SELECT * FROM product WHERE product_name = '$p_name' AND author_id = '$au_id' AND NOT product_id = '$p_id'");
	if (mysqli_num_rows($existingProductQuery) > 0) {
		echo "<script>alert('Product name already exists for the selected author. Please choose a different product name or author.');
		document.location.href='manage_product.php';</script>";

	}
	else{
		// Update the product details
		mysqli_query($connect, "UPDATE product SET product_name ='$p_name', product_price ='$p_price', discount='$p_discount', discount_price='$p_disprice', product_description ='$p_description', publisher_date ='$pbs_date', category_id ='$cat_id', publisher_id ='$pbs_id', author_id ='$au_id', availability ='$a_code' WHERE product_id = '$p_id'");
		echo "<script>alert('$p_name saved');</script>";
		// Redirect to the "manage_product.php" page with a random query parameter to prevent caching
		echo '<script>window.location.href = "manage_product.php?'.mt_rand().'";</script>';
	}
}


if(isset($_POST['update-img'])){
  $id = $_SESSION['TangShengXian'];
	$picture = $_FILES['product-img'];


	if(!empty($_FILES['product-img'])){
$pictureName = $_FILES['product-img']['name'];
	$pictureTmpName = $_FILES['product-img']['tmp_name'];
	$pictureSize = $_FILES['product-img']['size'];
	$pictureError = $_FILES['product-img']['error'];
	$pictureType = $_FILES['product-img']['type'];

	$pictureExtension = explode('.',$pictureName);
	$pictureActualExtension = strtolower(end($pictureExtension));

	$pictureAllowedExtension = array('jpg','jpeg','png');
	if(in_array($pictureActualExtension,$pictureAllowedExtension)){
		if($pictureError === 0){
			if($pictureSize <= 1000000){
				$sql1 = "SELECT product_image FROM product WHERE product_id='".$id."';";
				$result = mysqli_query($connect,$sql1);
				if($row1 = mysqli_fetch_assoc($result)){
					$databaseProfilePicture= $row1['product_image'];

						$documentCustomerPicture = "../staff/product_image/".$databaseProfilePicture;
						if(!unlink($documentCustomerPicture)){
              echo '
              <script>
              alert("Fail to delete the old file!");
              window.location.href="./edit_product.php?id='.$id.'";
              </script>
              ';
						}else{
							$newPictureName = "product".$id.".".$pictureActualExtension;
							$pictureLocation = "../staff/product_image/".$newPictureName;
							if(move_uploaded_file($pictureTmpName, $pictureLocation)){
							$sql =  "UPDATE product SET product_image= '".$newPictureName."' WHERE product_id='".$id."';";
							if(mysqli_query($connect,$sql)){
                echo '
                <script>
                alert("Update the product image successfully!");
                window.location.href="./edit_product.php?id='.$id.'";
                </script>
                ';
							}else{
                echo '
                <script>
                alert("Update the product image successfully, but fail to update the database!");
                window.location.href="./edit_product.php?id='.$id.'";
                </script>
                ';
							}
							}else{

                echo '
                <script>
                alert("Image file upload fails!");
                window.location.href="./edit_product.php?id='.$id.'";
                </script>
                ';
							}
						}

				}else{
          echo '
          <script>
          alert("Fail to check the database!");
          window.location.href="./edit_product.php?id='.$id.'";
          </script>
          ';
				}

			}else{
        echo '
        <script>
        alert("Image file size is oversize (1000000B/1000KB/1MB)!");
        window.location.href="./edit_product.php?id='.$id.'";
        </script>
        ';
			}
		}else{
      echo '
      <script>
      alert("Error uploading the product image!");
      window.location.href="./edit_product.php?id='.$id.'";
      </script>
      ';
		}
	}else{
    echo '
    <script>
    alert("Invalid extension!");
    window.location.href="./edit_product.php?id='.$id.'";
    </script>
    ';
	}
}else{
  echo '
  <script>
  alert("Please upload the product image!");
  window.location.href="./edit_product.php?id='.$id.'";
  </script>
  ';
}

}


?>

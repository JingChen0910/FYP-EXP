<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Sign Up</title>
	<link rel="stylesheet" href="formstyle.css">
	<script src="https://www.google.com/recaptcha/api.js" async defer></script>
</head>

<body>
	<form action="sregisteraction2.php" method="post" style="border:1px solid #ccc">
		<div class="container">
			<h1>Add new staff</h1>
			<p>Please fill in this form to add new staff account.</p>
			<!--testing-->
			<?php
    if(!isset($_GET['status'])){

    }else if(isset($_GET['status'])){
      $status = $_GET['status'];

      //all empty input
      if($status == "ALLemptyinput"){
        echo '<h1 style="color:red;">Please enter all inputs! &#128581;&#8205;&#9794;&#65039;</h1>';
      }

      //all invalid
      else if($status == "ALLinvalidinput"){
        echo '<h1 style="color:red;">Please enter all inputs in the correct format! &#128581;&#8205;&#9794;&#65039;</h1>';
      }

      //all valid
      else if($status == "registered"){
        echo '<h1 style="color:red;">Account registration successfully! &#128521;</h1>';
      }

      //invalid username email phone
      else if($status == "invalidusernameemailphone"){
        echo '<h1 style="color:red;">Invalid fullname, email, and phone number! &#128581;&#8205;&#9794;&#65039;</h1>';
      }

      //invalid username email password
      else if($status == "invalidusernameemailpassword"){
        echo '<h1 style="color:red;">Invalid fullname, email, and password! &#128581;&#8205;&#9794;&#65039;</h1>';
      }

      //invalid username phone password
      else if($status == "invalidusernamephonepassword"){
        echo '<h1 style="color:red;">Invalid fullname, phone number, and password! &#128581;&#8205;&#9794;&#65039;</h1>';
      }

      //invalid email phone password
      else if($status == "invalidemailphonepassword"){
        echo '<h1 style="color:red;">Invalid email, phone number, and password! &#128581;&#8205;&#9794;&#65039;</h1>';
      }

      //invalid username email
      else if($status == "invalidusernameemail"){
        echo '<h1 style="color:red;">Invalid fullname and email! &#128581;&#8205;&#9794;&#65039;</h1>';
      }

      //invalid username password
      else if($status == "invalidusernamepassword"){
        echo '<h1 style="color:red;">Invalid fullname and password! &#128581;&#8205;&#9794;&#65039;</h1>';
      }

      //invalid username phone
      else if($status == "invalidusernamephone"){
        echo '<h1 style="color:red;">Invalid fullname and phone number! &#128581;&#8205;&#9794;&#65039;</h1>';
      }

      //invalid phone password
      else if($status == "invalidphonepassword"){
        echo '<h1 style="color:red;">Invalid phone number and password! &#128581;&#8205;&#9794;&#65039;</h1>';
      }

      //invalid email phone
      else if($status == "invalidemailphone"){
        echo '<h1 style="color:red;">Invalid email and phone number! &#128581;&#8205;&#9794;&#65039;</h1>';
      }

      //invalid email password
      else if($status == "invalidemailpassword"){
        echo '<h1 style="color:red;">Invalid email and password! &#128581;&#8205;&#9794;&#65039;</h1>';
      }

      //invalid username
      else if($status == "invalidusername"){
        echo '<h1 style="color:red;">Invalid fullname! &#128581;&#8205;&#9794;&#65039;</h1>';
      }

      //invalid password
      else if($status == "invalidpassword"){
        echo '<h1 style="color:red;">Invalid password! &#128581;&#8205;&#9794;&#65039;</h1>';
      }

      //invalid phone
      else if($status == "invalidphone"){
        echo '<h1 style="color:red;">Invalid phone number! &#128581;&#8205;&#9794;&#65039;</h1>';
      }

      //invalid email
      else if($status == "invalidemail"){
        echo '<h1 style="color:red;">Invalid email! &#128581;&#8205;&#9794;&#65039;</h1>';
      }

	    //empty recaptcha
	    else if($status == "emptyrecaptcha"){
		  echo '<h1 style="color:red;">Do the recaptcha test, or you are a bot!? &#129302;</h1>';
	    }

	    //email taken
	    else if($status == "emailtaken"){
		  echo '<h1 style="color:red;">The email address has been taken! &#128581;&#8205;&#9794;&#65039;</h1>';
	    }

	    //sql error
	    else if($status == "sqlerror"){
		  echo '<h1 style="color:red;">Sorry, registration got trouble. &#128581;&#8205;&#9794;&#65039;</h1>';
	  }

		else if($status == "thepassword2isnotsamewithpassword"){
		echo '<h1 style="color:red;">The confirm password does not match the password! &#128581;&#8205;&#9794;&#65039;</h1>';
	}

    }
?>
			<!-- testing end -->
			<hr>

			<label for="username"><b>Fullname (The fullname must be at least 8 characters long but no more than 60 characters, begin with an alphabet, and may contain a space/number/-/_/.)</b></label>
			<?php
    if(isset($_GET['name'])){
      $name = $_GET['name'];
      echo '<input type="text" placeholder="Enter Fullname" name="name" id="username" value="'.$name.'" required>';
    }else {
      echo '<input type="text" placeholder="Enter Fullname" name="name" id="username" required>';
    }
     ?>


			<label for="email"><b>Email</b></label>
			<?php
    if(isset($_GET['email'])){
      $email = $_GET['email'];
      echo '<input type="email" placeholder="Enter Email" name="email" id="email" value="'.$email.'" required>';
    }else{
      echo '<input type="email" placeholder="Enter Email" name="email" id="email" required>';
    }
    ?>


			<label for="phoneNumber"><b>Phone Number (Phone number must be in Malaysian format, etc. 60xx-xxxxxxx)</b></label>
			<?php
    if(isset($_GET['phoneNumber'])){
      $phoneNumber = $_GET['phoneNumber'];
      echo '<input type="text" placeholder="Enter Phone Number" name="phoneNumber" id="phoneNumber" value="'.$phoneNumber.'" required>';
    }else{
      echo '<input type="text" placeholder="Enter Phone Number" name="phoneNumber" id="phoneNumber" required>';
    }
    ?>


			<label for="psw"><b>Password (Password must be at least 12 characters long, and it must include at least one uppercase, lowercase,special chracter, and numeric)</b></label>
			<input type="password" placeholder="Enter Password" name="password" id="psw" required>

			<label for="show">
				<input type="checkbox" onclick="showPassword()" name="show" id="show" style="margin-bottom:15px">Show password
			</label>
			<br>
			<label for="psw2"><b>Confirm Password</b></label>
			<input type="password" placeholder="Enter Confirm Password" name="password2" id="psw2" required>

			<label for="show2">
				<input type="checkbox" onclick="showPassword2()" name="show2" id="show2" style="margin-bottom:15px">Show password
			</label>
			<br>

      <div class="g-recaptcha" data-sitekey="6Lcfkl8mAAAAAM17lon3KPsh-IF2ub16hVBNis-c"></div>




			<div class="clearfix">
        <button type="submit" class="signupbtn" name="register">Add</button>
				<button type="button" class="cancelbtn" name="cancel" onclick="sstafflist()">Cancel</button>

			</div>
		</div>
	</form>
	<script type="text/javascript">
		function showPassword() {
			var show = document.getElementById("psw");
			if (show.type == "password") {
				show.type = "text";
			} else if(show.type == "text"){
				show.type = "password";
			}
		}
		function showPassword2() {
			var show = document.getElementById("psw2");
			if (show.type == "password") {
				show.type = "text";
			} else if(show.type == "text"){
				show.type = "password";
			}
		}
    function sstafflist(){
      window.location.href="./sstafflist.php";
    }
	</script>
</body>

</html>

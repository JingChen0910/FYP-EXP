<?php

session_start();
if(!isset($_SESSION['mid']) || !isset($_SESSION['mname']) || !isset($_SESSION['memail'])){
   echo '
   <script>
   alert("Please sign in your account!");
   window.location.href="./login.php";
   </script>
   ';
}else{
	include("dataconnection.php");

$id = $_GET["id"];
$result = mysqli_query($connect, "SELECT * FROM faq WHERE faq_id = '$id'");
$row = mysqli_fetch_assoc($result);
}


?>
<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<!-- <meta name="description" content="">
    <meta name="author" content="Dashboard">
    <meta name="keyword" content="Dashboard, Bootstrap, Admin, Template, Theme, Responsive, Fluid, Retina"> -->

	<title>Knowledge Sdn Bhd</title>

	<!-- Bootstrap core CSS -->
	<link href="./assets/css/bootstrap.css" rel="stylesheet">
	<!--external css-->
	<link href="./assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
	<!-- <link rel="stylesheet" type="text/css" href="assets/css/zabuto_calendar.css"> -->
	<!-- <link rel="stylesheet" type="text/css" href="assets/js/gritter/css/jquery.gritter.css" /> boleh-->
	<link rel="stylesheet" type="text/css" href="./assets/lineicons/style.css">

	<!-- Custom styles for this template -->
	<link href="./assets/css/style.css" rel="stylesheet">
	<link href="./assets/css/style-responsive.css" rel="stylesheet">

	<script src="./assets/js/chart-master/Chart.js"></script>
	<script src="https://kit.fontawesome.com/2a7abdb60f.js" crossorigin="anonymous"></script>

	<!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
	<!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>

<body>

	<section id="container">
		<!-- **********************************************************************************************************************************************************
      TOP BAR CONTENT & NOTIFICATIONS
      *********************************************************************************************************************************************************** -->
		<!--header start-->
		<header class="header black-bg">
			<div class="sidebar-toggle-box">
				<div class="fa fa-bars tooltips" data-placement="right" data-original-title="Toggle Navigation"></div>
			</div>
			<!--logo start-->
		<a href="index.php" class="logo"><b>Knowledge</b></a>
			<!--logo end-->
			<div class="top-menu">
				<ul class="nav pull-right top-menu">
	<li><a class="logout" href="./logoutaction.php">Logout</a></li>
				</ul>
			</div>
		</header>
		<!--header end-->

		<!-- **********************************************************************************************************************************************************
      MAIN SIDEBAR MENU
      *********************************************************************************************************************************************************** -->
		<!--sidebar start-->
		<aside>
			<div id="sidebar" class="nav-collapse ">
				<!-- sidebar menu start-->
				<ul class="sidebar-menu" id="nav-accordion">

				<?php
 				$get_profile_stmt = "SELECT * FROM master WHERE master_id ='".$_SESSION['mid']."';";
				$get_profile_result = mysqli_query($connect, $get_profile_stmt);
				if($get_profile_row = mysqli_fetch_assoc($get_profile_result)){
					$name = $get_profile_row['master_name'];
					$picture = $get_profile_row['master_profile_picture'];
				}else{
					echo "<script>alert('Database error!');
						window.location.href='./login.php';
					</script>";
				}
				?>
							<p class="centered"><a href="./user_profile.php"><img src="./master_propic/<?php echo $picture?>" class="img-circle" width="60"></a></p>
					<h5 class="centered"><?php echo $name ?></h5>

					<li class="mt">
						<a href="./index.php">
							<i class="fa fa-dashboard"></i>
							<span>Dashboard</span>
						</a>
					</li>

					<li class="sub-menu">
					<a href="./smasterlist.php">
						<i class="fa-solid fa-user-secret"></i>
							<span>Master</span>
						</a>
					</li>

					<li class="sub-menu">
						<a href="./sstafflist.php">
							<i class="fa-solid fa-helmet-safety"></i>
							<span>Staff</span>
						</a>
					</li>

					<li class="sub-menu">
					<a href="./scustomerlist.php">
							<i class="fa-solid fa-address-book"></i>
							<span>Customer</span>
						</a>
					</li>

					<li class="sub-menu">
						<a href="./manage_product.php">
							<i class="fa fa-book"></i>
							<span>Product</span>
						</a>
					</li>

					<li class="sub-menu">
						<a href="./order.php">
							<i class="fa-solid fa-cart-arrow-down"></i>
							<span>Order</span>
						</a>
					</li>

					<li class="sub-menu">
						<a href="./payment.php">
							<i class="fa fa-sack-dollar"></i>
							<span>Payment</span>
						</a>
					</li>

					<li class="sub-menu">
						<a href="./customer_review.php">
							<i class="fa-solid fa-comments"></i>
							<span>Customer Review</span>
						</a>
					</li>

					<li class="sub-menu">
						<a class="active" href="#">
                            <i class="fas fa-question-circle"></i>
							<span>FAQ</span>
						</a>
					</li>

				</ul>
				<!-- sidebar menu end-->
			</div>
		</aside>
		<!--sidebar end-->

		<!-- **********************************************************************************************************************************************************
      MAIN CONTENT
      *********************************************************************************************************************************************************** -->
		<!--main content start-->
        <section id="main-content">
			<section class="wrapper">

				<!-- BASIC FORM ELELEMNTS -->
				<div class="row mt">
					<div class="col-lg-12">
						<div class="form-panel">
							<h3 class="mb"><i class="fa fa-angle-right"></i> Edit FAQ</h3>


							<form name="edit" method="post" action="" class="form-horizontal style-form">

								<div class="form-group">
									<label class="col-sm-2 col-sm-2 control-label" for="f_id">FAQ ID: </label>
									<div class="col-sm-10">
										<input type="text" id="f_id" name="faq_id" size="50" required value="<?php echo !empty($row['faq_id']) ? $row['faq_id'] : ''; ?>" class="form-control" readonly>
									</div>
								</div>

								<div class="form-group">
									<label for="f_quest" class="col-sm-2 col-sm-2 control-label">Question: </label>
									<div class="col-sm-10">
                                    <textarea id="f_quest" class="form-control" cols="60" rows="3" name="faq_question"><?php echo $row['question'] ?? ''; ?></textarea>
									</div>
								</div>

								<div class="form-group">
									<label for="f_ans" class="col-sm-2 col-sm-2 control-label">Answer: </label>
									<div class="col-sm-10">
										<textarea id="f_ans" class="form-control" cols="60" rows="5" name="faq_answer"><?php echo $row['answer'] ?? ''; ?></textarea>
									</div>
								</div>


								<div class="form-group">
									<div class="col-sm-10">
										<input type="submit" name="update" value="Update" class="btn btn-rounded btn-success">
									</div>
								</div>
							</form>


							<div>
								<a href="faq.php" class="btn btn-rounded btn-primary">Back to FAQ List</a>
							</div>
						</div>
					</div><!-- col-lg-12-->
				</div><!-- /row -->




			</section>
			<!--/wrapper -->
		</section><!-- /MAIN CONTENT -->





		<!--main content end-->
		<!--footer start-->
		<footer class="site-footer">
			<div class="text-center">
			2023 - Knowledge
				<!-- <a href="index.html#" class="go-top">
                  <i class="fa fa-angle-up"></i>
              </a> -->
			</div>
		</footer>
		<!--footer end-->
	</section>

	<!-- js placed at the end of the document so the pages load faster -->
	<script src="./assets/js/jquery.js"></script>
	<script src="./assets/js/jquery-1.8.3.min.js"></script>
	<script src="./assets/js/bootstrap.min.js"></script>
	<script class="include" type="text/javascript" src="assets/js/jquery.dcjqaccordion.2.7.js"></script>
	<script src="./assets/js/jquery.scrollTo.min.js"></script>
	<script src="./assets/js/jquery.nicescroll.js" type="text/javascript"></script>
	<script src="./assets/js/jquery.sparkline.js"></script>


	<!--common script for all pages-->
	<script src="./assets/js/common-scripts.js"></script>

	<!-- <script type="text/javascript" src="assets/js/gritter/js/jquery.gritter.js"></script>
    <script type="text/javascript" src="assets/js/gritter-conf.js"></script>  boleh-->

	<!--script for this page-->
	<!-- <script src="assets/js/sparkline-chart.js"></script>
	<script src="assets/js/zabuto_calendar.js"></script>	 -->

	<!-- <script type="text/javascript">
        $(document).ready(function () {
        var unique_id = $.gritter.add({
            // (string | mandatory) the heading of the notification
            title: 'Welcome to Dashgum!',
            // (string | mandatory) the text inside the notification
            text: 'Hover me to enable the Close Button. You can hide the left sidebar clicking on the button next to the logo. Free version for <a href="http://blacktie.co" target="_blank" style="color:#ffd777">BlackTie.co</a>.',
            // (string | optional) the image to display on the left
            image: 'assets/img/ui-sam.jpg',
            // (bool | optional) if you want it to fade out on its own or just sit there
            sticky: true,
            // (int | optional) the time you want it to be alive for before fading out
            time: '',
            // (string | optional) the class name you want to apply to that specific message
            class_name: 'my-sticky-class'
        });

        return false;
        });
	</script> boleh -->

	<script type="application/javascript">
		$(document).ready(function() {
					$("#date-popover").popover({
						html: true,
						trigger: "manual"
					});
					$("#date-popover").hide();
					$("#date-popover").click(function(e) {
						$(this).hide();
					});

					//   boleh  $("#my-calendar").zabuto_calendar({
					//         action: function () {
					//             return myDateFunction(this.id, false);
					//         },
					//         action_nav: function () {
					//             return myNavFunction(this.id);
					//         },
					//         ajax: {
					//             url: "show_data.php?action=1",
					//             modal: true
					//         },
					//         legend: [
					//             {type: "text", label: "Special event", badge: "00"},
					//             {type: "block", label: "Regular event", }
					//         ]
					//     });
					// });


					// function myNavFunction(id) {
					//     $("#date-popover").hide();
					//     var nav = $("#" + id).data("navigation");
					//     var to = $("#" + id).data("to");
					//     console.log('nav ' + nav + ' to: ' + to.month + '/' + to.year);
					// }

	</script>


</body>

</html>
<?php
if(isset($_POST['update'])){
    $f_id = $_POST["faq_id"];
    $f_quest = $_POST["faq_question"];
    $f_ans = $_POST["faq_answer"];


    mysqli_query($connect, "UPDATE faq SET question ='$f_quest', answer ='$f_ans' WHERE faq_id = '$f_id'");
    echo "<script>alert('$f_id saved');</script>";
    echo '<script>window.location.href ="faq.php";</script>';
    exit();
}
?>

<?php
session_start();
if(!isset($_SESSION['mid']) || !isset($_SESSION['mname']) || !isset($_SESSION['memail'])){
   echo '
   <script>
   alert("Please sign in your account!");
   window.location.href="./login.php";
   </script>
   ';
}else{
   // Include the database connection file
   include("dataconnection.php");
   $query = "SELECT * FROM orders ORDER BY order_id ASC";
   $result= mysqli_query($connect, $query);
}


?>
<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<!-- <meta name="description" content="">
    <meta name="author" content="Dashboard">
    <meta name="keyword" content="Dashboard, Bootstrap, Admin, Template, Theme, Responsive, Fluid, Retina"> -->

	<title>Knowledge Sdn Bhd</title>

	<!-- Bootstrap core CSS -->
	<link href="./assets/css/bootstrap.css" rel="stylesheet">
	<!--external css-->
	<link href="./assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
	<!-- <link rel="stylesheet" type="text/css" href="assets/css/zabuto_calendar.css"> -->
	<!-- <link rel="stylesheet" type="text/css" href="assets/js/gritter/css/jquery.gritter.css" /> boleh-->
	<link rel="stylesheet" type="text/css" href="./assets/lineicons/style.css">

	<!-- Custom styles for this template -->
	<link href="./assets/css/style.css" rel="stylesheet">
	<link href="./assets/css/style-responsive.css" rel="stylesheet">

	<script src="./assets/js/chart-master/Chart.js"></script>
	<script src="https://kit.fontawesome.com/2a7abdb60f.js" crossorigin="anonymous"></script>

	<!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
	<!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>

<body>

	<section id="container">
		<!-- **********************************************************************************************************************************************************
      TOP BAR CONTENT & NOTIFICATIONS
      *********************************************************************************************************************************************************** -->
		<!--header start-->
		<header class="header black-bg">
			<div class="sidebar-toggle-box">
				<div class="fa fa-bars tooltips" data-placement="right" data-original-title="Toggle Navigation"></div>
			</div>
			<!--logo start-->
		<a href="index.php" class="logo"><b>Knowledge</b></a>
			<!--logo end-->
			<div class="top-menu">
				<ul class="nav pull-right top-menu">
			<li><a class="logout" href="./logoutaction.php">Logout</a></li>
				</ul>
			</div>
		</header>
		<!--header end-->

		<!-- **********************************************************************************************************************************************************
      MAIN SIDEBAR MENU
      *********************************************************************************************************************************************************** -->
		<!--sidebar start-->
		<aside>
			<div id="sidebar" class="nav-collapse ">
				<!-- sidebar menu start-->
				<ul class="sidebar-menu" id="nav-accordion">

				<?php
 				$get_profile_stmt = "SELECT * FROM master WHERE master_id ='".$_SESSION['mid']."';";
				$get_profile_result = mysqli_query($connect, $get_profile_stmt);
				if($get_profile_row = mysqli_fetch_assoc($get_profile_result)){
					$name = $get_profile_row['master_name'];
					$picture = $get_profile_row['master_profile_picture'];
				}else{
					echo "<script>alert('Database error!');
						window.location.href='./login.php';
					</script>";
				}
        //master_picture
				?>
							<p class="centered"><a href="./user_profile.php"><img src="./master_propic/<?php echo $picture?>" class="img-circle" width="60"></a></p>
					<h5 class="centered"><?php echo $name ?></h5>

					<li class="mt">
						<a href="./index.php">
							<i class="fa fa-dashboard"></i>
							<span>Dashboard</span>
						</a>
					</li>

					<li class="sub-menu">
					<a href="./smasterlist.php">
						<i class="fa-solid fa-user-secret"></i>
							<span>Master</span>
						</a>
					</li>

					<li class="sub-menu">
						<a href="./sstafflist.php">
							<i class="fa-solid fa-helmet-safety"></i>
							<span>Staff</span>
						</a>
					</li>

					<li class="sub-menu">
					<a href="./scustomerlist.php">
							<i class="fa-solid fa-address-book"></i>
							<span>Customer</span>
						</a>
					</li>

					<li class="sub-menu">
						<a href="./manage_product.php">
							<i class="fa fa-book"></i>
							<span>Product</span>
						</a>
					</li>

					<li class="sub-menu">
						<a class="active" href="#">
							<i class="fa-solid fa-cart-arrow-down"></i>
							<span>Order</span>
						</a>
					</li>

					<li class="sub-menu">
						<a href="./payment.php">
							<i class="fa fa-sack-dollar"></i>
							<span>Payment</span>
						</a>
					</li>

					<li class="sub-menu">
						<a href="./customer_review.php">
							<i class="fa-solid fa-comments"></i>
							<span>Customer Review</span>
						</a>
					</li>

					<li class="sub-menu">
						<a href="./faq.php">
                            <i class="fas fa-question-circle"></i>
							<span>FAQ</span>
						</a>
					</li>

				</ul>
				<!-- sidebar menu end-->
			</div>
		</aside>
		<!--sidebar end-->

		<!-- **********************************************************************************************************************************************************
      MAIN CONTENT
      *********************************************************************************************************************************************************** -->
		<!--main content start-->
		<section id="main-content">
			<section class="wrapper">
				<!-- <h2><i class="fa fa-angle-right"></i> Product</h2> -->
				<div class="row">
					<div class="col-md-12">
						<div class="row mt">
							<div class="col-md-12">
								<div class="content-panel">
<!-- stop -->

<table class="table table-striped table-advance table-hover">
<h3><i class="fa fa-angle-right"></i> Order List</h3>
			<thead>
		<tr>
		    <td>Order_ID</td>
			<td>Customer_Name</td>
            <td>Date</td>
			<td>Es_arriveDate</td>
			<td>Total(RM)</td>
			<td>Status</td>
			<td>Details</td>
			<td>Action</td>
			<td>Cancel_Date</td>
	  	</tr>
		</thead>
		<tbody>
		<?php
		while ($row = mysqli_fetch_assoc($result)) {
			echo "<tr>";
			echo "<td class='hidden-phone'>".$row ['order_id']."</td>";
			$order_id=$row['order_id'];
			$cust_id =$row["customer_id"];
			$query =mysqli_query($connect,"SELECT * FROM customer WHERE customer_id= $cust_id");
			$customer = mysqli_fetch_assoc($query);
			$customer_name = $customer['customer_name'];
			echo "<td class='hidden-phone'>$customer_name</td>";
            echo "<td class='hidden-phone'>".$row ['order_date']."</td>";
			echo "<td class='hidden-phone'>".$row ['estimated_arriveDate']."</td>";
			echo "<td class='hidden-phone'>".$row ['overall_total']."</td>";
			echo "<td class='hidden-phone'>".$row ['order_status']."</td>";
			echo "<td class='hidden-phone'><a class='btn btn-round btn-info' href=\"order_details.php?id=".$row['order_id']."\">View</a></td>";
			//echo "<td class='hidden-phone'><a href=\"edit_orderstatus.php?id=".$row['order_id']."\">Edit</a></td>";
			echo "<td class='hidden-phone'><form action=\"edit_orderstatus.php?id=" . $row['order_id'] . "\" method=\"POST\">
				<div class=\"form-group\">
					<select name=\"status\"";

					if ($row['order_status'] == 'Processing') {
						echo ">
							<option value=\"Processing\"selected>Processing</option>
							<option value=\"Shipping\">Shipping</option>
							<option value=\"Cancelled\">Cancelled</option>";
					} elseif ($row['order_status'] == 'Shipping') {
						echo ">
							<option value=\"Shipping\" selected>Shipping</option>
							<option value=\"Delivered\">Delivered</option>";
					} elseif ($row['order_status'] == 'Delivered') {
						echo ">
							<option value=\"Cancelled\">Cancelled</option>
							<option value=\"Delivered\" selected>Delivered</option>";
					} elseif ($row['order_status'] == 'Cancelled') {
						echo " disabled>
							<option value=\"Processing\">Processing</option>
							<option value=\"Shipping\">Shipping</option>
							<option value=\"Delivered\">Delivered</option>
							<option value=\"Cancelled\" selected>Cancelled</option>";
					}

					echo "</select>";
					echo "<input type=\"submit\" value=\"Update\" class=\"btn btn-round btn-success\">
				</div>
				</form>
			</td>";

			
			if ($row['order_status'] == 'Cancelled' && empty($row['cancellation_date'])) {
			// Set the cancellation date
			date_default_timezone_set('Asia/Kuala_Lumpur');
			$cancellation_date = date('Y-m-d H:i:s');
			$query = "UPDATE orders SET cancellation_date = '$cancellation_date' WHERE order_id = $order_id";
			mysqli_query($connect, $query);
			echo "<script>alert('Order cancelled successfully!');</script>";

			}
			echo "<td class='hidden-phone'>".$row ['cancellation_date']."</td>";
			//echo "<td class='hidden-phone'><a class='btn btn-round btn-danger' href=\"cancel_order.php?id=".$row['order_id']."\">Cancel</a></td>";
			echo "</tr>";

		}
		?>
</tbody>
									</table>
    </div><!-- /content-panel -->
   <div>
   	<a href="./index.php" class="btn btn-primary">Back to Dashboard</a>
	</div>

							</div><!-- /col-md-12 -->
						</div><!-- /row -->
					</div><!-- /col-md-12 -->

			</section>
			<!--/wrapper -->
		</section><!-- /MAIN CONTENT -->










		<!--main content end-->
		<!--footer start-->
		<footer class="site-footer">
			<div class="text-center">
			2023 - Knowledge
				<!-- <a href="index.html#" class="go-top">
                  <i class="fa fa-angle-up"></i>
              </a> -->
			</div>
		</footer>
		<!--footer end-->
	</section>

	<!-- js placed at the end of the document so the pages load faster -->
	<script src="./assets/js/jquery.js"></script>
	<script src="./assets/js/jquery-1.8.3.min.js"></script>
	<script src="./assets/js/bootstrap.min.js"></script>
	<script class="include" type="text/javascript" src="assets/js/jquery.dcjqaccordion.2.7.js"></script>
	<script src="./assets/js/jquery.scrollTo.min.js"></script>
	<script src="./assets/js/jquery.nicescroll.js" type="text/javascript"></script>
	<script src="./assets/js/jquery.sparkline.js"></script>


	<!--common script for all pages-->
	<script src="./assets/js/common-scripts.js"></script>

	<!-- <script type="text/javascript" src="assets/js/gritter/js/jquery.gritter.js"></script>
    <script type="text/javascript" src="assets/js/gritter-conf.js"></script>  boleh-->

	<!--script for this page-->
	<!-- <script src="assets/js/sparkline-chart.js"></script>
	<script src="assets/js/zabuto_calendar.js"></script>	 -->

	<!-- <script type="text/javascript">
        $(document).ready(function () {
        var unique_id = $.gritter.add({
            // (string | mandatory) the heading of the notification
            title: 'Welcome to Dashgum!',
            // (string | mandatory) the text inside the notification
            text: 'Hover me to enable the Close Button. You can hide the left sidebar clicking on the button next to the logo. Free version for <a href="http://blacktie.co" target="_blank" style="color:#ffd777">BlackTie.co</a>.',
            // (string | optional) the image to display on the left
            image: 'assets/img/ui-sam.jpg',
            // (bool | optional) if you want it to fade out on its own or just sit there
            sticky: true,
            // (int | optional) the time you want it to be alive for before fading out
            time: '',
            // (string | optional) the class name you want to apply to that specific message
            class_name: 'my-sticky-class'
        });

        return false;
        });
	</script> boleh -->

	<script type="application/javascript">
		$(document).ready(function() {
					$("#date-popover").popover({
						html: true,
						trigger: "manual"
					});
					$("#date-popover").hide();
					$("#date-popover").click(function(e) {
						$(this).hide();
					});

					//   boleh  $("#my-calendar").zabuto_calendar({
					//         action: function () {
					//             return myDateFunction(this.id, false);
					//         },
					//         action_nav: function () {
					//             return myNavFunction(this.id);
					//         },
					//         ajax: {
					//             url: "show_data.php?action=1",
					//             modal: true
					//         },
					//         legend: [
					//             {type: "text", label: "Special event", badge: "00"},
					//             {type: "block", label: "Regular event", }
					//         ]
					//     });
					// });


					// function myNavFunction(id) {
					//     $("#date-popover").hide();
					//     var nav = $("#" + id).data("navigation");
					//     var to = $("#" + id).data("to");
					//     console.log('nav ' + nav + ' to: ' + to.month + '/' + to.year);
					// }

	</script>


</body>

</html>

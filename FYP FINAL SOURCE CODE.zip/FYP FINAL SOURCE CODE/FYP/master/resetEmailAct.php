<?php
session_start();
if(!isset($_SESSION['mid']) || !isset($_SESSION['mname']) || !isset($_SESSION['memail'])){
 echo '
 <script>
 alert("Please sign in your account!");
 window.location.href="./login.php";
 </script>
 ';
}else{
 require_once 'dataconnection.php';

}

  use PHPMailer\PHPMailer\PHPMailer;
	use PHPMailer\PHPMailer\Exception;

	require 'PHPmailer/src/Exception.php';
	require 'PHPmailer/src/PHPMailer.php';
	require 'PHPmailer/src/SMTP.php';


if(isset($_POST['resetEmail'])){
  $newEmail = mysqli_real_escape_string($connect,$_POST['email']);
  $pass =  mysqli_real_escape_string($connect,$_POST['pass']);

  //all empty
  if(empty($newEmail) || empty($pass)){
    header("Location:./resetEmail.php?status=emptyinput");
    exit();
  }else{
    $vemail = filter_var($newEmail,FILTER_VALIDATE_EMAIL);
    $vemailRegex = preg_match('/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/',$newEmail);
    $vpass = preg_match('/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^\w\s]).{12,}$/',$pass);

    //all invalid
    if((!$vemail || !$vemailRegex) && !$vpass){
      header("Location:./resetEmail.php?status=allinvalid");
      exit();
    }

    //all valid
    else if($vemail && $vemailRegex && $vpass){// all valid start


      //statement select master password statement
      $sql = "SELECT * FROM master WHERE master_id = ? && master_email = ?";
      $stmt = mysqli_stmt_init($connect);
      if(!mysqli_stmt_prepare($stmt,$sql)){
        header("Location:./resetEmail.php?status=sqlerror");
        exit();
        //statement error
      }else{
        //statement correct
        mysqli_stmt_bind_param($stmt, "ss", $_SESSION['mid'], $_SESSION['memail']);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
        if($row = mysqli_fetch_assoc($result)){
          $checkPassword = password_verify($pass, $row['master_password']);
          if($checkPassword == false){
            header("Location:./resetEmail.php?status=wrongpassword");
            exit();
            //password false
          }else if($checkPassword == true){
            //password true start


            //check master email
            $sql1 = "SELECT * FROM master WHERE master_email = ?";
            $stmt1 = mysqli_stmt_init($connect);
            if(!mysqli_stmt_prepare($stmt1,$sql1)){
              header("Location:./resetEmail.php?status=sqlerror");
              exit();
              //statement error
            }else{
              // check master email statement not error
              //check master email prepare statement
              mysqli_stmt_bind_param($stmt1, "s", $newEmail);
              mysqli_stmt_execute($stmt1);
              mysqli_stmt_store_result($stmt1);
              $newEmailRow = mysqli_stmt_num_rows($stmt1);
              //check master email prepare statement end

            }// check master email not error
						mysqli_stmt_close($stmt1);
            // check master email statement end

            //check staff email statement start

    $sqlstaff123 = "SELECT * FROM staff WHERE staff_email =?";
    $stmtstaff123 = mysqli_stmt_init($connect);
    if(!mysqli_stmt_prepare($stmtstaff123,$sqlstaff123)){
      header("Location:./sregister.php?status=sqlerror");
      exit(); //database error
    }else{ //database success
      mysqli_stmt_bind_param($stmtstaff123, "s", $newEmail);
      mysqli_stmt_execute($stmtstaff123);
      mysqli_stmt_store_result($stmtstaff123);
      $emailRowStaff = mysqli_stmt_num_rows($stmtstaff123);
    }
    mysqli_stmt_close($stmtstaff123);

            //check staff email statement end
            if($newEmailRow >0 || $emailRowStaff >0){// email taken start
                  header("Location:./resetEmail.php?status=emailtaken");
                  exit();
                  //email taken end
                }else{ //email not taken
                  //start send OTP

                  //session new email
                  $_SESSION['mResettheNewEmailis'] = $newEmail;
                  //send OTP
                  $email="knowledgemain1991@gmail.com";
                  $appPass="bsbddqyahqsshvdf";
                  $OTP= mt_rand(100000,999999);
                  $hashedOTP = password_hash($OTP,PASSWORD_DEFAULT);
                  $_SESSION["mResetEmailOTP"]= $hashedOTP;
                  $_SESSION["mOTPvExpiredTime"] = time() + 300;
                  $subject="Reset Email -- Knowledge";
                  $body ='<div style="font-family: Helvetica,Arial,sans-serif;min-width:1000px;overflow:auto;line-height:2">
                  <div style="margin:50px auto;width:70%;padding:20px 0">
                    <div style="border-bottom:1px solid #eee">
                      <a href="" style="font-size:1.4em;color: #00466a;text-decoration:none;font-weight:600">Knowledge</a>
                    </div>
                    <p style="font-size:1.1em">Hi,</p>
                    <p>Thank you for choosing Knowledge. Use the following OTP to complete your Reset Email procedures. OTP is valid for 5 minutes</p>
                    <h2 style="background: #00466a;margin: 0 auto;width: max-content;padding: 0 10px;color: #fff;border-radius: 4px;">'.$OTP.'</h2>
                    <p style="font-size:0.9em;">Regards,<br />Knowledge Sdn Bhd</p>
                    <hr style="border:none;border-top:1px solid #eee" />
                    <div style="float:right;padding:8px 0;color:#aaa;font-size:0.8em;line-height:1;font-weight:300">
                      <p>Knowledge Sdn Bhd, Jalan Ayer Keroh Lama,</p>
                      <p>75450, Bukit Beruang,</p>
                      <p>Melaka, Malaysia</p>
                    </div>
                  </div>
                  </div>
                  ';


                          $mail = new PHPMailer(true);

                          $mail -> isSMTP();
                          $mail -> Host = 'smtp.gmail.com';
                          $mail -> SMTPAuth = true;
                          $mail -> Username = $email; //Your email
                          $mail -> Password = $appPass; //Your email app password
                          $mail -> SMTPSecure = 'ssl';
                          $mail -> Port = 465;

                          $mail -> setFrom($email); //Your email

                          $mail -> addAddress($newEmail); // customer email

                          $mail -> isHTML(true);

                          $mail -> Subject = $subject;
                          $mail -> Body = $body;

                          $mail -> send();

                          //OTP sent
                          echo
                          "
                          <script>
                          alert('Reset Email OTP sent!');
                          document.location.href='resetEmailOTPcheck.php';
                          </script>
                          ";



                }//email not taken end























          }//password true end


        }//get master password row

      }//statement correct
			mysqli_stmt_close($stmt);
			mysqli_close($connect);
}//all valid end

    //invalid new email
    else if((!$vemail || !$vemailRegex) && $vpass){
      header("Location:./resetEmail.php?status=invalidnewemail");
      exit();
    }

    //invalid password
    else if(($vemail && $vemailRegex) && !$vpass){
      header("Location:./resetEmail.php?status=invalidpassword&email=".$newEmail);
      exit();
    }

  }



/*      if($newEmailRow >0){// email taken start
        header("Location:./resetEmail.php?status=emailtaken");
        exit();
        //email taken end
      }else{ //email not taken
        //start send OTP

        //session new email
        $_SESSION['mResettheNewEmailis'] = $newEmail;
        //send OTP
        $email="knowledgemain1991@gmail.com";
        $appPass="bsbddqyahqsshvdf";
        $OTP= mt_rand(100000,999999);
        $hashedOTP = password_hash($OTP,PASSWORD_DEFAULT);
        $_SESSION["mResetEmailOTP"]= $hashedOTP;
        $_SESSION["mOTPvExpiredTime"] = time() + 300;
        $subject="Reset Email -- Knowledge";
        $body ='<div style="font-family: Helvetica,Arial,sans-serif;min-width:1000px;overflow:auto;line-height:2">
        <div style="margin:50px auto;width:70%;padding:20px 0">
          <div style="border-bottom:1px solid #eee">
            <a href="" style="font-size:1.4em;color: #00466a;text-decoration:none;font-weight:600">Knowledge</a>
          </div>
          <p style="font-size:1.1em">Hi,</p>
          <p>Thank you for choosing Knowledge. Use the following OTP to complete your Reset Email procedures. OTP is valid for 5 minutes</p>
          <h2 style="background: #00466a;margin: 0 auto;width: max-content;padding: 0 10px;color: #fff;border-radius: 4px;">'.$OTP.'</h2>
          <p style="font-size:0.9em;">Regards,<br />Knowledge Sdn Bhd</p>
          <hr style="border:none;border-top:1px solid #eee" />
          <div style="float:right;padding:8px 0;color:#aaa;font-size:0.8em;line-height:1;font-weight:300">
            <p>Knowledge Sdn Bhd, Jalan Ayer Keroh Lama,</p>
            <p>75450, Bukit Beruang,</p>
            <p>Melaka, Malaysia</p>
          </div>
        </div>
        </div>
        ';


                $mail = new PHPMailer(true);

                $mail -> isSMTP();
                $mail -> Host = 'smtp.gmail.com';
                $mail -> SMTPAuth = true;
                $mail -> Username = $email; //Your email
                $mail -> Password = $appPass; //Your email app password
                $mail -> SMTPSecure = 'ssl';
                $mail -> Port = 465;

                $mail -> setFrom($email); //Your email

                $mail -> addAddress($newEmail); // customer email

                $mail -> isHTML(true);

                $mail -> Subject = $subject;
                $mail -> Body = $body;

                $mail -> send();

                //OTP sent
                echo
                "
                <script>
                alert('Reset Email OTP sent!');
                document.location.href='resetEmailOTPcheck.php';
                </script>
                ";



      }//email not taken end*/










}


?>

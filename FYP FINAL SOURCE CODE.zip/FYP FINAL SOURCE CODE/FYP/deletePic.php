<?php
session_start();
require_once 'dataconnection.php';
if(!isset($_SESSION['id']) || !isset($_SESSION['name']) || !isset($_SESSION['email']) || !isset($_SESSION['vemail'])){
	echo "<script>window.location.href='clogin.php';</script>";
 }else if(isset($_SESSION['id']) &&  isset($_SESSION['name']) && isset($_SESSION['email']) && isset($_SESSION['vemail'])){
	   $vemail = $_SESSION['vemail'];
	   if($vemail == false){
		echo "<script>window.location.href='sentOTP.php';</script>";
		  exit();
	   }
	}

if(isset($_POST['delete'])){
    $id = $_POST['delete'];
    $sql1 = "SELECT customer_profile_picture FROM customer WHERE customer_id='".$id."';";
    $result = mysqli_query($connect,$sql1);
    if($row = mysqli_fetch_array($result)){
        $databaseProfilePicture = $row["customer_profile_picture"];
        if($databaseProfilePicture == "default.png"){
					echo
					"
					<script>
					alert('You cannot delete the default profile picture!');
					document.location.href='user_profile.php';
					</script>
					";
					exit();
        }else if($databaseProfilePicture != "default.png"){
            $documentCustomerPicture = "./images/cus_profile/".$databaseProfilePicture;
            if(!unlink($documentCustomerPicture)){
							echo
							"
							<script>
							alert('Fail to delete the current profile picture file!');
							document.location.href='user_profile.php';
							</script>
							";
							exit();
            }else{
                $sql2 = "UPDATE customer SET customer_profile_picture='default.png' WHERE customer_id = '".$id."';";
                if(mysqli_query($connect,$sql2)){
									echo
									"
									<script>
									alert('Profile picture successfully deleted!');
									document.location.href='user_profile.php';
									</script>
									";
									exit();
                }
            }
        }
    }else{
			echo
			"
			<script>
			alert('Sorry, SQL error!');
			document.location.href='user_profile.php';
			</script>
			";
			exit();
	}
}

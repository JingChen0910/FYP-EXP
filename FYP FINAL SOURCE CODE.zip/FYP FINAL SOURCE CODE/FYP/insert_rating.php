<?php include("dataconnection.php"); 
  session_start();
  if(!isset($_SESSION['id']) || !isset($_SESSION['name']) || !isset($_SESSION['email']) || !isset($_SESSION['vemail'])){
    echo "<script>window.location.href='clogin.php';</script>";
   }else if(isset($_SESSION['id']) &&  isset($_SESSION['name']) && isset($_SESSION['email']) && isset($_SESSION['vemail'])){
       $vemail = $_SESSION['vemail'];
       if($vemail == false){
        echo "<script>window.location.href='sentOTP.php';</script>";
        exit();
       }
       // else{
       // 	header("Location:./index.php");
       // 	exit();
       // }
   }
  if(isset($_POST["submitrating"]))
  { $customer_id=$_SESSION["id"];
    $rating=$_POST["rating"];
    $comments=$_POST["comments"];
    $order_id=$_POST["order_id"];
    $product_id=$_POST["product_id"];
    date_default_timezone_set('Asia/Kuala_Lumpur');
    $date=date('Y-m-d H:i:s');
    if(strlen(trim($comments)) === 0)
    {
        $insert_rate="INSERT INTO rating(order_id, product_id, customer_id, rating_rate, rating_date) VALUES ($order_id, '$product_id', $customer_id, $rating, '$date')";
        $run_insert_rate=mysqli_query($connect, $insert_rate);
        if($run_insert_rate)
        {
            echo "<script>alert('Thanks for your feedback'); history.go(-1);</script>";
        }
    }
    else
    {
        $insert_rate="INSERT INTO rating(order_id, product_id, customer_id, rating_rate, comments, rating_date) VALUES ($order_id, '$product_id', $customer_id, $rating, '$comments', '$date')";
        $run_insert_rate=mysqli_query($connect, $insert_rate);
        if($run_insert_rate)
        {
            echo "<script>alert('Thanks for your feedback'); history.go(-1);</script>";
        }
    }
  }
?>
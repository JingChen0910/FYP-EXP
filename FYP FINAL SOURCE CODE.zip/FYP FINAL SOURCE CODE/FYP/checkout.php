<!DOCTYPE html>
    <?php include("dataconnection.php");
	session_start();
	if(!isset($_SESSION['id']) || !isset($_SESSION['name']) || !isset($_SESSION['email']) || !isset($_SESSION['vemail'])){
		echo "<script>window.location.href='clogin.php';</script>";
	 }else if(isset($_SESSION['id']) &&  isset($_SESSION['name']) && isset($_SESSION['email']) && isset($_SESSION['vemail'])){
		   $vemail = $_SESSION['vemail'];
		   if($vemail == false){
			echo "<script>window.location.href='sentOTP.php';</script>";
			  exit();
		   }
		   // else{
		   // 	header("Location:./index.php");
		   // 	exit();
		   // }
	 }
    ?>
	<html lang="en">
	<head>
		<title>Book Store</title>
		<meta charset="utf-8">
	    <meta http-equiv="X-UA-Compatible" content="IE=edge">
	    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	    <meta name="format-detection" content="telephone=no">
	    <meta name="apple-mobile-web-app-capable" content="yes">
	    <meta name="author" content="">
	    <meta name="keywords" content="">
	    <meta name="description" content="">

	    <link rel="stylesheet" type="text/css" href="css/normalize.css">
	    <link rel="stylesheet" type="text/css" href="icomoon/icomoon.css">
	    <link rel="stylesheet" type="text/css" href="css/vendor.css">
	    <link rel="stylesheet" type="text/css" href="style.css">
		<!-- script
		================================================== -->
		<script src="http://translate.google.com/translate_a/element.js?cb=loadGoogleTranslate"></script>
		<script src="js/modernizr.js">
			function handle_keyup(event){
				if (event.keyCode === 13) {
                   document.getElementById('search_btn').click();
                }
			}
		</script>
		<script type="text/javascript">
			function validate(track)
			{  var counter=0;
				if(track!=2)
				{
					var rname=document["address_form"]["recipient_name"].value, remail=document["address_form"]["recipient_email"].value, rhp=document["address_form"]["recipient_hp"].value;
					var rn=rname.replace(/\s+/g, ''), re=remail.replace(/\s+/g, ''), rh=rhp.replace(/\s+/g, '');
					var nameRegex = /^(?=[a-zA-Z])[a-zA-Z0-9 ._-]{3,60}$/;
			        var emailRegex = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
			        var hpRegex = /^60\d{2}-\d{7,8}$/;
					var vrname = nameRegex.test(rname);
			        var vremail = emailRegex.test(remail);
			        var vrhp = hpRegex.test(rhp);
					if(rname=="" || rn.length==0)
			        {
				      document.getElementById("recipient_name-error").innerHTML="*Recipient's Name is required";
				     document.getElementById("recipient_name-error").style.color="red";
				document.getElementById("recipient_name-error").style.fontSize="15px";
				counter++;
			   }
			   else
			   {
				document.getElementById("recipient_name-error").innerHTML="";
				if(!vrname)
				{
					document.getElementById("recipient_name-error").innerHTML="*Recipient's Name is invalid";
				    document.getElementById("recipient_name-error").style.color="red";
				    document.getElementById("recipient_name-error").style.fontSize="15px";
				    counter++;
				}
				else
				{
					document.getElementById("recipient_name-error").innerHTML="";
				}
			   }
			   if(rhp=="" || rh.length==0)
			   {
				document.getElementById("recipient_hp-error").innerHTML="*Recipient's Phone Number is required";
				document.getElementById("recipient_hp-error").style.color="red";
				document.getElementById("recipient_hp-error").style.fontSize="15px";
				counter++;
			   }
			   else
			   {
				document.getElementById("recipient_hp-error").innerHTML="";
				if(!vrhp)
				{
					document.getElementById("recipient_hp-error").innerHTML="*Recipient's Phone Number is invalid";
				    document.getElementById("recipient_hp-error").style.color="red";
				    document.getElementById("recipient_hp-error").style.fontSize="15px";
				    counter++;
				}
				else
				{
					document.getElementById("recipient_hp-error").innerHTML="";
				}
			   }
			   if(remail=="" || re.length==0)
			   {
				document.getElementById("recipient_email-error").innerHTML="*Recipient's Email is required";
				document.getElementById("recipient_email-error").style.color="red";
				document.getElementById("recipient_email-error").style.fontSize="15px";
				counter++;
			   }
			   else
			   {
				document.getElementById("recipient_email-error").innerHTML="";
				if(!vremail)
				{
					document.getElementById("recipient_email-error").innerHTML="*Recipient's Email is invalid";
				    document.getElementById("recipient_email-error").style.color="red";
				    document.getElementById("recipient_email-error").style.fontSize="15px";
				    counter++;
				}
				else
				{
					document.getElementById("recipient_email-error").innerHTML="";
				}
			   }
				}
               var address1=document["address_form"]["address1"].value, address2=document["address_form"]["address2"].value, city=document["address_form"]["city"].value, state=document["address_form"]["state"].value, postcode=document["address_form"]["postcode"].value;
			   var add1=address1.replace(/\s+/g, ''), add2=address2.replace(/\s+/g, ''), ct=city.replace(/\s+/g, ''), pc=postcode.replace(/\s+/g, '');
			   var add1Regex = /^(?=.*[A-Za-z])[A-Za-z0-9 .,\/-]{0,99}$/;
               var cityRegex = /\b[a-zA-Z][a-zA-Z\s]+\b/;
			   var melakaregex=/^7[5-8]\d{3}$/, johorregex=/^8[0-6]\d{3}$/, kedahregex=/^0[2-9]\d{3}$/, kelantanregex=/^1[5-8]\d{3}$/, nsregex=/^7[0-3]\d{3}$/, pahangregex=/^2[5-9]\d{3}$/, penangregex=/^1[0-4]\d{3}$/, perakregex=/^3[0-6]\d{3}$/, perlisregex=/^01\d{3}$/, sabahregex=/^8[8-9]\d{3}$|^9[0-1]\d{3}$/, sarawakregex=/^9[3-8]\d{3}$/, selangorregex=/^(4[0-8]|6[2-4]|5[0-9]|60)\d{3}$/, terengganuregex=/^2[0-4]\d{3}$/;
               var vadd1 = add1Regex.test(address1);
			   var vadd2 = add1Regex.test(address2);
               var vcity = cityRegex.test(city);
			   if(address1=="" || add1.length==0)
			   {
				document.getElementById("address1-error").innerHTML="*Address1 is required";
				document.getElementById("address1-error").style.color="red";
				document.getElementById("address1-error").style.fontSize="15px";
				counter++;
			   }
			   else
			   {
				document.getElementById("address1-error").innerHTML="";
				if(!vadd1)
				{
					document.getElementById("address1-error").innerHTML="*Address1 is invalid";
				    document.getElementById("address1-error").style.color="red";
				    document.getElementById("address1-error").style.fontSize="15px";
				    counter++;
				}
				else
				{
					document.getElementById("address1-error").innerHTML="";
				}
			   }
			   if(address2=="" || add2.length==0)
			   {
				document.getElementById("address2-error").innerHTML="*Address2 is required";
				document.getElementById("address2-error").style.color="red";
				document.getElementById("address2-error").style.fontSize="15px";
				counter++;
			   }
			   else
			   {
				document.getElementById("address2-error").innerHTML="";
				if(!vadd2)
				{
					document.getElementById("address2-error").innerHTML="*Address2 is invalid";
				    document.getElementById("address2-error").style.color="red";
				    document.getElementById("address2-error").style.fontSize="15px";
				    counter++;
				}
				else
				{
					document.getElementById("address2-error").innerHTML="";
				}
			   }
			   if(city=="" || ct.length==0)
			   {
				document.getElementById("city-error").innerHTML="*City is required";
				document.getElementById("city-error").style.color="red";
				document.getElementById("city-error").style.fontSize="15px";
				counter++;
			   }
			   else
			   {
				document.getElementById("city-error").innerHTML="";
				if(!vcity)
				{
					document.getElementById("city-error").innerHTML="*City is invalid";
				    document.getElementById("city-error").style.color="red";
				    document.getElementById("city-error").style.fontSize="15px";
				    counter++;
				}
				else
				{
					document.getElementById("city-error").innerHTML="";
				}
			   }
			   if(state=="")
			   {
				document.getElementById("state-error").innerHTML="*State is required";
				document.getElementById("state-error").style.color="red";
				document.getElementById("state-error").style.fontSize="15px";
				counter++;
			   }
			   else
			   {
				document.getElementById("state-error").innerHTML="";
			   }
			   if(postcode=="" || pc.length==0)
			   {
				document.getElementById("postcode-error").innerHTML="*Postcode is required";
				document.getElementById("postcode-error").style.color="red";
				document.getElementById("postcode-error").style.fontSize="15px";
				counter++;
			   }
			   else
			   {
				document.getElementById("postcode-error").innerHTML="";
				if(isNaN(postcode) || postcode.length!=5 || pc.length!=5)
			   {
				document.getElementById("postcode-error").innerHTML="*Invalid postcode";
				document.getElementById("postcode-error").style.color="red";
				document.getElementById("postcode-error").style.fontSize="15px";
				counter++;
			   }
			   else
			   {
				document.getElementById("postcode-error").innerHTML="";
                if(state!="")
				{
					if(state=="Melaka")
					{
						if(!melakaregex.test(postcode))
						{
							document.getElementById("postcode-error").innerHTML="*Postcode not match with state";
							document.getElementById("postcode-error").style.color="red";
				            document.getElementById("postcode-error").style.fontSize="15px";
							counter++;
						}
						else
						{
							document.getElementById("postcode-error").innerHTML="";
						}

					}
					else if(state=="Johor")
					{
						if(!johorregex.test(postcode))
						{
							document.getElementById("postcode-error").innerHTML="*Postcode not match with state";
							document.getElementById("postcode-error").style.color="red";
				            document.getElementById("postcode-error").style.fontSize="15px";
							counter++;
						}
						else
						{
							document.getElementById("postcode-error").innerHTML="";
						}
					}
					else if(state=="Kedah")
					{
						if(!kedahregex.test(postcode))
						{
							document.getElementById("postcode-error").innerHTML="*Postcode not match with state";
							document.getElementById("postcode-error").style.color="red";
				            document.getElementById("postcode-error").style.fontSize="15px";
							counter++;
						}
						else
						{
							document.getElementById("postcode-error").innerHTML="";
						}
					}
					else if(state=="Kelantan")
					{
						if(!kelantanregex.test(postcode))
						{
							document.getElementById("postcode-error").innerHTML="*Postcode not match with state";
							document.getElementById("postcode-error").style.color="red";
				            document.getElementById("postcode-error").style.fontSize="15px";
							counter++;
						}
						else
						{
							document.getElementById("postcode-error").innerHTML="";
						}
					}
					else if(state=="Negeri Sembilan")
					{
						if(!nsregex.test(postcode))
						{
							document.getElementById("postcode-error").innerHTML="*Postcode not match with state";
							document.getElementById("postcode-error").style.color="red";
				            document.getElementById("postcode-error").style.fontSize="15px";
							counter++;
						}
						else
						{
							document.getElementById("postcode-error").innerHTML="";
						}
					}
					else if(state=="Pahang")
					{
						if(!pahangregex.test(postcode))
						{
							document.getElementById("postcode-error").innerHTML="*Postcode not match with state";
							document.getElementById("postcode-error").style.color="red";
				            document.getElementById("postcode-error").style.fontSize="15px";
							counter++;
						}
						else
						{
							document.getElementById("postcode-error").innerHTML="";
						}
					}
					else if(state=="Penang")
					{
						if(!penangregex.test(postcode))
						{
							document.getElementById("postcode-error").innerHTML="*Postcode not match with state";
							document.getElementById("postcode-error").style.color="red";
				            document.getElementById("postcode-error").style.fontSize="15px";
							counter++;
						}
						else
						{
							document.getElementById("postcode-error").innerHTML="";
						}
					}
					else if(state=="Perak")
					{
						if(!perakregex.test(postcode))
						{
							document.getElementById("postcode-error").innerHTML="*Postcode not match with state";
							document.getElementById("postcode-error").style.color="red";
				            document.getElementById("postcode-error").style.fontSize="15px";
							counter++;
						}
						else
						{
							document.getElementById("postcode-error").innerHTML="";
						}
					}
					else if(state=="Perlis")
					{
						if(!perlisregex.test(postcode))
						{
							document.getElementById("postcode-error").innerHTML="*Postcode not match with state";
							document.getElementById("postcode-error").style.color="red";
				            document.getElementById("postcode-error").style.fontSize="15px";
							counter++;
						}
						else
						{
							document.getElementById("postcode-error").innerHTML="";
						}
					}
					else if(state=="Sabah")
					{
						if(!sabahregex.test(postcode))
						{
							document.getElementById("postcode-error").innerHTML="*Postcode not match with state";
							document.getElementById("postcode-error").style.color="red";
				            document.getElementById("postcode-error").style.fontSize="15px";
							counter++;
						}
						else
						{
							document.getElementById("postcode-error").innerHTML="";
						}
					}
					else if(state=="Sarawak")
					{
						if(!sarawakregex.test(postcode))
						{
							document.getElementById("postcode-error").innerHTML="*Postcode not match with state";
							document.getElementById("postcode-error").style.color="red";
				            document.getElementById("postcode-error").style.fontSize="15px";
							counter++;
						}
						else
						{
							document.getElementById("postcode-error").innerHTML="";
						}
					}
					else if(state=="Selangor")
					{
						if(!selangorregex.test(postcode))
						{
							document.getElementById("postcode-error").innerHTML="*Postcode not match with state";
							document.getElementById("postcode-error").style.color="red";
				            document.getElementById("postcode-error").style.fontSize="15px";
							counter++;
						}
						else
						{
							document.getElementById("postcode-error").innerHTML="";
						}
					}
					else if(state=="Terengganu")
					{
						if(!terengganuregex.test(postcode))
						{
							document.getElementById("postcode-error").innerHTML="*Postcode not match with state";
							document.getElementById("postcode-error").style.color="red";
				            document.getElementById("postcode-error").style.fontSize="15px";
							counter++;
						}
						else
						{
							document.getElementById("postcode-error").innerHTML="";
						}
					}
				}
			   }
			   }
			   if(counter!=0)
			   { return false; }
			}
			function getValue()
			{
				var address_form = document.forms["address_form"];
				var selectaddress_form=document.getElementById("selectaddress_form");
				var detect_form=document.getElementById("dpl_addfrm");
				if(detect_form)
				{
					detect_form.remove();
				}
				if(selectaddress_form)
				{
					var pay_type1=document.getElementById("select_address1"), pay_type2=document.getElementById("select_address2");
                    if(pay_type1.checked)
					{
						document.getElementById("duplicate_addfrm").innerHTML="<form id='dpl_addfrm' name='dpl_addfrm' method='POST' action='cart.php'><input type='text' id='paytype' name='paytype'><input type='submit' id='dpladdressbtn' name='dpladdressbtn'></form>"
					    document.getElementById("paytype").value=pay_type1.value;
						document.getElementById("paytype").style.display="none"; document.getElementById("dpladdressbtn").style.display="none";
					}
					else if(pay_type2.checked)
					{
						var rname=address_form.elements["recipient_name"].value; var remail=address_form.elements["recipient_email"].value; var rhp=address_form.elements["recipient_hp"].value; address1=address_form.elements["address1"].value; var address2=address_form.elements["address2"].value; var city=address_form.elements["city"].value; var state=address_form.elements["state"].value; var postcode=address_form.elements["postcode"].value;
						document.getElementById("duplicate_addfrm").innerHTML="<form id='dpl_addfrm' name='dpl_addfrm' method='POST' action='cart.php'><input type='text' id='rname' name='rname'><input type='text' id='remail' name='remail'><input type='text' id='rhp' name='rhp'><input type='text' id='paytype' name='paytype'><input type='text' id='dpaddress1' name='dpaddress1'><input type='text' id='dpaddress2' name='dpaddress2'><input type='text' id='dpcity' name='dpcity'><input type='text' id='dpstate' name='dpstate'><input type='text' id='dppostcode' name='dppostcode'><input type='submit' id='dpladdressbtn' name='dpladdressbtn'></form>"
					    document.getElementById("rname").value=rname; document.getElementById("remail").value=remail; document.getElementById("rhp").value=rhp; document.getElementById("paytype").value=pay_type2.value; document.getElementById("dpaddress1").value=address1; document.getElementById("dpaddress2").value=address2; document.getElementById("dpcity").value=city; document.getElementById("dpstate").value=state; document.getElementById("dppostcode").value=postcode;
					    document.getElementById("rname").style.display="none"; document.getElementById("remail").style.display="none"; document.getElementById("rhp").style.display="none"; document.getElementById("paytype").style.display="none"; document.getElementById("dpaddress1").style.display="none"; document.getElementById("dpaddress2").style.display="none"; document.getElementById("dpcity").style.display="none"; document.getElementById("dpstate").style.display="none"; document.getElementById("dppostcode").style.display="none"; document.getElementById("dpladdressbtn").style.display="none";
					}
				}
				else
				{
					var address1=address_form.elements["address1"].value; var address2=address_form.elements["address2"].value; var city=address_form.elements["city"].value; var state=address_form.elements["state"].value; var postcode=address_form.elements["postcode"].value;
					document.getElementById("duplicate_addfrm").innerHTML="<form id='dpl_addfrm' name='dpl_addfrm' method='POST' action='cart.php'><input type='text' id='dpaddress1' name='dpaddress1'><input type='text' id='dpaddress2' name='dpaddress2'><input type='text' id='dpcity' name='dpcity'><input type='text' id='dpstate' name='dpstate'><input type='text' id='dppostcode' name='dppostcode'><input type='submit' id='dpladdressbtn' name='dpladdressbtn'></form>"
					document.getElementById("dpaddress1").value=address1; document.getElementById("dpaddress2").value=address2; document.getElementById("dpcity").value=city; document.getElementById("dpstate").value=state; document.getElementById("dppostcode").value=postcode;
				    document.getElementById("dpaddress1").style.display="none"; document.getElementById("dpaddress2").style.display="none"; document.getElementById("dpcity").style.display="none"; document.getElementById("dpstate").style.display="none"; document.getElementById("dppostcode").style.display="none"; document.getElementById("dpladdressbtn").style.display="none";
				}
			}
			function loadGoogleTranslate() {
    const defaultLanguage = "en";

    const translateElement = new google.translate.TranslateElement({
      pageLanguage: defaultLanguage,
      includedLanguages: "en,ms,zh-CN",
      layout: google.translate.TranslateElement.InlineLayout.SIMPLE
    }, "google_element");

    // Get the language select dropdown element
    const languageSelect = document.getElementById("languageSelect");

    // Function to set a cookie
    function setCookie(name, value, days) {
      const expires = new Date();
      expires.setTime(expires.getTime() + days * 24 * 60 * 60 * 1000);
      document.cookie = `${name}=${value};expires=${expires.toUTCString()};path=/`;
    }

    // Function to get a cookie value
    function getCookie(name) {
      const cookieName = `${name}=`;
      const cookies = document.cookie.split(';');
      for (let i = 0; i < cookies.length; i++) {
        let cookie = cookies[i];
        while (cookie.charAt(0) === ' ') {
          cookie = cookie.substring(1);
        }
        if (cookie.indexOf(cookieName) === 0) {
          return cookie.substring(cookieName.length, cookie.length);
        }
      }
      return null;
    }

    // Set the initial language selection
    const storedLanguage = getCookie("selectedLanguage");
    if (storedLanguage) {
      languageSelect.value = storedLanguage;
      translateElement.update({
        includedLanguages: storedLanguage
      });
    }

    // Add event listener for change event
    languageSelect.addEventListener("change", function() {
      const selectedLanguage = this.value;
      translateElement.update({
        includedLanguages: selectedLanguage
      });
      setCookie("selectedLanguage", selectedLanguage, 30); // Set the cookie for 30 days
    });
  }
		</script>
	</head>

<body>

<div id="header-wrap">

	<div class="top-content">
		<div class="container">
			<div class="row">
				<div class="col-md-6" style="width: 25%;">

				</div>
				<div class="col-md-6" style="width: 75%;">
					<div class="right-element">
						<?php
						if(isset($_SESSION["id"]))
						{   $cust_id=$_SESSION["id"];
							$cartsql="SELECT * FROM cart WHERE customer_id=$cust_id";
							$run_cartsql=mysqli_query($connect, $cartsql);
							$num_rows_cartsql=mysqli_num_rows($run_cartsql);
							$rows_cartsql=mysqli_fetch_assoc($run_cartsql);
							if($num_rows_cartsql==0)
							{
								$cartitem_rows=0;
							}
							else
							{   $cartid=$rows_cartsql["cart_id"];
								$cartitemsql="SELECT * FROM cart_item WHERE cart_id=$cartid";
							    $run_cartitemsql=mysqli_query($connect, $cartitemsql);
							    $cartitem_rows=mysqli_num_rows($run_cartitemsql);
								$del_val=0;
								while($rows_cartitemsql=mysqli_fetch_assoc($run_cartitemsql))
								{
                                  $prodid=$rows_cartitemsql["product_id"];
								  $itemqty=$rows_cartitemsql["item_quantity"];
								  $stocksql="SELECT * FROM stock WHERE product_id='$prodid'";
                                  $run_stocksql=mysqli_query($connect, $stocksql);
                                  $stockrows=mysqli_fetch_assoc($run_stocksql);
                                  $stocklevel=$stockrows['stock_level'];
								  $prodsql="SELECT * FROM product WHERE product_id='$prodid' AND availability=0";
                                  $run_prodsql=mysqli_query($connect, $prodsql);
                                  $prodrows=mysqli_num_rows($run_prodsql);
								  if($prodrows==0)
								  {
									$del_cartitem="DELETE FROM cart_item WHERE cart_id=$cartid AND product_id='$prodid'";
									$run_del_cartitem=mysqli_query($connect, $del_cartitem);
									if($run_del_cartitem)
                                      $del_val++;
								  }
								  else if($stocklevel==0)
								  {
									$del_cartitem="DELETE FROM cart_item WHERE cart_id=$cartid AND product_id='$prodid'";
									$run_del_cartitem=mysqli_query($connect, $del_cartitem);
									if($run_del_cartitem)
                                      $del_val++;
								  }
								  else if($itemqty>$stocklevel)
								  {
									$update_cartitem="UPDATE cart_item SET item_quantity=$stocklevel WHERE cart_id=$cartid AND product_id='$prodid'";
									$run_update_cartitem=mysqli_query($connect, $update_cartitem);
								  }
								}
								if($del_val==$cartitem_rows)
								{
									$del_cart="DELETE FROM cart WHERE cart_id=$cartid";
									$run_del_cart=mysqli_query($connect, $del_cart);
								}
								$cartitem_rows-=$del_val;
							}
							$select_cust="SELECT * FROM customer WHERE customer_id=$cust_id";
							$run_select_cust=mysqli_query($connect, $select_cust);
							$row_select_cust=mysqli_fetch_assoc($run_select_cust);
							$user_profile=$row_select_cust["customer_profile_picture"];
                            $custaddresssql="SELECT * FROM address WHERE customer_id=$cust_id";
                            $run_custaddresssql=mysqli_query($connect, $custaddresssql);
                            $num_rowscustaddress=mysqli_num_rows($run_custaddresssql);
							?>
							<?php
							if($num_rowscustaddress!=0 && !isset($_POST["select_addressbtn"]) && !isset($_POST["preturnbtn"]) && !isset($_SESSION["ptype"]))
							{?><a href="cart.php" class="cart for-buy"><img src="images/icon/carts.png" style="width: 50px; height: 50px; opacity: 70%; margin-bottom: 5px;"><span>Cart: <?php echo $cartitem_rows; ?> item(s)</span></a>
							<?php
							}
							else
							{?><a href="#" onclick="getValue(); document.getElementById('dpladdressbtn').click();" class="cart for-buy"><img src="images/icon/carts.png" style="width: 50px; height: 50px; opacity: 70%; margin-bottom: 5px;"><span>Cart: <?php echo $cartitem_rows; ?> item(s)</span></a>
							 <?php
							}
							?>
							<a href="order_history.php" class="cart for-buy"><i class="icon icon-clipboard"></i> <span>Order History</span></a>
						<nav id="navbar" style="display: inline-block; margin-left: -40px; position: relative; z-index: 3;">
						<div class="main-menu stellarnav">
						<ul class="menu-list">
						<li class="menu-item has-sub">
						<a href="./user_profile.php" class="nav-link" data-effect="Pages"><img src="images/cus_profile/<?php echo $user_profile; ?>" style="width: 40px; height: 40px; border-radius: 50%; margin-right: 10px;" alt="user_profile" title="user_profile">Account</a>
							<ul style="font-size: 16px;">
								<li><a href="./user_profile.php">My Profile</a></li>
								<li><a href="./logoutaction.php">Logout</a></li>
							 </ul>
						</li>
						</ul>
						</div>
						</nav>
						<?php
						}
						?>

						<div class="action-menu" style="margin-left: 10px;">

                          <div class="search-bar">
	                      <a href="#" class="search-button search-toggle" data-selector="#header-wrap">
		                     <i class="icon icon-search"></i>
	                      </a>
	                      <form role="search" method="get" class="search-box" action="search_products.php">
		                  <input class="search-field text search-input" placeholder="Search products" type="text" name="search_keyword" onkeyup="handle_keyup(event)">
		                  <input type="submit" id="search_btn" style="display: none;">
	                      </form>
                          </div>
                        </div>
                        <div id="google_element" style="display: inline-block;"></div>
					</div><!--top-right-->
				</div>

			</div>
		</div>
	</div><!--top-content-->

	<header id="header" style="background-color: #f3e7be;">
		<div class="container">
			<div class="row">

			    <div class="col-md-2">
					<!--<div class="main-logo">-->
						<a href="index.php"><img src="images/icon/logo.png" alt="logo" style="height: 140px; margin:-60px 0px -30px 0px;"></a>
					<!--</div>-->
				</div>

				<div class="col-md-10">

					<nav id="navbar" style="position: relative; z-index: 1;">
						<div class="main-menu stellarnav">
							<ul class="menu-list">
								<li class="menu-item active"><a href="index.php" data-effect="Home">Home</a></li>
								<li class="menu-item"><a href="about_us.php" class="nav-link" data-effect="About">About</a></li>
								<!--<li class="menu-item has-sub">
									<a href="#pages" class="nav-link" data-effect="Pages">Pages</a>

									<ul>
								        <li><a href="styles.html">Styles</a></li>
								        <li><a href="blog.html">Blog</a></li>
								        <li><a href="single-post.html">Post Single</a></li>
								        <li><a href="thank-you.html">Thank You</a></li>
								     </ul>

								</li>-->
								<li class="menu-item"><a href="shop.php" class="nav-link" data-effect="Shop">Shop</a></li>
								<li class="menu-item"><a href="contact.php" class="nav-link" data-effect="Contact">Contact Us</a></li>
							</ul>

							<div class="hamburger">
				                <span class="bar"></span>
				                <span class="bar"></span>
				                <span class="bar"></span>
				            </div>

						</div>
					</nav>

				</div>

			</div>
		</div>
	</header>

</div><!--header-wrap-->

<div>
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div class="colored">
					<br>
					<div class="breadcum-items">
					<?php
							if($num_rowscustaddress!=0 && !isset($_POST["select_addressbtn"]) && !isset($_POST["preturnbtn"]) && !isset($_SESSION["ptype"]))
							{?><span class="item"><a href="cart.php">Cart </a> > </span>
							<?php
							}
							else
							{?><span class="item"><a href="#" onclick="getValue(); document.getElementById('dpladdressbtn').click();">Cart </a> > </span>
							 <?php
							}
							?>
						<span class="item colored" style="font-weight: bold;">Shipping</span> >
						<span class="item colored">Payment</span>
					</div>
				</div>
			</div>
		</div>
	</div>
</div><!--site-banner-->

<section class="padding-large">
<div class="container"style="margin: auto; background-color: white;">
<div style="height: 40px; background-color: #f1daa0; width: 103%; font-weight: bold; font-size: 20px; margin-left: -20px;"><span style="margin-left: 20px; color: #866e37;">Step 1 of 2: Shipping</span></div>
<div class="wrap-all-pay">
<?php $track=0; $del=0;
	$custaddress_sql="SELECT * FROM address WHERE customer_id=$cust_id";
	$run_custaddress_sql=mysqli_query($connect, $custaddress_sql);
	$num_rows_custaddress=mysqli_num_rows($run_custaddress_sql);
	if($num_rows_custaddress==0)
	{$track++; }?>
<div class="container" style="width:40%; float:left; <?php if(isset($_POST["select_addressbtn"]) || $track!=0 || isset($_POST["preturnbtn"]) || isset($_SESSION["ptype"]) && $cartitem_rows<10) echo 'border-right: 1px dotted grey;'?>">
    <div class="wrap-pay-elements" style="margin-left: 30px;">
    <div class="pay-body">
	<?php $set=0; ?>
	<h3>Recipient's Information</h3>
	<?php
	if(isset($_SESSION["ptype"]) && isset($_POST["select_addressbtn"]))
	{
		$_SESSION["ptype"]=$select_address=$_POST["select_address"];
		if($_SESSION["ptype"]=="r2")
		{  $_SESSION["rname"]="";
		   $_SESSION["remail"]="";
		   $_SESSION["rhp"]="";
		   $_SESSION["padd1"]="";
		   $_SESSION["padd2"]="";
		   $_SESSION["pst"]="";
		   $_SESSION["pct"]="";
		   $_SESSION["ppc"]="";
		}
		else if($_SESSION["ptype"]=="r1")
		{
			$custaddress_sql="SELECT * FROM address WHERE customer_id=$cust_id";
		 $run_custaddress_sql=mysqli_query($connect, $custaddress_sql);
		 $num_rows_custaddress=mysqli_num_rows($run_custaddress_sql);
		if($num_rows_custaddress==1)
		{
		  while($rows_custaddress=mysqli_fetch_assoc($run_custaddress_sql))
		  {
			  $_SESSION["padd1"]=$address1=$rows_custaddress["address1"];
			  $_SESSION["padd2"]=$address2=$rows_custaddress["address2"];
			  $_SESSION["pst"]=$state=$rows_custaddress["state"];
			  $_SESSION["pct"]=$city=$rows_custaddress["city"];
			  $_SESSION["ppc"]=$postcode=$rows_custaddress["postalCode"];
		  }
		}
		}
	}
	if(isset($_POST["select_addressbtn"]))
	{
	  $select_address=$_POST["select_address"];
	  if($select_address=="r1")
		{
            $set++;
		 $custaddress_sql="SELECT * FROM address WHERE customer_id=$cust_id";
		 $run_custaddress_sql=mysqli_query($connect, $custaddress_sql);
		 $num_rows_custaddress=mysqli_num_rows($run_custaddress_sql);
		if($num_rows_custaddress==1)
		{
		  while($rows_custaddress=mysqli_fetch_assoc($run_custaddress_sql))
		  {
             $address1=$rows_custaddress["address1"];
			 $address2=$rows_custaddress["address2"];
			 $state=$rows_custaddress["state"];
			 $city=$rows_custaddress["city"];
			 $postcode=$rows_custaddress["postalCode"];
		  }
	    }
		}
	}
	if(isset($_SESSION["ptype"]) && !isset($_POST["select_addressbtn"]))
	{   $select_address=$_SESSION["ptype"];
		if($_SESSION["ptype"]=="r1")
		{
			$custaddress_sql="SELECT * FROM address WHERE customer_id=$cust_id";
		 $run_custaddress_sql=mysqli_query($connect, $custaddress_sql);
		 $num_rows_custaddress=mysqli_num_rows($run_custaddress_sql);
		if($num_rows_custaddress==1)
		{
		  while($rows_custaddress=mysqli_fetch_assoc($run_custaddress_sql))
		  {
			  $_SESSION["padd1"]=$address1=$rows_custaddress["address1"];
			  $_SESSION["padd2"]=$address2=$rows_custaddress["address2"];
			  $_SESSION["pst"]=$state=$rows_custaddress["state"];
			  $_SESSION["pct"]=$city=$rows_custaddress["city"];
			  $_SESSION["ppc"]=$postcode=$rows_custaddress["postalCode"];
		  }
		}
		}
	}
	if(isset($_POST["preturnbtn"]))
	{  if(isset($_POST["pselect"]))
	   {
		  $select_address=$_POST["pselect"];
	   }
	   else
	   {
		  $select_address="r1"; $set++;
	   }
	}
	if($num_rows_custaddress!=0)
	{?>
	<form id="selectaddress_form" method="POST">
    <p>
        <input type="radio" id="select_address1" name="select_address" value="r1" onclick="document.getElementById('addressbtn').click()" <?php if(isset($_POST["select_addressbtn"]) && $select_address=="r1" || isset($_POST["preturnbtn"]) && $select_address=="r1" || isset($_SESSION["ptype"]) && $_SESSION["ptype"]=="r1") echo "checked"; ?>></a> Registered Address<br>
        <input type="radio" id="select_address2" name="select_address" value="r2" onclick="document.getElementById('addressbtn').click()" <?php if(isset($_POST["select_addressbtn"]) && $select_address=="r2" || isset($_POST["preturnbtn"]) && $select_address=="r2" || isset($_SESSION["ptype"]) && $_SESSION["ptype"]=="r2") echo "checked"; ?>> New Shipping Address
		<input type="submit" id="addressbtn" name="select_addressbtn" style="display: none;">
		<?php
		if(!isset($_POST["select_addressbtn"]) && !isset($_POST["preturnbtn"]) && !isset($_SESSION["ptype"]))
		{
			echo "<br><span><a href='cart.php'>Back to Cart</a></span>";
		}
		?>
    </p>
    </form>
    <?php
	}
	else
	{   $track++;
		echo "<p>You haven't register your address. Please register your address first before purchase.</p>";
	}
	if(isset($_POST["select_addressbtn"]) || $track!=0 || isset($_POST["preturnbtn"]) || isset($_SESSION["ptype"]))
	{   if(isset($_POST["preturnbtn"]))
		{   if(isset($_POST["cardtype"]))
			{   $_SESSION["cardtype"]=$_POST["cardtype"];
				$_SESSION["holder_name"]=$_POST["holder_name"];
				$_SESSION["cardnum"]=$_POST["cardnum"];
				$_SESSION["cardvv"]=$_POST["cardvv"];
				$_SESSION["carddate"]=$_POST["carddate"];
			}
			/*if(isset($_POST["ewallet_types"]))
			{
				$_SESSION["ewallet_types"]=$_POST["ewallet_types"];
				$_SESSION["transaction_no"]=$_POST["transaction_no"];
			}*/
			if(isset($_POST["pselect"]))
			{
              $pselect=$_POST["pselect"];
			  if($pselect=="r2")
			  { $rname=$_POST["rname"];
				$remail=$_POST["remail"];
				$rhp=$_POST["rhp"];
				$address1=$_POST["paddress1"];
			    $address2=$_POST["paddress2"];
			    $city=$_POST["pcity"];
			    $postcode=$_POST["ppostcode"];
			    $state=$_POST["pstate"];
			  }
			  else if($pselect=="r1")
			  {
				$custaddress_sql="SELECT * FROM address WHERE customer_id=$cust_id";
	            $run_custaddress_sql=mysqli_query($connect, $custaddress_sql);
	            $num_rows_custaddress=mysqli_num_rows($run_custaddress_sql);
				if($num_rows_custaddress==1)
				{   $set++;
					while($rows_custaddress=mysqli_fetch_assoc($run_custaddress_sql))
		            {
                      $address1=$rows_custaddress["address1"];
			          $address2=$rows_custaddress["address2"];
			          $state=$rows_custaddress["state"];
			          $city=$rows_custaddress["city"];
			          $postcode=$rows_custaddress["postalCode"];
		            }
				}
				else
				{
                  $del++;
				  $state="0";
				}
			  }
			}
			else
			{
				$address1=$_POST["paddress1"];
			    $address2=$_POST["paddress2"];
			    $city=$_POST["pcity"];
			    $postcode=$_POST["ppostcode"];
			    $state=$_POST["pstate"];
			}
		}
		?>
       <form id="address_form" name="address_form" method="POST" action="payment.php" onsubmit="return validate('<?php echo $track; ?>')">
	   <input type="text" name="track" value="<?php echo $track; ?>" style="display: none;">
	   <?php
	   if($track==0)
	   {?>
	   <input type="text" name="select_address" value="<?php echo $select_address; ?>" style="display: none;">
	   <?php
	   }
	   if(isset($_POST["select_addressbtn"]) && $select_address=="r1")
	   {
		unset($_SESSION["rname"]);
		unset($_SESSION["remail"]);
		unset($_SESSION["rhp"]);
		unset($_SESSION["padd1"]);
		unset($_SESSION["padd2"]);
		unset($_SESSION["pst"]);
		unset($_SESSION["pct"]);
		unset($_SESSION["ppc"]);
	   }
	   else if(isset($_POST["select_addressbtn"]) && $select_address=="r2")
	   {
		$address1="";
		$address2="";
		$city="";
		$postcode="";
		$state="";
		unset($_SESSION["padd1"]);
		unset($_SESSION["padd2"]);
		unset($_SESSION["pst"]);
		unset($_SESSION["pct"]);
		unset($_SESSION["ppc"]);
	   }
	   if(isset($_POST["select_addressbtn"]) && $select_address=="r2" || isset($_POST["preturnbtn"]) && $select_address=="r2" || isset($_SESSION["ptype"]) && $_SESSION["ptype"]=="r2")
	   {
		?>
	   <div style="font-size: 18px; <?php if($set==1 || isset($_SESSION["ptype"]) && $_SESSION["ptype"]=="r1") echo 'display: none;'; ?>">
	   Name<span style='color: red;'>*</span><br><input type="text" id="recipient_name" name="recipient_name" style="width: 400px;" <?php
	   if(isset($_POST["preturnbtn"]) && $del==0){ echo "value='$rname'";}
	   else if(isset($_SESSION["rname"]) && isset($_SESSION["ptype"]) && $_SESSION["ptype"]=="r2"){ $rname=$_SESSION["rname"]; echo "value='$rname'"; }
	   else if(isset($_SESSION["rname"])){ $rname=$_SESSION["rname"]; echo "value='$rname'"; }?>>
	   <br><span id="recipient_name-error" style="position: relative; top: -30px; margin-bottom: 10px;"></span>
	   </div>
	   <div style="font-size: 18px; <?php if($set==1 || isset($_SESSION["ptype"]) && $_SESSION["ptype"]=="r1") echo 'display: none;'; ?>">
	   Email<span style='color: red;'>*</span><br><input type="text" id="recipient_email" name="recipient_email" style="width: 400px;"<?php
	   if(isset($_POST["preturnbtn"]) && $del==0){ echo "value='$remail'";}
	   else if(isset($_SESSION["remail"]) && isset($_SESSION["ptype"]) && $_SESSION["ptype"]=="r2"){ $remail=$_SESSION["remail"]; echo "value='$remail'"; }
	   else if(isset($_SESSION["remail"])){ $remail=$_SESSION["remail"]; echo "value='$remail'"; }?>>
	   <br><span id="recipient_email-error" style="position: relative; top: -30px; margin-bottom: 10px;"></span>
	   </div>
	   <div style="font-size: 18px; <?php if($set==1 || isset($_SESSION["ptype"]) && $_SESSION["ptype"]=="r1") echo 'display: none;'; ?>">
	   Phone Number<span style='color: red;'>*</span> (Malaysia format only, eg. 60xx-xxxxxxx)<br><input type="text" id="recipient_hp" name="recipient_hp" style="width: 400px;"<?php
	   if(isset($_POST["preturnbtn"]) && $del==0){ echo "value='$rhp'";}
	   else if(isset($_SESSION["rhp"]) && isset($_SESSION["ptype"]) && $_SESSION["ptype"]=="r2"){ $rhp=$_SESSION["rhp"]; echo "value='$rhp'"; }
	   else if(isset($_SESSION["rhp"])){ $rhp=$_SESSION["rhp"]; echo "value='$rhp'"; }?>>
	   <br><span id="recipient_hp-error" style="position: relative; top: -30px; margin-bottom: 10px;"></span>
	   </div>
	   <?php
	   }
	   ?>
    <div style="font-size: 18px;">
	    Address1<span style='color: red;'>*</span><br>
        <textarea id="address1" name="address1" style="width: 380px; height: 100px;" <?php if(/*!isset($_SESSION["pf"]) &&*/!isset($_SESSION["del"]) && isset($address1) && $set==1 && $address1!="" || /*!isset($_SESSION["pf"]) &&*/ isset($_SESSION["ptype"]) && $_SESSION["ptype"]=="r1" && isset($_SESSION["padd1"]))
		{ echo "disabled"; }?>><?php if(/*!isset($_SESSION["pf"]) &&*/ !isset($_SESSION["del"]) && isset($address1) && $set==1 && $address1!="" || /*!isset($_SESSION["pf"]) &&*/ !isset($_SESSION["del"]) && isset($_POST["preturnbtn"]) && $del==0){ echo trim($address1); } else if(!isset($_SESSION["del"]) && isset($_SESSION["padd1"])){ echo trim($_SESSION["padd1"]); } ?></textarea>
        <br><span id="address1-error" style="position: relative; top: -40px; margin-bottom: 10px;"></span>
	</div>
    <div style="font-size: 18px;">
	    Address2<span style='color: red;'>*</span><br>
        <textarea id="address2" name="address2" style="width: 380px; height: 100px;"
		<?php if(/*!isset($_SESSION["pf"]) &&*/!isset($_SESSION["del"]) && isset($address2) && $set==1 && $address2!="" || /*!isset($_SESSION["pf"]) &&*/ !isset($_SESSION["del"]) && isset($_SESSION["ptype"]) && $_SESSION["ptype"]=="r1" && isset($_SESSION["padd2"]))
		{ echo "disabled"; }?>><?php if(/*!isset($_SESSION["pf"]) &&*/!isset($_SESSION["del"]) && isset($address2) &&  $set==1 && $address2!="" || /*!isset($_SESSION["pf"]) &&*/ !isset($_SESSION["del"]) && isset($_POST["preturnbtn"]) && $del==0){ echo trim($address2); } else if(!isset($_SESSION["del"]) && isset($_SESSION["padd2"])){ echo trim($_SESSION["padd2"]); }?></textarea>
		<br><span id="address2-error" style="position: relative; top: -40px; margin-bottom: 10px;"></span>
	</div>
	<div style="font-size: 18px;">
	    City<span style='color: red;'>*</span><br>
        <input type="text" id="city" name="city" style="width: 300px;" <?php if(/*!isset($_SESSION["pf"]) &&*/!isset($_SESSION["del"]) && isset($city) && $set==1 && $city!=""){ echo "value='$city' disabled"; } else if(/*!isset($_SESSION["pf"]) &&*/ !isset($_SESSION["del"]) && isset($_POST["preturnbtn"]) && $del==0){ echo "value='$city'";} else if(!isset($_SESSION["del"]) && isset($_SESSION["ptype"]) && $_SESSION["ptype"]=="r1" && isset($_SESSION["pct"])){ $city=$_SESSION["pct"]; echo "value='$city' disabled"; } else if(!isset($_SESSION["del"]) && isset($_SESSION["pct"])){ $city=$_SESSION["pct"]; echo "value='$city'"; }?>>
	    <br><span id="city-error" style="position: relative; top: -30px; margin-bottom: 10px;"></span>
	</div>
	<div style="font-size: 18px;">
	    PostalCode<span style='color: red;'>*</span><br>
        <input type="text" id="postcode" name="postcode" <?php if(/*!isset($_SESSION["pf"]) &&*/!isset($_SESSION["del"]) && isset($postcode) && $set==1 && $postcode!=""){ echo "value='$postcode' disabled"; } else if(/*!isset($_SESSION["pf"]) &&*/ !isset($_SESSION["del"]) && isset($_POST["preturnbtn"]) && $del==0){ echo "value='$postcode'";} else if(!isset($_SESSION["del"]) && isset($_SESSION["ptype"]) && $_SESSION["ptype"]=="r1" && isset($_SESSION["ppc"])){ $postcode=$_SESSION["ppc"]; echo "value='$postcode' disabled"; } else if(!isset($_SESSION["del"]) && isset($_SESSION["ppc"])){ $postcode=$_SESSION["ppc"]; echo "value='$postcode'"; }?> maxlength="5">
		<br><span id="postcode-error" style="position: relative; top: -30px; margin-bottom: 10px;"></span>
	</div>
	<div style="font-size: 18px;">
	    State<span style='color: red;'>*</span><br>
        <select id="state" name="state" <?php if(/*!isset($_SESSION["pf"]) &&*/!isset($_SESSION["del"]) && isset($state) && $set==1 && $state!="" || /*!isset($_SESSION["pf"]) &&*/ !isset($_SESSION["del"]) && isset($_SESSION["ptype"]) && $_SESSION["ptype"]=="r1" && isset($_SESSION["pst"])){ echo "disabled"; }?>>
		<option value=''>Select your state</option>
		<option value='Johor' <?php if(/*!isset($_SESSION["pf"]) &&*/!isset($_SESSION["del"]) && isset($state) &&  $set==1 && $state=='Johor' || /*!isset($_SESSION["pf"]) &&*/ !isset($_SESSION["del"]) && isset($_POST["preturnbtn"]) && $state=='Johor' || !isset($_SESSION["del"]) && /*!isset($_SESSION["pf"]) &&*/ isset($_SESSION["pst"]) && $_SESSION["pst"]=='Johor'){ echo "selected"; }?>>Johor</option>
        <option value='Kedah' <?php if(/*!isset($_SESSION["pf"]) &&*/!isset($_SESSION["del"]) && isset($state) &&  $set==1 && $state=='Kedah' || /*!isset($_SESSION["pf"]) &&*/ !isset($_SESSION["del"]) && isset($_POST["preturnbtn"]) && $state=='Kedah' || !isset($_SESSION["del"]) && /*!isset($_SESSION["pf"]) &&*/ isset($_SESSION["pst"]) && $_SESSION["pst"]=='Kedah'){ echo "selected"; }?>>Kedah</option>
        <option value='Kelantan' <?php if(/*!isset($_SESSION["pf"]) &&*/!isset($_SESSION["del"]) && isset($state) &&  $set==1 && $state=='Kelantan' || /*!isset($_SESSION["pf"]) &&*/ !isset($_SESSION["del"]) && isset($_POST["preturnbtn"]) && $state=='Kelantan' || !isset($_SESSION["del"]) && /*!isset($_SESSION["pf"]) &&*/ isset($_SESSION["pst"]) && $_SESSION["pst"]=='Kelantan'){ echo "selected"; }?>>Kelantan</option>
        <option value='Melaka' <?php if(/*!isset($_SESSION["pf"]) &&*/!isset($_SESSION["del"]) && isset($state) &&  $set==1 && $state=='Melaka' || /*!isset($_SESSION["pf"]) &&*/ !isset($_SESSION["del"]) && isset($_POST["preturnbtn"]) && $state=='Melaka' || !isset($_SESSION["del"]) && /*!isset($_SESSION["pf"]) &&*/ isset($_SESSION["pst"]) && $_SESSION["pst"]=='Melaka'){ echo "selected"; }?>>Melaka</option>
        <option value='Negeri Sembilan' <?php if(/*!isset($_SESSION["pf"]) &&*/!isset($_SESSION["del"]) && isset($state) &&  $set==1 && $state=='Negeri Sembilan' || /*!isset($_SESSION["pf"]) &&*/ !isset($_SESSION["del"]) && isset($_POST["preturnbtn"]) && $state=='Negeri Sembilan' || !isset($_SESSION["del"]) && /*!isset($_SESSION["pf"]) &&*/ isset($_SESSION["pst"]) && $_SESSION["pst"]=='Negeri Sembilan'){ echo "selected"; }?>>Negeri Sembilan</option>
        <option value='Pahang' <?php if(/*!isset($_SESSION["pf"]) &&*/!isset($_SESSION["del"]) && isset($state) &&  $set==1 && $state=='Pahang' || /*!isset($_SESSION["pf"]) &&*/ !isset($_SESSION["del"]) && isset($_POST["preturnbtn"]) && $state=='Pahang' || !isset($_SESSION["del"]) && /*!isset($_SESSION["pf"]) &&*/ isset($_SESSION["pst"]) && $_SESSION["pst"]=='Pahang'){ echo "selected"; }?>>Pahang</option>
        <option value='Penang' <?php if(/*!isset($_SESSION["pf"]) &&*/!isset($_SESSION["del"]) && isset($state) &&  $set==1 && $state=='Penang' || /*!isset($_SESSION["pf"]) &&*/ !isset($_SESSION["del"]) && isset($_POST["preturnbtn"]) && $state=='Penang' || !isset($_SESSION["del"]) && /*!isset($_SESSION["pf"]) &&*/ isset($_SESSION["pst"]) && $_SESSION["pst"]=='Penang'){ echo "selected"; }?>>Penang</option>
        <option value='Perak' <?php if(/*!isset($_SESSION["pf"]) &&*/!isset($_SESSION["del"]) && isset($state) &&  $set==1 && $state=='Perak' || /*!isset($_SESSION["pf"]) &&*/ !isset($_SESSION["del"]) && isset($_POST["preturnbtn"]) && $state=='Perak' || !isset($_SESSION["del"]) && /*!isset($_SESSION["pf"]) &&*/ isset($_SESSION["pst"]) && $_SESSION["pst"]=='Perak'){ echo "selected"; }?>>Perak</option>
        <option value='Perlis' <?php if(/*!isset($_SESSION["pf"]) &&*/!isset($_SESSION["del"]) && isset($state) &&  $set==1 && $state=='Perlis' || /*!isset($_SESSION["pf"]) &&*/ !isset($_SESSION["del"]) && isset($_POST["preturnbtn"]) && $state=='Perlis' || !isset($_SESSION["del"]) && /*!isset($_SESSION["pf"]) &&*/ isset($_SESSION["pst"]) && $_SESSION["pst"]=='Perlis'){ echo "selected"; }?>>Perlis</option>
        <option value='Sabah' <?php if(/*!isset($_SESSION["pf"]) &&*/!isset($_SESSION["del"]) && isset($state) &&  $set==1 && $state=='Sabah' || /*!isset($_SESSION["pf"]) &&*/ !isset($_SESSION["del"]) && isset($_POST["preturnbtn"]) && $state=='Sabah' || !isset($_SESSION["del"]) && /*!isset($_SESSION["pf"]) &&*/ isset($_SESSION["pst"]) && $_SESSION["pst"]=='Sabah'){ echo "selected"; }?>>Sabah</option>
        <option value='Sarawak' <?php if(/*!isset($_SESSION["pf"]) &&*/!isset($_SESSION["del"]) && isset($state) &&  $set==1 && $state=='Sarawak' || /*!isset($_SESSION["pf"]) &&*/ !isset($_SESSION["del"]) && isset($_POST["preturnbtn"]) && $state=='Sarawak' || !isset($_SESSION["del"]) && /*!isset($_SESSION["pf"]) &&*/ isset($_SESSION["pst"]) && $_SESSION["pst"]=='Sarawak'){ echo "selected"; }?>>Sarawak</option>
        <option value='Selangor' <?php if(/*!isset($_SESSION["pf"]) &&*/!isset($_SESSION["del"]) && isset($state) &&  $set==1 && $state=='Selangor' || /*!isset($_SESSION["pf"]) &&*/ !isset($_SESSION["del"]) && isset($_POST["preturnbtn"]) && $state=='Selangor' || !isset($_SESSION["del"]) && /*!isset($_SESSION["pf"]) &&*/ isset($_SESSION["pst"]) && $_SESSION["pst"]=='Selangor'){ echo "selected"; }?>>Selangor</option>
        <option value='Terengganu' <?php if(/*!isset($_SESSION["pf"]) &&*/!isset($_SESSION["del"]) && isset($state) &&  $set==1 && $state=='Terengganu' || /*!isset($_SESSION["pf"]) &&*/ !isset($_SESSION["del"]) && isset($_POST["preturnbtn"]) && $state=='Terengganu' || !isset($_SESSION["del"]) && /*!isset($_SESSION["pf"]) &&*/ isset($_SESSION["pst"]) && $_SESSION["pst"]=='Terengganu'){ echo "selected"; }?>>Terengganu</option>
        </select>
		<br><span id="state-error" style="position: relative; top: -30px; margin-bottom: 10px;"></span>
	</div>
	<?php
	/*if(isset($_POST["preturnbtn"]))
	{   if(isset($_POST["payment_method"]))
		{
			$payment_method=$_POST["payment_method"];
	        ?>
	        <input type="text" name="payment_method" value="<?php echo $payment_method; ?>" style="display: none;">
	        <?php
		}
	}
	else if(isset($_SESSION["payment_method"]))
	{
		$payment_method=$_SESSION["payment_method"];
	    ?>
	    <input type="text" name="payment_method" value="<?php echo $payment_method; ?>" style="display: none;">
	    <?php
	}*/
	?>
	<span style="margin-left: 20px;"><a href="#" onclick="getValue(); document.getElementById('dpladdressbtn').click();">Back to Cart</a></span>
	<input type="submit" id="shippingbtn" name="shipping_addressbtn" value="Continue Payment" style="margin-left: 60px;">
    </form>
	<span id="duplicate_addfrm"></span>
	<?php
	}
	?>
    </div>
    </div>
</div>
	<div class="container" style="width:60%; float:right; <?php if(!isset($_POST["select_addressbtn"]) && $track==0 && !isset($_POST["preturnbtn"]) && !isset($_SESSION["ptype"]) || $cartitem_rows>=10) echo 'border-left: 1px dotted grey;'?>">
	<div class="row" style="margin-left:50px;">
         <?php
		 $select_cartsql="SELECT * FROM cart WHERE customer_id=$cust_id";
		 $run_select_cartsql=mysqli_query($connect, $select_cartsql);
		 $num_rows_select_cartsql=mysqli_num_rows($run_select_cartsql);
		 $sqlcust="SELECT * FROM customer WHERE customer_id=$cust_id";
	     $run_sqlcust=mysqli_query($connect, $sqlcust);
	     $rows_sqlcust=mysqli_fetch_assoc($run_sqlcust);
	     $cust_name=$rows_sqlcust["customer_name"];
		 if($num_rows_select_cartsql!=0)
		 {  $rows_select_cartsql=mysqli_fetch_assoc($run_select_cartsql);
		    $cart_id=$rows_select_cartsql["cart_id"];
            $item_sql="SELECT * FROM cart_item WHERE cart_id=$cart_id";
			$run_item_sql=mysqli_query($connect, $item_sql);
			echo "<p style='margin-left: 20px; margin-top: 20px;'>Dear $cust_name, please check your orders before purchase.</p>";
			?>
			<table width="90%" style="border-collapse: collapse;">
            <tr class="thead">
               <th style="text-align: center; font-size: 20px; border-bottom: 1px solid grey;">Product</th>
			   <th style="text-align: center; font-size: 20px; border-bottom: 1px solid grey;">Quantity</th>
			   <th style="text-align: center; font-size: 20px; border-bottom: 1px solid grey;">Price(RM)</th>
               <th style="text-align: center; font-size: 20px; border-bottom: 1px solid grey;">Subtotal(RM)</th>
            </tr>
			<?php $total=0; $overall_total=0;
			while($rows_item_sql=mysqli_fetch_assoc($run_item_sql))
			{
               $product_id=$rows_item_sql["product_id"];
			   $product_qty=$rows_item_sql["item_quantity"];
			   $product_sql="SELECT * FROM product WHERE product_id='$product_id' AND availability=0";
               $run_product_sql=mysqli_query($connect, $product_sql);
			   $num_rows_productsql=mysqli_num_rows($run_product_sql);
			   if($num_rows_productsql==1)
			   {
				$rows_productsql=mysqli_fetch_assoc($run_product_sql);
				$product_name=$rows_productsql["product_name"];
				$price=$rows_productsql["discount_price"];
				$total=$price*$product_qty;
				$overall_total+=$total;
                ?>
				<tr>
					<td style="text-align: center;"><?php echo $product_name;?></td>
					<td style="text-align: center;"><?php echo $product_qty;?></td>
					<td style="text-align: center;"><?php echo number_format($price, 2);?></td>
					<td style="text-align: center;"><?php echo number_format($total, 2);?></td>
			    </tr>
				<?php
			   }
			}?>
			<tr>
				<td></td>
				<td></td>
				<td style="text-align: center; font-size: 18px;">Shipping Fee(RM)</td>
				<td style="text-align: center; font-size: 18px;">Calculated at next step</td>
		    </tr>
			<tr>
				<td></td>
				<td></td>
				<td style="text-align: center; font-size: 20px; font-weight: bold;">Total(RM):</td>
				<td style="text-align: center; font-size: 20px; font-weight: bold;"><?php echo number_format($overall_total, 2);?></td>
		    </tr>
			</table>
			<?php
		 }
		 ?>
	</div>
	</div>
	</div>
	</div>
</section>

<footer id="footer" style="background-color: #f3e7be;">
	<div class="container">
		<div class="row">

			<div class="col-md-4" style="width: 40%;">

				<div class="footer-item">
					<div class="company-brand">
						<img src="images/icon/logo.png" alt="logo" class="footer-logo" style="height: 180px; width: 200px; margin-left: 70px;">
						<p>Welcome to Knowledge Bookstore, your gateway to a vast world of literary treasures, where words come alive and imagination knows no bounds.</p>
					</div>
				</div>

			</div>

			<div class="col-md-2" style="margin-top: 80px;">

				<div class="footer-menu">
					<h5><a href="about_us.php">About Us</a></h5>
					<ul class="menu-list">
						<li class="menu-item">
							Phone: 06 – 252 3253
						</li>
						<!--<li class="menu-item">
							<a href="#">articles </a>
						</li>
						<li class="menu-item">
							<a href="#">careers</a>
						</li>
						<li class="menu-item">
							<a href="#">service terms</a>
						</li>
						<li class="menu-item">
							<a href="#">donate</a>
						</li>-->
					</ul>
				</div>

			</div>
			<!--<div class="col-md-2">

				<div class="footer-menu">
					<h5>Discover</h5>
					<ul class="menu-list">
						<li class="menu-item">
							<a href="#">Home</a>
						</li>
						<li class="menu-item">
							<a href="#">Books</a>
						</li>
						<li class="menu-item">
							<a href="#">Authors</a>
						</li>
						<li class="menu-item">
							<a href="#">Subjects</a>
						</li>
						<li class="menu-item">
							<a href="#">Advanced Search</a>
						</li>
					</ul>
				</div>

			</div>-->
			<div class="col-md-2" style="padding-left: 30px; margin-top: 80px;">

				<div class="footer-menu">
					<h5>Quick Links</h5>
					<ul class="menu-list">
						<li class="menu-item">
							<a href="index.php">Home</a>
						</li>
						<li class="menu-item">
							<a href="shop.php">Shop</a>
						</li>
					</ul>
				</div>

			</div>
			<div class="col-md-2" style="padding-left: 100px; margin-top: 80px;">

				<div class="footer-menu">
					<h5>Services</h5>
					<ul class="menu-list">
						<!--<li class="menu-item">
							<a href="#">Help center</a>
						</li>
						<li class="menu-item">
							<a href="#">Report a problem</a>
						</li>
						<li class="menu-item">
							<a href="#">Suggesting edits</a>
						</li>-->
						<li class="menu-item">
							<a href="contact.php">Contact us</a>
						</li>
						<li class="menu-item">
							<a href="faq.php">FAQ</a>
						</li>
					</ul>
				</div>

			</div>

		</div>
		<!-- / row -->

	</div>
</footer>

<div id="footer-bottom">
	<div class="container">
		<div class="row">
			<div class="col-md-12">

				<div class="copyright">
					<div class="row">

						<div class="col-md-6">
							<p>© 2023 All rights reserved.</p>
						</div>

						<div class="col-md-6">

						</div>

					</div>
				</div><!--grid-->

			</div><!--footer-bottom-content-->
		</div>
	</div>
</div>

<script src="js/jquery-1.11.0.min.js"></script>
<script src="js/plugins.js"></script>
<script src="js/script.js"></script>

</body>
</html>

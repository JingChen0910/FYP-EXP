<!DOCTYPE html>
    <?php include("dataconnection.php");
	session_start();
	if(!isset($_SESSION['id']) || !isset($_SESSION['name']) || !isset($_SESSION['email']) || !isset($_SESSION['vemail'])){
		echo "<script>window.location.href='clogin.php';</script>";
	 }else if(isset($_SESSION['id']) &&  isset($_SESSION['name']) && isset($_SESSION['email']) && isset($_SESSION['vemail'])){
		   $vemail = $_SESSION['vemail'];
		   if($vemail == false){
			  echo "<script>window.location.href='sentOTP.php';</script>";
			  exit();
		   }
		   // else{
		   // 	header("Location:./index.php");
		   // 	exit();
		   // }
	 }
	 if(isset($_SESSION["del"]))
	 {
		unset($_SESSION["del"]);
	 }
    ?>
	<html lang="en">
	<head>
		<title>Book Store</title>
		<meta charset="utf-8">
	    <meta http-equiv="X-UA-Compatible" content="IE=edge">
	    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	    <meta name="format-detection" content="telephone=no">
	    <meta name="apple-mobile-web-app-capable" content="yes">
	    <meta name="author" content="">
	    <meta name="keywords" content="">
	    <meta name="description" content="">

	    <link rel="stylesheet" type="text/css" href="css/normalize.css">
	    <link rel="stylesheet" type="text/css" href="icomoon/icomoon.css">
	    <link rel="stylesheet" type="text/css" href="css/vendor.css">
	    <link rel="stylesheet" type="text/css" href="style.css">
		<!-- script
		================================================== -->
		<script src="http://translate.google.com/translate_a/element.js?cb=loadGoogleTranslate"></script>
		<script src="js/modernizr.js">
			function handle_keyup(event){
				if (event.keyCode === 13) {
                   document.getElementById('search_btn').click();
                }
			}
		</script>
		<script type="text/javascript">
			function validate_card(dt)
			{   var shipping_rate=document.getElementById("shipping_rate").value;
				if(shipping_rate==0)
				{
					alert("Please choose your shipping address first...");  window.location.href="checkout.php"; return false;
				}
				if(dt==1)
				{
                  alert("Please register your address first...");  window.location.href="checkout.php"; return false;
				}
               var card_type=document.getElementById("card_type").value, card_num=document.getElementById("cnum").value, card_cvv=document.getElementById("cvv").value;
			   var visa_cardno = /^(?:4[0-9]{15})$/, master_cardno = /^(?:5[1-5][0-9]{14})$/, cvv_format = /^\d{3}$/, nameRegex = /^(?=[a-zA-Z])[a-zA-Z0-9 ._-]{3,60}$/, card_holder=document.getElementById("cn").value, card_date=document.getElementById("cdate").value, counter=0;
			   let cvvinput=card_cvv.replace(/\s+/g, '');
               let cvvlength=cvvinput.length;
			   let cardholder_input=card_holder.replace(/\s+/g, '');
			   let cardholder_length=cardholder_input.length;
			   let card_num_input=card_num.replace(/\s+/g, '');
			   if(card_type=="")
			   {
				document.getElementById("alerttypc").innerHTML=" [This field is required]";
				counter++;
				if(card_num_input=="")
			   {
				document.getElementById("alertcnum").innerHTML=" [This field is required]";
				counter++;
			   }
			   else
			   {
				document.getElementById("alertcnum").innerHTML="";
			   }
			   }
			   else if(card_type=="visa-card")
			   {  document.getElementById("alerttypc").innerHTML="";
                  if(!card_num.match(visa_cardno) || card_num_input.length!=16)
				  {
                    document.getElementById("alertcnum").innerHTML=" [Invalid Visa Card Number]";
					counter++;
				  }
				  else
				  {
					document.getElementById("alertcnum").innerHTML="";
				  }
			   }
			   else if(card_type=="master-card")
			   {  document.getElementById("alerttypc").innerHTML="";
				  if(!card_num.match(master_cardno) || card_num_input.length!=16)
				  {
                    document.getElementById("alertcnum").innerHTML=" [Invalid Mastercard Number]";
					counter++;
				  }
				  else
				  {
					document.getElementById("alertcnum").innerHTML="";
				  }
			   }
			   if(card_holder=="" || cardholder_length==0)
			   {
				document.getElementById("alertholdname").innerHTML=" [This field is required]";
				counter++;
			   }
			   else
			   {
				document.getElementById("alertholdname").innerHTML="";
				if(!card_holder.match(nameRegex))
			   {
				    document.getElementById("alertholdname").innerHTML=" [Invalid Card Holder Name]";
					counter++;
			   }
			   else
			   {
				   document.getElementById("alertholdname").innerHTML="";
			   }
			   }
			   if(card_date=="")
			   {
				document.getElementById("alertcarddate").innerHTML=" [This field is required]";
				counter++;
			   }
			   else
			   {
				document.getElementById("alertcarddate").innerHTML="";
			   }
			   if(card_cvv=="")
			   {
				document.getElementById("alertcvv").innerHTML=" [This field is required]";
				counter++;
			   }
			   else
			   {
				document.getElementById("alertcvv").innerHTML="";
				if(cvvlength!=3 || !card_cvv.match(cvv_format))
			   {
				    document.getElementById("alertcvv").innerHTML=" [Invalid CVV]";
					counter++;
			   }
			   else
			   {
				   document.getElementById("alertcvv").innerHTML="";
			   }
			   }
			   if(counter!=0){
				 return false;
			   }
			}
			function getValue(count)
			{   var address_frm=document.forms["addressfrm"];
				if(count==0)
				{
					address_frm.action="checkout.php";
				}
				else if(count==1)
				{
					address_frm.action="cart.php";
				}
				var pay_form = document.forms["selectpayfrm"];
				//var pay_type=pay_form.elements["payment_method"].value;
				/*if(pay_type=="Credit/Debit Card")
				{*/
                   var main_form = document.forms["paymentfrm"];
				   var cardtype = main_form.elements["card_type"].value;
				   var holder_name = main_form.elements["cn"].value;
				   var card_num = main_form.elements["cnum"].value;
				   var cvv = main_form.elements["cvv"].value;
				   var card_date = main_form.elements["cdate"].value;
				   document.getElementById("payment_element").innerHTML="<input type='text' name='cardtype' id='cardtype'><input type='text' name='holder_name' id='holder_name'><input type='text' name='cardnum' id='cardnum'><input type='text' name='cardvv' id='cardvv'><input type='text' name='carddate' id='carddate'>";
				   document.getElementById('cardtype').value=cardtype; document.getElementById('holder_name').value=holder_name; document.getElementById('cardnum').value=card_num; document.getElementById('cardvv').value=cvv; document.getElementById('carddate').value=card_date;
				   document.getElementById('cardtype').style.display="none"; document.getElementById('holder_name').style.display="none"; document.getElementById('cardnum').style.display="none"; document.getElementById('cardvv').style.display="none"; document.getElementById('carddate').style.display="none";
				/*}*/
				/*else if(pay_type=="E-Wallet")
				{
					var main_form = document.forms["ewallet_frm"];
					var ewallet_types = main_form.elements["e-wallet_types"].value;
				    var transaction_no = main_form.elements["transaction_no"].value;
					document.getElementById("payment_element").innerHTML="<input type='text' name='ewallet_types' id='ewallet_types'><input type='text' name='transaction_no' id='transaction_no'>";
					document.getElementById('ewallet_types').value=ewallet_types; document.getElementById('transaction_no').value=transaction_no;
					document.getElementById('ewallet_types').style.display="none"; document.getElementById('transaction_no').style.display="none";
				}*/
			}
			function loadGoogleTranslate() {
    const defaultLanguage = "en";

    const translateElement = new google.translate.TranslateElement({
      pageLanguage: defaultLanguage,
      includedLanguages: "en,ms,zh-CN",
      layout: google.translate.TranslateElement.InlineLayout.SIMPLE
    }, "google_element");

    // Get the language select dropdown element
    const languageSelect = document.getElementById("languageSelect");

    // Function to set a cookie
    function setCookie(name, value, days) {
      const expires = new Date();
      expires.setTime(expires.getTime() + days * 24 * 60 * 60 * 1000);
      document.cookie = `${name}=${value};expires=${expires.toUTCString()};path=/`;
    }

    // Function to get a cookie value
    function getCookie(name) {
      const cookieName = `${name}=`;
      const cookies = document.cookie.split(';');
      for (let i = 0; i < cookies.length; i++) {
        let cookie = cookies[i];
        while (cookie.charAt(0) === ' ') {
          cookie = cookie.substring(1);
        }
        if (cookie.indexOf(cookieName) === 0) {
          return cookie.substring(cookieName.length, cookie.length);
        }
      }
      return null;
    }

    // Set the initial language selection
    const storedLanguage = getCookie("selectedLanguage");
    if (storedLanguage) {
      languageSelect.value = storedLanguage;
      translateElement.update({
        includedLanguages: storedLanguage
      });
    }

    // Add event listener for change event
    languageSelect.addEventListener("change", function() {
      const selectedLanguage = this.value;
      translateElement.update({
        includedLanguages: selectedLanguage
      });
      setCookie("selectedLanguage", selectedLanguage, 30); // Set the cookie for 30 days
    });
  }
		</script>
	</head>

<body>


<div id="header-wrap">

	<div class="top-content">
		<div class="container">
			<div class="row">
				<div class="col-md-6" style="width: 25%;">

				</div>
				<div class="col-md-6" style="width: 75%;">
					<div class="right-element">
						<?php
						if(isset($_SESSION["id"]))
						{   $cust_id=$_SESSION["id"];
							$cartsql="SELECT * FROM cart WHERE customer_id=$cust_id";
							$run_cartsql=mysqli_query($connect, $cartsql);
							$num_rows_cartsql=mysqli_num_rows($run_cartsql);
							$rows_cartsql=mysqli_fetch_assoc($run_cartsql);
							if($num_rows_cartsql==0)
							{
								$cartitem_rows=0;
							}
							else
							{   $cartid=$rows_cartsql["cart_id"];
								$cartitemsql="SELECT * FROM cart_item WHERE cart_id=$cartid";
							    $run_cartitemsql=mysqli_query($connect, $cartitemsql);
							    $cartitem_rows=mysqli_num_rows($run_cartitemsql);
								$del_val=0;
								while($rows_cartitemsql=mysqli_fetch_assoc($run_cartitemsql))
								{
                                  $prodid=$rows_cartitemsql["product_id"];
								  $itemqty=$rows_cartitemsql["item_quantity"];
								  $stocksql="SELECT * FROM stock WHERE product_id='$prodid'";
                                  $run_stocksql=mysqli_query($connect, $stocksql);
                                  $stockrows=mysqli_fetch_assoc($run_stocksql);
                                  $stocklevel=$stockrows['stock_level'];
								  $prodsql="SELECT * FROM product WHERE product_id='$prodid' AND availability=0";
                                  $run_prodsql=mysqli_query($connect, $prodsql);
                                  $prodrows=mysqli_num_rows($run_prodsql);
								  if($prodrows==0)
								  {
									$del_cartitem="DELETE FROM cart_item WHERE cart_id=$cartid AND product_id='$prodid'";
									$run_del_cartitem=mysqli_query($connect, $del_cartitem);
									if($run_del_cartitem)
                                      $del_val++;
								  }
								  else if($stocklevel==0)
								  {
									$del_cartitem="DELETE FROM cart_item WHERE cart_id=$cartid AND product_id='$prodid'";
									$run_del_cartitem=mysqli_query($connect, $del_cartitem);
									if($run_del_cartitem)
                                      $del_val++;
								  }
								  else if($itemqty>$stocklevel)
								  {
									$update_cartitem="UPDATE cart_item SET item_quantity=$stocklevel WHERE cart_id=$cartid AND product_id='$prodid'";
									$run_update_cartitem=mysqli_query($connect, $update_cartitem);
								  }
								}
								if($del_val==$cartitem_rows)
								{
									$del_cart="DELETE FROM cart WHERE cart_id=$cartid";
									$run_del_cart=mysqli_query($connect, $del_cart);
								}
								$cartitem_rows-=$del_val;
							}
							$select_cust="SELECT * FROM customer WHERE customer_id=$cust_id";
							$run_select_cust=mysqli_query($connect, $select_cust);
							$row_select_cust=mysqli_fetch_assoc($run_select_cust);
							$user_profile=$row_select_cust["customer_profile_picture"];
							?>
							<a href="#" onclick="getValue(1); document.getElementById('pbackbtn').click();" class="cart for-buy"><img src="images/icon/carts.png" style="width: 50px; height: 50px; opacity: 70%; margin-bottom: 5px;"><span>Cart: <?php echo $cartitem_rows; ?> item(s)</span></a>
						    <a href="order_history.php" class="cart for-buy"><i class="icon icon-clipboard"></i> <span>Order History</span></a>
						<nav id="navbar" style="display: inline-block; margin-left: -40px; position: relative; z-index: 3;">
						<div class="main-menu stellarnav">
						<ul class="menu-list">
						<li class="menu-item has-sub">
						<a href="./user_profile.php" class="nav-link" data-effect="Pages"><img src="images/cus_profile/<?php echo $user_profile; ?>" style="width: 40px; height: 40px; border-radius: 50%; margin-right: 10px;" alt="user_profile" title="user_profile">Account</a>
							<ul style="font-size: 16px;">
								<li><a href="./user_profile.php">My Profile</a></li>
								<li><a href="./logoutaction.php">Logout</a></li>
							 </ul>
						</li>
						</ul>
						</div>
						</nav>
                        <?php
						}
						?>
						<div class="action-menu" style="margin-left: 10px;">

                          <div class="search-bar">
	                      <a href="#" class="search-button search-toggle" data-selector="#header-wrap">
		                     <i class="icon icon-search"></i>
	                      </a>
	                      <form role="search" method="get" class="search-box" action="search_products.php">
		                  <input class="search-field text search-input" placeholder="Search products" type="text" name="search_keyword" onkeyup="handle_keyup(event)">
		                  <input type="submit" id="search_btn" style="display: none;">
	                      </form>
                          </div>
                        </div>
                        <div id="google_element" style="display: inline-block;"></div>
					</div><!--top-right-->
				</div>

			</div>
		</div>
	</div><!--top-content-->

	<header id="header" style="background-color: #f3e7be;">
		<div class="container">
			<div class="row">

			    <div class="col-md-2">
					<!--<div class="main-logo">-->
						<a href="index.php"><img src="images/icon/logo.png" alt="logo" style="height: 140px; margin:-60px 0px -30px 0px;"></a>
					<!--</div>-->
				</div>

				<div class="col-md-10">

					<nav id="navbar" style="position: relative; z-index: 1;">
						<div class="main-menu stellarnav">
							<ul class="menu-list">
								<li class="menu-item active"><a href="index.php" data-effect="Home">Home</a></li>
								<li class="menu-item"><a href="about_us.php" class="nav-link" data-effect="About">About</a></li>
								<!--<li class="menu-item has-sub">
									<a href="#pages" class="nav-link" data-effect="Pages">Pages</a>

									<ul>
								        <li><a href="styles.html">Styles</a></li>
								        <li><a href="blog.html">Blog</a></li>
								        <li><a href="single-post.html">Post Single</a></li>
								        <li><a href="thank-you.html">Thank You</a></li>
								     </ul>

								</li>-->
								<li class="menu-item"><a href="shop.php" class="nav-link" data-effect="Shop">Shop</a></li>
								<li class="menu-item"><a href="contact.php" class="nav-link" data-effect="Contact">Contact Us</a></li>
							</ul>

							<div class="hamburger">
				                <span class="bar"></span>
				                <span class="bar"></span>
				                <span class="bar"></span>
				            </div>

						</div>
					</nav>

				</div>

			</div>
		</div>
	</header>

</div><!--header-wrap-->

<div>
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div class="colored">
				<?php
				$shipping_rate=0;
				$shipping_fee=0;
				$ototal=0;
				if(isset($_POST["shipping_addressbtn"]) /*|| isset($_POST["select_paybtn"])*/)
	            {
					if(isset($_POST["select_address"]) /*|| isset($_POST["select_paybtn"])*/)
					{   if(isset($_POST["select_address"]))
						{
							$select_address=$_POST["select_address"];
						}
						else
						{
							$select_address=$_POST["pselect"];
						}
						if($select_address=="r2")
						{  $rname=$_POST["recipient_name"];
						   $remail=$_POST["recipient_email"];
						   $rhp=$_POST["recipient_hp"];
						   $address1=$_POST["address1"];
	                       $address2=$_POST["address2"];
	                       $city=$_POST["city"];
	                       $postcode=$_POST["postcode"];
	                       $state=$_POST["state"];
						   if($state!="Sabah" && $state!="Sarawak")
				           {   $shipping_rate=0.06;
				           }
				           else if($state=="Sabah" || $state=="Sarawak")
				           {   $shipping_rate=0.09;
				           }
						}
						else
						{
							$custaddress_sql="SELECT state FROM address WHERE customer_id=$cust_id";
	                        $run_custaddress_sql=mysqli_query($connect, $custaddress_sql);
	                        $num_rows_custaddress=mysqli_num_rows($run_custaddress_sql);
				            if($num_rows_custaddress==1)
				            {
					            $rows_custaddress=mysqli_fetch_assoc($run_custaddress_sql);
			                    $state=$rows_custaddress["state"];
			                    if($state!="Sabah" && $state!="Sarawak")
				                {   $shipping_rate=0.06;
				                }
				                else if($state=="Sabah" || $state=="Sarawak")
				                {   $shipping_rate=0.09;
				                }
				            }
						}
					}
					else
					{
						$address1=$_POST["address1"];
	                    $address2=$_POST["address2"];
	                    $city=$_POST["city"];
	                    $postcode=$_POST["postcode"];
	                    $state=$_POST["state"];
						$select_address="r1";
						$_SESSION["select_address"]="r1";
						if($state!="Sabah" && $state!="Sarawak")
				        {   $shipping_rate=0.06;
				        }
				        else if($state=="Sabah" || $state=="Sarawak")
				        {   $shipping_rate=0.09;
				        }
						$update_address="INSERT INTO address(customer_id, address1, address2, state, city, postalCode) VALUES($cust_id, '$address1', '$address2', '$state', '$city', '$postcode')";
						$run_update_address=mysqli_query($connect, $update_address);
						if($run_update_address)
						{
							echo "<script>alert('Address saved')</script>";
						}
					}
				  ?>
				  <form id="addressfrm" method="POST">
					<?php
				  if(isset($_POST["select_address"]) /*|| isset($_POST["select_paybtn"])*/)
				  {
				  /*if(isset($_POST["select_paybtn"]))
	               {  $_SESSION["payment_method"]=$payment_method=$_POST["payment_method"];
					  if($_SESSION["payment_method"]=="E-Wallet")
					  {
						if(isset($_SESSION["cardtype"]) && isset($_SESSION["holder_name"]) && isset($_SESSION["cardnum"]) && isset($_SESSION["cardvv"]) && isset($_SESSION["carddate"]))
						{
							$_SESSION["cardtype"]="";
				            $_SESSION["holder_name"]="";
				            $_SESSION["cardnum"]="";
				            $_SESSION["cardvv"]="";
				            $_SESSION["carddate"]="";
						}
					  }
					  if($_SESSION["payment_method"]=="Credit/Debit Card")
					  {
                         if(isset($_SESSION["ewallet_types"]) && isset($_SESSION["transaction_no"]))
						 {
							$_SESSION["ewallet_types"]="";
							$_SESSION["transaction_no"]="";
						 }
					  }
					  if($_SESSION["payment_method"]=="0")
					  {
						if(isset($_SESSION["cardtype"]) && isset($_SESSION["holder_name"]) && isset($_SESSION["cardnum"]) && isset($_SESSION["cardvv"]) && isset($_SESSION["carddate"]))
						{
							$_SESSION["cardtype"]="";
				            $_SESSION["holder_name"]="";
				            $_SESSION["cardnum"]="";
				            $_SESSION["cardvv"]="";
				            $_SESSION["carddate"]="";
						}
						if(isset($_SESSION["ewallet_types"]) && isset($_SESSION["transaction_no"]))
						 {
							$_SESSION["ewallet_types"]="";
							$_SESSION["transaction_no"]="";
						 }
					  }
	                ?>
	                  <input type="text" name="payment_method" value="<?php echo $payment_method; ?>" style="display: none;">
	                <?php
	                }
					else if(isset($_SESSION["payment_method"]))
					{   $payment_method=$_SESSION["payment_method"];
						?>
						  <input type="text" name="payment_method" value="<?php echo $payment_method; ?>" style="display: none;">
						<?php
					}
					?>*/?>
				  <input type="text" name="pselect" value="<?php echo $select_address; ?>" style="display: none;">
				  <?php
				     if($select_address=="r2")
					 {?>
					 <input type="text" name="rname" value="<?php echo $rname; ?>" style="display: none;">
					<input type="text" name="remail" value="<?php echo $remail; ?>" style="display: none;">
					<input type="text" name="rhp" value="<?php echo $rhp; ?>" style="display: none;">
					 <input type="text" name="paddress1" value="<?php echo $address1; ?>" style="display: none;">
					<input type="text" name="paddress2" value="<?php echo $address2; ?>" style="display: none;">
					<input type="text" name="pcity" value="<?php echo $city; ?>" style="display: none;">
					<input type="text" name="ppostcode" value="<?php echo $postcode; ?>" style="display: none;">
					<input type="text" name="pstate" value="<?php echo $state; ?>" style="display: none;">
                     <?php
					 }
				  }
				  else
				  {
					?>
					<input type="text" name="paddress1" value="<?php echo $address1; ?>" style="display: none;">
					<input type="text" name="paddress2" value="<?php echo $address2; ?>" style="display: none;">
					<input type="text" name="pcity" value="<?php echo $city; ?>" style="display: none;">
					<input type="text" name="ppostcode" value="<?php echo $postcode; ?>" style="display: none;">
					<input type="text" name="pstate" value="<?php echo $state; ?>" style="display: none;">
				  <?php
	              }?>
				  <span id="payment_element"></span>
				 <input type="submit" id="pbackbtn" name="preturnbtn" style="display: none;">
				 </form>
				 <?php
				}?>
					<br>
					<div class="breadcum-items">
						<span class="item"><a href="#" onclick="getValue(1); document.getElementById('pbackbtn').click();">Cart </a> > </span>
						<span class="item colored"><a href="#" onclick="getValue(0); document.getElementById('pbackbtn').click();">Shipping</a></span> >
						<span class="item colored" style="font-weight: bold;">Payment</span>
					</div>
				</div>
			</div>
		</div>
	</div>
</div><!--site-banner-->

<section class="padding-large">
<div class="container"style="margin: auto; background-color: white;">
<div style="height: 40px; background-color: #f1daa0; width: 103%; font-weight: bold; font-size: 20px; margin-left: -20px;"><span style="margin-left: 20px; color: #866e37;">Step 2 of 2: Payment</span></div>
<div class="wrap-all-pay" style="width:100%;  height: 700px;">
<div class="container" style="width:40%; float:left;  <?php if(/*isset($_POST["select_paybtn"]) && $_POST["payment_method"]!="0" || isset($_SESSION["payment_method"]) && $_SESSION["payment_method"]!="0" && */$cartitem_rows<10) echo 'border-right: 1px dotted grey;'?>">
    <div class="wrap-pay-elements" style="margin-left: 30px;">
    <div class="pay-body">
	<?php $set=0; ?>
	<h3>Payment</h3>
	<?php/*
	if(isset($_POST["shipping_addressbtn"]))
	{ if(isset($_POST["payment_method"]))
		{
			$select_pay=$_POST["payment_method"];
		}
	}
	else if(isset($_POST["select_paybtn"]))
	{
		$select_pay=$_POST["payment_method"];
	}*/
	?>
	<form name="selectpayfrm" id="selectpay_form" method="POST">
    <p style="position: relative; left:40px;">
        <!--<select id="payment_method" name="payment_method" onchange="document.getElementById('paybtn').click()">
            <option value="0">Select payment method</option>
            <option value="Credit/Debit Card" </*?php if(isset($_POST["shipping_addressbtn"]) && isset($_POST["payment_method"]) && $select_pay=="Credit/Debit Card" || isset($_POST["select_paybtn"]) && $select_pay=="Credit/Debit Card") echo "selected";*/ ?>>Credit Card/Debit Card</option>
            <option value="E-Wallet" </*?php if(isset($_POST["shipping_addressbtn"]) && isset($_POST["payment_method"]) && $select_pay=="E-Wallet" || isset($_POST["select_paybtn"]) && $select_pay=="E-Wallet") echo "selected";*/ ?>>E-Wallet</option>
        </select>-->
		<?php
				  if(isset($_POST["select_address"]))
				  {$select_address=$_POST["select_address"];?><input type="text" name="pselect" value="<?php echo $select_address; ?>" style="display: none;">
				  <?php $_SESSION["select_address"]=$select_address;
				     if($select_address=="r2")
					 {?>
					 <input type="text" name="rname" value="<?php echo $rname; ?>" style="display: none;">
					<input type="text" name="remail" value="<?php echo $remail; ?>" style="display: none;">
					<input type="text" name="rhp" value="<?php echo $rhp; ?>" style="display: none;">
					 <input type="text" name="paddress1" value="<?php echo $address1; ?>" style="display: none;">
					<input type="text" name="paddress2" value="<?php echo $address2; ?>" style="display: none;">
					<input type="text" name="pcity" value="<?php echo $city; ?>" style="display: none;">
					<input type="text" name="ppostcode" value="<?php echo $postcode; ?>" style="display: none;">
					<input type="text" name="pstate" value="<?php echo $state; ?>" style="display: none;">
                     <?php
					 $_SESSION["rname"]=$rname;
					 $_SESSION["remail"]=$remail;
					 $_SESSION["rhp"]=$rhp;
					 $_SESSION["address1"]=$address1;
					 $_SESSION["address2"]=$address2;
					 $_SESSION["city"]=$city;
					 $_SESSION["postcode"]=$postcode;
					 $_SESSION["state"]=$state;
					 }
				  }
				  else {
					if(isset($_SESSION["select_address"]))
					{
						$select_address=$_SESSION["select_address"];
					    ?><input type="text" name="pselect" value="<?php echo $select_address; ?>" style="display: none;">
					    <?php
						if($select_address=="r2")
						{ $rname=$_SESSION["rname"];
						  $remail=$_SESSION["remail"];
						  $rhp=$_SESSION["rhp"];
						  $address1=$_SESSION["address1"];
						  $address2=$_SESSION["address2"];
						  $city=$_SESSION["city"];
						  $postcode=$_SESSION["postcode"];
						  $pstate=$_SESSION["state"];
						 ?>
						 <input type="text" name="rname" value="<?php echo $rname; ?>" style="display: none;">
					     <input type="text" name="remail" value="<?php echo $remail; ?>" style="display: none;">
					     <input type="text" name="rhp" value="<?php echo $rhp; ?>" style="display: none;">
						 <input type="text" name="paddress1" value="<?php echo $address1; ?>" style="display: none;">
					     <input type="text" name="paddress2" value="<?php echo $address2; ?>" style="display: none;">
					     <input type="text" name="pcity" value="<?php echo $city; ?>" style="display: none;">
					     <input type="text" name="ppostcode" value="<?php echo $postcode; ?>" style="display: none;">
					     <input type="text" name="pstate" value="<?php echo $state; ?>" style="display: none;">
						<?php
					    }
					   }
	              }?>
				  <input type="submit" id="paybtn" name="select_paybtn" style="display: none;">
		          <?php/*
		          if(!isset($_POST["select_paybtn"]) && !isset($_SESSION["payment_method"]))
		          {   ?><!--<br><span><a href='#' onclick="getValue(0); document.getElementById('pbackbtn').click();">Back to Shipping</a></span>-->
			          <?php
				   /*}
		          /*else if(isset($_POST["select_paybtn"]) && $_POST["payment_method"]=="0" || isset($_SESSION["payment_method"]) && $_SESSION["payment_method"]=="0")
		          {   ?><br><span><a href='#' onclick="getValue(0); document.getElementById('pbackbtn').click();">Back to Shipping</a></span>
			          <?php
		          }*/
		          ?>
				  <!--<a href='#' onclick="getValue(0); document.getElementById('pbackbtn').click();">Back to Shipping</a></span>-->
              </p>
        </form>
		<?php
				  /*if(isset($_POST["select_paybtn"]) || isset($_SESSION["payment_method"]))
	              {  if(isset($_SESSION["payment_method"]))
					 {
						$select_pay=$_SESSION["payment_method"];
					 }
					 if($select_pay=="Credit/Debit Card")
					 {*/  date_default_timezone_set('Asia/Kuala_Lumpur');
						$mindate=date('Y-m');
						$maxdate = date('Y-m', strtotime('+8 year'));
						$dt=0;
						$custaddress_sql="SELECT * FROM address WHERE customer_id=$cust_id";
	                    $run_custaddress_sql=mysqli_query($connect, $custaddress_sql);
	                    $num_rows_custaddress=mysqli_num_rows($run_custaddress_sql);
	                    if($num_rows_custaddress==0)
	                    {$dt++; }?>
						<form id="paymentfrm" name="paymentfrm" method="POST" action="insert_orders.php" onsubmit="return validate_card('<?php echo $dt; ?>')">
					    <div>Accepted Cards: <br><img src="images/icon/visa_card.png" style="width: 70px; height: 50px; margin-right: 20px;"><img src="images/icon/master_card.png" style="width: 70px; height: 50px;"></div><br>
						<div>Cards<span style="color: red;">*</span> <span id="alerttypc" style="color: red; font-size: 15px;"></span><br>
						<input type="text" id="shipping_rate" value="<?php echo $shipping_rate; ?>" style="display: none;">
						<select  id="card_type" name="card_type" >
						    <option value="">Select the types of card</option>
							<option value="visa-card" <?php if(isset($_SESSION["cardtype"]) && $_SESSION["cardtype"]=="visa-card") echo "selected"; ?>>Visa Card</option>
							<option value="master-card" <?php if(isset($_SESSION["cardtype"]) && $_SESSION["cardtype"]=="master-card") echo "selected"; ?>>Mastercard</option>
					    </select>
					    </div>
						<div>Card Holder Name<span style="color: red;">*</span> <span id="alertholdname" style="color: red; font-size: 15px;"></span><br><input type="text"  id="cn" name="cname" style="width: 400px;" <?php if(isset($_SESSION["holder_name"])){ $holdername=$_SESSION['holder_name']; echo "value='$holdername'";} ?>></div>
                        <div>Card Number<span style="color: red;">*</span> (Without spacing or '-')<span id="alertcnum" style="color: red; font-size: 15px;"></span><br><input type="text"  id="cnum" name="ccnum" placeholder="xxxx xxxx xxxx xxxx" maxlength="16" style="width: 300px;" <?php if(isset($_SESSION["cardnum"])){$cardn=$_SESSION['cardnum']; echo "value='$cardn'";} ?>></div>
                        <div>CVV<span style="color: red;">*</span> <span id="alertcvv" style="color: red; font-size: 15px;"></span><br><input type="text"  id="cvv" name="ccvv" placeholder="xxx" maxlength="3" <?php if(isset($_SESSION["cardvv"])){$cardVV=$_SESSION['cardvv']; echo "value='$cardVV'";} ?>></div>
                        <div>Card Expiry Date<span style="color: red;">*</span> <span id="alertcarddate" style="color: red; font-size: 15px;"></span><br><input type="month"  id="cdate" name="cexdate" min="<?php echo $mindate; ?>" max="<?php echo $maxdate; ?>" <?php if(isset($_SESSION["carddate"])){ $carddt=$_SESSION['carddate']; echo "value='$carddt'";} ?>></div>
					    <br><span><a href="#" onclick="getValue(0); document.getElementById('pbackbtn').click();">Back to Shipping</a></span>
					    <input type="submit" id="purchasebtn" name="confirm_paybtn" value="Confirm Payment" style="margin-left: 70px;">
					    </form>
					 <?php
					 /*}
					 else if($select_pay=="E-Wallet")
					 {?>
					 <form id="ewallet_frm" name="ewallet_frm" method="POST" action="insert_orders.php">
					 <div style="position: relative; left:40px;">
					 <select id="e-wallet_types" name="e-wallet_types" required>
                        <option value="">Choose E-Wallet</option>
                        <option value="Touch n Go" <?php if(isset($_SESSION["ewallet_types"]) && $_SESSION["ewallet_types"]=="Touch n Go") echo "selected"; ?>>Touch n Go</option>
                        <option value="Boost" <?php if(isset($_SESSION["ewallet_types"]) && $_SESSION["ewallet_types"]=="Boost") echo "selected"; ?>>Boost</option>
						<option value="GrabPay" <?php if(isset($_SESSION["ewallet_types"]) && $_SESSION["ewallet_types"]=="GrabPay") echo "selected"; ?>>GrabPay</option>
                     </select>
					 </div>
                     <div style="position: relative; left:40px;">Transaction No<span style="color: red;">*</span><br><input type="text" id="transaction_no" name="transaction_no" minlength="8" maxlength="30" style="width: 300px;" required  <?php if(isset($_SESSION["transaction_no"])){ $transaction_num=$_SESSION["transaction_no"]; echo "value='$transaction_num'"; } ?>></div>
					 <br><span style="margin-left: 30px;"><a href="#" onclick="getValue(0); document.getElementById('pbackbtn').click();">Back to Shipping</a></span>
					 <input type="submit" id="purchasebtn" name="confirm_paybtn" value="Confirm Payment" style="margin-left: 70px;">
					 </form>
					  <?php
					 }
	                 ?>
	                 <?php
	              }*/
		?>
    </div>
    </div>
</div>
	<div class="container" style="width:60%; float:right; <?php if(/*!isset($_POST["select_paybtn"]) && !isset($_SESSION["payment_method"])  || */$cartitem_rows>=10) echo 'border-left: 1px dotted grey;'; /*else if(isset($_SESSION["payment_method"]) && $_SESSION["payment_method"]=="0" || $cartitem_rows>=10) echo 'border-left: 1px dotted grey;'; */?>">
	<div class="row" style="margin-left:50px;">
         <?php
		 $select_cartsql="SELECT * FROM cart WHERE customer_id=$cust_id";
		 $run_select_cartsql=mysqli_query($connect, $select_cartsql);
		 $num_rows_select_cartsql=mysqli_num_rows($run_select_cartsql);
		 $sqlcust="SELECT * FROM customer WHERE customer_id=$cust_id";
	     $run_sqlcust=mysqli_query($connect, $sqlcust);
	     $rows_sqlcust=mysqli_fetch_assoc($run_sqlcust);
	     $cust_name=$rows_sqlcust["customer_name"];
		 if($num_rows_select_cartsql!=0)
		 {  $rows_select_cartsql=mysqli_fetch_assoc($run_select_cartsql);
		    $cart_id=$rows_select_cartsql["cart_id"];
            $item_sql="SELECT * FROM cart_item WHERE cart_id=$cart_id";
			$run_item_sql=mysqli_query($connect, $item_sql);
			echo "<p style='margin-left: 20px; margin-top: 20px;'>Dear $cust_name, please check your orders before purchase.</p>";
			?>
			<table width="80%" style="border-collapse: collapse;">
            <tr class="thead">
               <th style="text-align: center; font-size: 20px; border-bottom: 1px solid grey;">Product</th>
			   <th style="text-align: center; font-size: 20px; border-bottom: 1px solid grey;">Quantity</th>
			   <th style="text-align: center; font-size: 20px; border-bottom: 1px solid grey;">Price(RM)</th>
               <th style="text-align: center; font-size: 20px; border-bottom: 1px solid grey;">Subtotal(RM)</th>
            </tr>
			<?php $total=0; $overall_total=0;
			while($rows_item_sql=mysqli_fetch_assoc($run_item_sql))
			{
               $product_id=$rows_item_sql["product_id"];
			   $product_qty=$rows_item_sql["item_quantity"];
			   $product_sql="SELECT * FROM product WHERE product_id='$product_id' AND availability=0";
               $run_product_sql=mysqli_query($connect, $product_sql);
			   $num_rows_productsql=mysqli_num_rows($run_product_sql);
			   if($num_rows_productsql==1)
			   {
				$rows_productsql=mysqli_fetch_assoc($run_product_sql);
				$product_name=$rows_productsql["product_name"];
				$price=$rows_productsql["discount_price"];
				$total=$price*$product_qty;
				$overall_total+=$total;
                ?>
				<tr>
					<td style="text-align: center;"><?php echo $product_name;?></td>
					<td style="text-align: center;"><?php echo $product_qty;?></td>
					<td style="text-align: center;"><?php echo number_format($price, 2);?></td>
					<td style="text-align: center;"><?php echo number_format($total, 2);?></td>
			    </tr>
				<?php
			   }
			}
			$shipping_fee=$overall_total*$shipping_rate;
			$ototal=$overall_total+$shipping_fee;
			?>
			<tr>
				<td></td>
				<td></td>
				<td style="text-align: center; font-size: 18px;">Shipping Fee(RM)</td>
				<td style="text-align: center; font-size: 18px;"><?php echo number_format($shipping_fee, 2); echo " (",$shipping_rate*100,"%)";?></td>
		    </tr>
			<tr>
				<td></td>
				<td></td>
				<td style="text-align: center; font-size: 20px; font-weight: bold;">Total(RM):</td>
				<td style="text-align: center; font-size: 20px; font-weight: bold;"><?php echo number_format($ototal, 2);?></td>
		    </tr>
			</table>
			<?php
		 }
		 ?>
	</div>
	</div>
	</div>
	</div>
</section>

<footer id="footer" style="background-color: #f3e7be;">
	<div class="container">
		<div class="row">

			<div class="col-md-4" style="width: 40%;">

				<div class="footer-item">
					<div class="company-brand">
						<img src="images/icon/logo.png" alt="logo" class="footer-logo" style="height: 180px; width: 200px; margin-left: 70px;">
						<p>Welcome to Knowledge Bookstore, your gateway to a vast world of literary treasures, where words come alive and imagination knows no bounds.</p>
					</div>
				</div>

			</div>

			<div class="col-md-2" style="margin-top: 80px;">

				<div class="footer-menu">
					<h5><a href="about_us.php">About Us</a></h5>
					<ul class="menu-list">
						<li class="menu-item">
							Phone: 06 – 252 3253
						</li>
						<!--<li class="menu-item">
							<a href="#">articles </a>
						</li>
						<li class="menu-item">
							<a href="#">careers</a>
						</li>
						<li class="menu-item">
							<a href="#">service terms</a>
						</li>
						<li class="menu-item">
							<a href="#">donate</a>
						</li>-->
					</ul>
				</div>

			</div>
			<!--<div class="col-md-2">

				<div class="footer-menu">
					<h5>Discover</h5>
					<ul class="menu-list">
						<li class="menu-item">
							<a href="#">Home</a>
						</li>
						<li class="menu-item">
							<a href="#">Books</a>
						</li>
						<li class="menu-item">
							<a href="#">Authors</a>
						</li>
						<li class="menu-item">
							<a href="#">Subjects</a>
						</li>
						<li class="menu-item">
							<a href="#">Advanced Search</a>
						</li>
					</ul>
				</div>

			</div>-->
			<div class="col-md-2" style="padding-left: 30px; margin-top: 80px;">

				<div class="footer-menu">
					<h5>Quick Links</h5>
					<ul class="menu-list">
						<li class="menu-item">
							<a href="index.php">Home</a>
						</li>
						<li class="menu-item">
							<a href="shop.php">Shop</a>
						</li>
					</ul>
				</div>

			</div>
			<div class="col-md-2" style="padding-left: 100px; margin-top: 80px;">

				<div class="footer-menu">
					<h5>Services</h5>
					<ul class="menu-list">
						<!--<li class="menu-item">
							<a href="#">Help center</a>
						</li>
						<li class="menu-item">
							<a href="#">Report a problem</a>
						</li>
						<li class="menu-item">
							<a href="#">Suggesting edits</a>
						</li>-->
						<li class="menu-item">
							<a href="contact.php">Contact us</a>
						</li>
						<li class="menu-item">
							<a href="faq.php">FAQ</a>
						</li>
					</ul>
				</div>

			</div>

		</div>
		<!-- / row -->

	</div>
</footer>

<div id="footer-bottom">
	<div class="container">
		<div class="row">
			<div class="col-md-12">

				<div class="copyright">
					<div class="row">

						<div class="col-md-6">
							<p>© 2023 All rights reserved.</p>
						</div>

						<div class="col-md-6">

						</div>

					</div>
				</div><!--grid-->

			</div><!--footer-bottom-content-->
		</div>
	</div>
</div>

<script src="js/jquery-1.11.0.min.js"></script>
<script src="js/plugins.js"></script>
<script src="js/script.js"></script>

</body>
</html>

<!DOCTYPE html>
<html lang="en">
<?php
session_start();
	if(isset($_SESSION["rname"]))
    {
      unset($_SESSION["rname"]);
    }
    if(isset($_SESSION["remail"]))
    {
      unset($_SESSION["remail"]);
    }
    if(isset($_SESSION["rhp"]))
    {
      unset($_SESSION["rhp"]);
    }
	if(isset($_SESSION["padd1"]))
    {
      unset($_SESSION["padd1"]);
    }
    if(isset($_SESSION["padd2"]))
    {
      unset($_SESSION["padd2"]);
    }
    if(isset($_SESSION["pst"]))
    {
      unset($_SESSION["pst"]);
    }
    if(isset($_SESSION["ppc"]))
    {
      unset($_SESSION["ppc"]);
    }
    if(isset($_SESSION["pct"]))
    {
      unset($_SESSION["pct"]);
    }
    if(isset($_SESSION["ptype"]))
    {
      unset($_SESSION["ptype"]);
    }
    /*if(isset($_SESSION["payment_method"]))
    {
      unset($_SESSION["payment_method"]);
    }*/
    if(isset($_SESSION["cardtype"]))
    {
      unset($_SESSION["cardtype"]);
    }
    if(isset($_SESSION["holder_name"]))
    {
      unset($_SESSION["holder_name"]);
    }
    if(isset($_SESSION["cardnum"]))
    {
      unset($_SESSION["cardnum"]);
    }
    if(isset($_SESSION["cardvv"]))
    {
      unset($_SESSION["cardvv"]);
    }
    if(isset($_SESSION["carddate"]))
    {
      unset($_SESSION["carddate"]);
    }
    /*if(isset($_SESSION["ewallet_types"]))
    {
      unset($_SESSION["ewallet_types"]);
    }
    if(isset($_SESSION["transaction_no"]))
    {
      unset($_SESSION["transaction_no"]);
    }*/
    if(isset($_SESSION["address1"]))
    {
      unset($_SESSION["address1"]);
    }
    if(isset($_SESSION["address2"]))
    {
      unset($_SESSION["address2"]);
    }
    if(isset($_SESSION["city"]))
    {
      unset($_SESSION["city"]);
    }
    if(isset($_SESSION["state"]))
    {
      unset($_SESSION["state"]);
    }
    if(isset($_SESSION["postcode"]))
    {
      unset($_SESSION["postcode"]);
    }
?>
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Verify Email</title>
	<link rel="stylesheet" href="formstyle.css">
	<script src="http://translate.google.com/translate_a/element.js?cb=loadGoogleTranslate"></script>
		<script style="text/javascript">
		  function loadGoogleTranslate() {
    const defaultLanguage = "en";

    const translateElement = new google.translate.TranslateElement({
      pageLanguage: defaultLanguage,
      includedLanguages: "en,ms,zh-CN",
      layout: google.translate.TranslateElement.InlineLayout.SIMPLE
    }, "google_element");

    // Get the language select dropdown element
    const languageSelect = document.getElementById("languageSelect");

    // Function to set a cookie
    function setCookie(name, value, days) {
      const expires = new Date();
      expires.setTime(expires.getTime() + days * 24 * 60 * 60 * 1000);
      document.cookie = `${name}=${value};expires=${expires.toUTCString()};path=/`;
    }

    // Function to get a cookie value
    function getCookie(name) {
      const cookieName = `${name}=`;
      const cookies = document.cookie.split(';');
      for (let i = 0; i < cookies.length; i++) {
        let cookie = cookies[i];
        while (cookie.charAt(0) === ' ') {
          cookie = cookie.substring(1);
        }
        if (cookie.indexOf(cookieName) === 0) {
          return cookie.substring(cookieName.length, cookie.length);
        }
      }
      return null;
    }

    // Set the initial language selection
    const storedLanguage = getCookie("selectedLanguage");
    if (storedLanguage) {
      languageSelect.value = storedLanguage;
      translateElement.update({
        includedLanguages: storedLanguage
      });
    }

    // Add event listener for change event
    languageSelect.addEventListener("change", function() {
      const selectedLanguage = this.value;
      translateElement.update({
        includedLanguages: selectedLanguage
      });
      setCookie("selectedLanguage", selectedLanguage, 30); // Set the cookie for 30 days
    });
  }
		</script>
</head>

<body>
<div id="header-wrap">

<div class="top-content">
	<div class="container">
		<div class="row">
		<div class="col-md-6" style="width: 25%;">

			</div>
			<div class="col-md-6" style="width: 75%;">
				<div class="right-element">
					<div id="google_element" style="display: inline-block;"></div>
				</div><!--top-right-->
			</div>

		</div>
	</div>
</div><!--top-content-->
	<form action="verifyemail1.php" method="post" style="border:1px solid #ccc">
		<div class="container">
			<h1>Verify Email</h1>
			<p>Please input the OTP to verify email.</p>
			<p style="color:red;">The OTP will expire in 5 minutes.</p>

			<hr>

			<label for="otp"><b>Verify Email OTP</b></label>
			<input type="number" placeholder="Enter OTP" name="otp" id="otp" min="0" required>

			<div class="clearfix">
				<button type="submit" class="signupbtn" name="otp-check">Submit</button>
			</div>

		</div>
	</form>
</body>

</html>
<?php

    if(isset($_POST['otp-check'])){
			if(time() <= $_SESSION['vExpiredTime']){
				require_once 'dataconnection.php';
				$otp = mysqli_real_escape_string($connect,$_POST['otp']);
				if(empty($_POST['otp'])){
						echo
						"
						<script>
						alert('Please input OTP!');
						</script>
						";
				}else{
						$vOTP = preg_match('/^\d{6}$/',$otp);
						if($vOTP){
								if(password_verify($otp,$_SESSION["OTP"])){
										$sql = "UPDATE customer SET vemail = ? WHERE customer_id = ? && customer_name = ? && customer_email = ?";
										$stmt = mysqli_stmt_init($connect);
										if(!mysqli_stmt_prepare($stmt,$sql)){
												echo
												"
												<script>
												alert('Sorry SQL error!');
												</script>
												";
										}else{
												$true = 1;
												mysqli_stmt_bind_param($stmt, "isss", $true ,$_SESSION['id'],$_SESSION['name'],$_SESSION['email']);
																mysqli_stmt_execute($stmt);

												$sql2 = "SELECT * FROM customer WHERE customer_id = ? && customer_name = ? && customer_email = ?";
												$stmt2 = mysqli_stmt_init($connect);
												if(!mysqli_stmt_prepare($stmt2,$sql2)){
														echo
														"
														<script>
														alert('Sorry for the SQL error! cannot get the latest email verification status.');
														</script>
														";
												}
												else{
														mysqli_stmt_bind_param($stmt2, "sss", $_SESSION['id'],$_SESSION['name'],$_SESSION['email']);
														mysqli_stmt_execute($stmt2);
														$result = mysqli_stmt_get_result($stmt2);
														if($row = mysqli_fetch_assoc($result)){
																$_SESSION['vemail'] = $row['vemail'];
																 echo
																 "
																<script>
																 alert('Email verification was successfully completed, and we updated the latest email verification status!');
																document.location.href='index.php';
														</script>
																	";
														}
														else{
																echo
																"
																<script>
																alert('Sorry for the SQL error! cannot get the latest email verification status.');
																</script>
																";
														}

						}
					mysqli_stmt_close($stmt2);
					mysqli_close($connect);
										}
					mysqli_stmt_close($stmt);
					mysqli_close($connect);
								}else if(!password_verify($vOTP,$_SESSION['OTP'])){
						 echo
				"
				<script>
				alert('Invalid OTP!');
				</script>
				";
				}

						}else{
				echo
				"
				<script>
				alert('Invalid OTP!');
				</script>
				";
			}
				}



			}else if(time() > $_SESSION['vExpiredTime']){
				//alert user
				echo
				'
				<script>
				aler("The OTP has expired! Please click the "Resend" button to request a new OTP.");
				</script>
				';

				//clear session
				unset($_SESSION["OTP"]);

				//output the resend button
				echo '
				<br>
				<br>
				';
				echo '<a href="./resendVEmailOTP.php" style="display: inline-block; padding: 10px 20px; background-color: #4CAF50; color: white; text-decoration: none; border-radius: 4px; border: none; text-align: center; cursor: pointer;">Resend Email Verification OTP</a>';

			}

















    }
?>

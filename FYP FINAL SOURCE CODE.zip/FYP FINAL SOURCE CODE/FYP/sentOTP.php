<?php
session_start();
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPmailer/src/Exception.php';
require 'PHPmailer/src/PHPMailer.php';
require 'PHPmailer/src/SMTP.php';

$email="knowledgemain1991@gmail.com";
$appPass="bsbddqyahqsshvdf";
$OTP= mt_rand(100000,999999);
$hashedOTP = password_hash($OTP,PASSWORD_DEFAULT);
$_SESSION["OTP"]= $hashedOTP;
$_SESSION["vExpiredTime"] = time() + 300;
$subject="Email Verfication -- Knowledge";
$body ='<div style="font-family: Helvetica,Arial,sans-serif;min-width:1000px;overflow:auto;line-height:2">
<div style="margin:50px auto;width:70%;padding:20px 0">
  <div style="border-bottom:1px solid #eee">
    <a href="" style="font-size:1.4em;color: #00466a;text-decoration:none;font-weight:600">Knowledge</a>
  </div>
  <p style="font-size:1.1em">Hi,</p>
  <p>Thank you for choosing Knowledge. Use the following OTP to complete your Sign Up procedures. OTP is valid for 5 minutes</p>
  <h2 style="background: #00466a;margin: 0 auto;width: max-content;padding: 0 10px;color: #fff;border-radius: 4px;">'.$OTP.'</h2>
  <p style="font-size:0.9em;">Regards,<br />Knowledge Sdn Bhd</p>
  <hr style="border:none;border-top:1px solid #eee" />
  <div style="float:right;padding:8px 0;color:#aaa;font-size:0.8em;line-height:1;font-weight:300">
    <p>Knowledge Sdn Bhd, Jalan Ayer Keroh Lama,</p>
    <p>75450, Bukit Beruang,</p>
    <p>Melaka, Malaysia</p>
  </div>
</div>
</div>
';

if(isset($_SESSION['vemail'])){

        $vemail = $_SESSION['vemail'];


        if($vemail == false){

        $mail = new PHPMailer(true);

        $mail -> isSMTP();
        $mail -> Host = 'smtp.gmail.com';
        $mail -> SMTPAuth = true;
        $mail -> Username = $email; //Your email
        $mail -> Password = $appPass; //Your email app password
        $mail -> SMTPSecure = 'ssl';
        $mail -> Port = 465;

        $mail -> setFrom($email); //Your email

        $mail -> addAddress($_SESSION['email']); // customer email

        $mail -> isHTML(true);

        $mail -> Subject = $subject;
        $mail -> Body = $body;

        $mail -> send();

        //OTP sent
        echo
        "
        <script>
        alert('You need to verify your email address first ---- OTP sent!');
        document.location.href='verifyemail1.php';
        </script>
        ";
        }
        else if($vemail == true){

        echo
        "
        <script>
        alert('Email already verified!');
        document.location.href='index.php';
        </script>
        ";
        }
 }

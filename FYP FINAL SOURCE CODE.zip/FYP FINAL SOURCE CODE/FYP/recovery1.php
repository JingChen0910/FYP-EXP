<?php
session_start();
require_once 'dataconnection.php';

	use PHPMailer\PHPMailer\PHPMailer;
	use PHPMailer\PHPMailer\Exception;

	require 'PHPmailer/src/Exception.php';
	require 'PHPmailer/src/PHPMailer.php';
	require 'PHPmailer/src/SMTP.php';

?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Recovery Password</title>
    	<link rel="stylesheet" href="formstyle.css">
      	<script src="https://www.google.com/recaptcha/api.js" async defer></script>
  </head>
  <body>
    <form action="recovery1.php" style="border:1px solid #ccc" method="post">
  <div class="container">
    <h1>Recovery Password</h1>
    <p>Please fill in this form to recover your password.</p>
		<?php
		// emptyemail
		// sqlerror
		// accountdoesnotexist
		// invalidemail
		// emptyrecaptcha
		if(isset($_GET['status'])){
			$s = $_GET['status'];
			if($s == "emptyemail"){
				 echo '<h1 style="color:red;">Please fill in your email! &#128581;&#8205;&#9794;&#65039;</h1>';
			}else if($s == "sqlerror"){
				   echo '<h1 style="color:red;">Sorry, recovery password got trouble. &#129301;</h1>';
			}else if($s == "accountdoesnotexist"){
						 echo '<h1 style="color:red;">Account does not exist! &#128581;&#8205;&#9794;&#65039;</h1>';
			}
			else if($s == "invalidemail"){
		echo '<h1 style="color:red;">Invalid email! &#128581;&#8205;&#9794;&#65039;</h1>';
			}
			else if($s == "emptyrecaptcha"){
 echo '<h1 style="color:red;">Do the recaptcha test, or you are a bot!? &#129302;</h1>';
			}





		}
		?>
    <hr>

    <label for="email"><b>Email</b></label>
    <input type="email" placeholder="Enter Email" name="email" required>

    <div class="g-recaptcha" data-sitekey="6Lcfkl8mAAAAAM17lon3KPsh-IF2ub16hVBNis-c"></div>


    <div class="clearfix">
      <button type="submit" class="signupbtn" name="recovery">Submit</button>
      <button type="button" class="cancelbtn" onclick="clogin()">Cancel</button>

    </div>
  </div>
</form>
<script type="text/javascript">
  function clogin(){
    window.location.href="./index.php";
  }

</script>
  </body>
</html>
<?php
if(isset($_POST["recovery"])){
    $email = mysqli_real_escape_string($connect,$_POST['email']);

    $secret ="6Lcfkl8mAAAAADYvd9vzdhNkkgUV7CqUmvLPK0Df";
    $response = $_POST['g-recaptcha-response'];
    $remoteip = $_SERVER['REMOTE_ADDR'];
    $URL = "https://www.google.com/recaptcha/api/siteverify?secret=$secret&response=$response&remoteip=$remoteip";
    $data = file_get_contents($URL);
    $Recaptcha = json_decode($data,true);

    if($Recaptcha['success'] == true){
      if(empty($email)){
        header("Location:./recovery1.php?status=emptyemail");
        exit();
      }else{
        $vemail = filter_var($email,FILTER_VALIDATE_EMAIL);
        $vemailRegex = preg_match('/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/',$email);

        if($vemail && $vemailRegex){

          $_SESSION["recoveryEmail"] = $email;

          $sql = "SELECT * FROM customer WHERE customer_email=?;";
          $stmt = mysqli_stmt_init($connect);
          if(!mysqli_stmt_prepare($stmt,$sql)){
            header("Location:./recovery1.php?status=sqlerror");
          }else{
            mysqli_stmt_bind_param($stmt,"s",$_SESSION["recoveryEmail"]);
            mysqli_stmt_execute($stmt);
            mysqli_stmt_store_result($stmt);
            $emailRow = mysqli_stmt_num_rows($stmt);
            if($emailRow > 0){
              $email="knowledgemain1991@gmail.com";
              $appPass="bsbddqyahqsshvdf";
              $OTP= mt_rand(100000,999999);
              $hashedOTP = password_hash($OTP,PASSWORD_DEFAULT);
              $_SESSION["OTP"]= $hashedOTP;
              $_SESSION["vExpiredTime"] = time() + 300;
              $subject="Recovery Password -- Knowledge";
              $body ='<div style="font-family: Helvetica,Arial,sans-serif;min-width:1000px;overflow:auto;line-height:2">
              <div style="margin:50px auto;width:70%;padding:20px 0">
                <div style="border-bottom:1px solid #eee">
                  <a href="" style="font-size:1.4em;color: #00466a;text-decoration:none;font-weight:600">Knowledge</a>
                </div>
                <p style="font-size:1.1em">Hi,</p>
                <p>Thank you for choosing Knowledge. Use the following OTP to complete your Recovery Password procedures. OTP is valid for 5 minutes</p>
                <h2 style="background: #00466a;margin: 0 auto;width: max-content;padding: 0 10px;color: #fff;border-radius: 4px;">'.$OTP.'</h2>
                <p style="font-size:0.9em;">Regards,<br />Knowledge Sdn Bhd</p>
                <hr style="border:none;border-top:1px solid #eee" />
                <div style="float:right;padding:8px 0;color:#aaa;font-size:0.8em;line-height:1;font-weight:300">
                  <p>Knowledge Sdn Bhd, Jalan Ayer Keroh Lama,</p>
                  <p>75450, Bukit Beruang,</p>
                  <p>Melaka, Malaysia</p>
                </div>
              </div>
              </div>
              ';


                      $mail = new PHPMailer(true);

                      $mail -> isSMTP();
                      $mail -> Host = 'smtp.gmail.com';
                      $mail -> SMTPAuth = true;
                      $mail -> Username = $email; //Your email
                      $mail -> Password = $appPass; //Your email app password
                      $mail -> SMTPSecure = 'ssl';
                      $mail -> Port = 465;

                      $mail -> setFrom($email); //Your email

                      $mail -> addAddress($_SESSION["recoveryEmail"]); // customer email

                      $mail -> isHTML(true);

                      $mail -> Subject = $subject;
                      $mail -> Body = $body;

                      $mail -> send();

                      //OTP sent
                      echo
                      "
                      <script>
                      alert('Recovery Password OTP sent!');
                      document.location.href='OTPcheckRecovery.php';
                      </script>
                      ";
            }else{
              header("Location:./recovery1.php?status=accountdoesnotexist");
              exit();
            }
          }


        }else if(!$vemail || !$vemailRegex){
          header("Location:./recovery1.php?status=invalidemail");
        }

      }

    }else{
      header("Location:./recovery1.php?status=emptyrecaptcha");
      exit();
    }



}




?>

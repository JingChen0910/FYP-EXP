<?php include("dataconnection.php"); 
  session_start();
  if(!isset($_SESSION['id']) || !isset($_SESSION['name']) || !isset($_SESSION['email']) || !isset($_SESSION['vemail'])){
    echo "<script>window.location.href='clogin.php';</script>";
   }else if(isset($_SESSION['id']) &&  isset($_SESSION['name']) && isset($_SESSION['email']) && isset($_SESSION['vemail'])){
       $vemail = $_SESSION['vemail'];
       if($vemail == false){
        echo "<script>window.location.href='sentOTP.php';</script>";
        exit();
       }
       // else{
       // 	header("Location:./index.php");
       // 	exit();
       // }
   }
  if(isset($_POST["confirm_paybtn"]))
  {
    $customer_id=$_SESSION["id"];
    date_default_timezone_set('Asia/Kuala_Lumpur');
    $date=date('Y-m-d H:i:s');
    $select_address=$_SESSION["select_address"];
    if($select_address=="r2")
    {   $rname=$_SESSION["rname"];
      $remail=$_SESSION["remail"];
      $rhp=$_SESSION["rhp"];
        $address1=$_SESSION["address1"];
		$address2=$_SESSION["address2"];
		$city=$_SESSION["city"];
		$postcode=$_SESSION["postcode"];
		$state=$_SESSION["state"];
    if(isset($_SESSION["state"]) && $_SESSION["state"]!="Sabah" && $_SESSION["state"]!="Sarawak")
    {
      $arrive_date=date('Y-m-d', strtotime('+3 days', strtotime($date)));
    }
    else if(isset($_SESSION["state"]) && $_SESSION["state"]=="Sabah" || $_SESSION["state"]=="Sarawak")
    {
      $arrive_date=date('Y-m-d', strtotime('+5 days', strtotime($date)));
    }
    }
    else if($select_address=="r1")
    {
        $custaddress_sql="SELECT * FROM address WHERE customer_id=$customer_id";
	    $run_custaddress_sql=mysqli_query($connect, $custaddress_sql);
	    $num_rows_custaddress=mysqli_num_rows($run_custaddress_sql);
		if($num_rows_custaddress==1)
		{  
			while($rows_custaddress=mysqli_fetch_assoc($run_custaddress_sql))
		    {
          $address1=$rows_custaddress["address1"];
          $address1=trim($address1);
			    $address2=$rows_custaddress["address2"];
          $address2=trim($address2);
			    $state=$rows_custaddress["state"];
			    $city=$rows_custaddress["city"];
			    $postcode=$rows_custaddress["postalCode"];
		    }
		}
    if($state!="Sabah" && $state!="Sarawak")
    {
      $arrive_date=date('Y-m-d', strtotime('+3 days', strtotime($date)));
    }
    else
    {
      $arrive_date=date('Y-m-d', strtotime('+5 days', strtotime($date)));
    }
    }
    if($select_address=="r2")
    { $insert_orders="INSERT INTO orders(customer_id, order_status, order_date, recipient_name, recipient_phoneNumber, recipient_email, delivery_address1, delivery_address2, delivery_state, delivery_city, delivery_postalCode, estimated_arriveDate, shipping_fee, overall_total) VALUES($customer_id, 'Processing', '$date', '$rname', '$rhp', '$remail', '$address1', '$address2', '$state', '$city', '$postcode', '$arrive_date', 0, 0)";
      $run_insert_orders=mysqli_query($connect, $insert_orders);
    }
    else if($select_address=="r1")
    { $sel_cust="SELECT * FROM customer WHERE customer_id=$customer_id";
      $runsel_cust=mysqli_query($connect, $sel_cust);
      $num_rows_cust=mysqli_num_rows($runsel_cust);
      if($num_rows_cust==1)
      {
        $rows_sel_cust=mysqli_fetch_assoc($runsel_cust);
        $rname=$rows_sel_cust["customer_name"];
        $remail=$rows_sel_cust["customer_email"];
        $rhp=$rows_sel_cust["customer_phoneNumber"];
        $insert_orders="INSERT INTO orders(customer_id, order_status, order_date, recipient_name, recipient_phoneNumber, recipient_email, delivery_address1, delivery_address2, delivery_state, delivery_city, delivery_postalCode, estimated_arriveDate, shipping_fee, overall_total) VALUES($customer_id, 'Processing', '$date', '$rname', '$rhp', '$remail', '$address1', '$address2', '$state', '$city', '$postcode', '$arrive_date', 0, 0)";
        $run_insert_orders=mysqli_query($connect, $insert_orders);
      }
    }
    if($run_insert_orders==1)
    {
        $select_order="SELECT order_id FROM orders WHERE customer_id=$customer_id AND order_date='$date'";
        $run_select_order=mysqli_query($connect, $select_order);
        $rows_order=mysqli_fetch_assoc($run_select_order);
        $order_id=$rows_order["order_id"];
        $select_carts="SELECT cart.customer_id, cart_item.* FROM cart, cart_item WHERE cart.cart_id=cart_item.cart_id AND cart.customer_id=$customer_id";
        $run_select_carts=mysqli_query($connect, $select_carts);
        $num_rows_cart=mysqli_num_rows($run_select_carts);
        if($num_rows_cart!=0)
        {   $overall_total=0; $shipping_fee=0;
            while($rows_cart=mysqli_fetch_assoc($run_select_carts))
            {
               $product_id=$rows_cart["product_id"];
               $quantity=$rows_cart["item_quantity"];
               $select_product="SELECT product.discount_price, stock.* FROM product, stock WHERE product.product_id=stock.product_id AND product.product_id='$product_id' AND product.availability=0";
               $run_select_product=mysqli_query($connect, $select_product);
               $num_rows_product=mysqli_num_rows($run_select_product);
               if($num_rows_product==1)
               {
                while($rows_product=mysqli_fetch_assoc($run_select_product))
                {
                    $price=$rows_product["discount_price"];
                    $stock=$rows_product["stock_level"];
                }
               }
               $total=$price*$quantity; $overall_total+=$total;
               $insert_orderitems="INSERT INTO order_details(order_id, product_id, quantity, price, total_price) VALUES($order_id, '$product_id', $quantity, $price, $total)";
               $run_insert_orderitems=mysqli_query($connect, $insert_orderitems);
               $updated_stock=$stock-$quantity;
               $update_stock="UPDATE stock SET stock_level=$updated_stock WHERE product_id='$product_id'";
               $run_update_stock=mysqli_query($connect, $update_stock);
            }
            if(isset($_SESSION["state"]) && $_SESSION["state"]!="Sabah" && $_SESSION["state"]!="Sarawak")
            {
              $shipping_fee=$overall_total*0.06;
            }
            else if(isset($_SESSION["state"]) && $_SESSION["state"]=="Sabah" && $_SESSION["state"]="Sarawak")
            {
              $shipping_fee=$overall_total*0.09;
            }
            else if($state!="Sabah" && $state!="Sarawak")
            {
              $shipping_fee=$overall_total*0.06;
            }
            else
            {
              $shipping_fee=$overall_total*0.09;
            }
            $overall_total+=$shipping_fee;
            $update_orders="UPDATE orders SET shipping_fee=$shipping_fee, overall_total=$overall_total WHERE order_id=$order_id";
           $run_update_orders=mysqli_query($connect, $update_orders);
        }
        //$payment_method=$_SESSION["payment_method"];
        $insert_payment="INSERT INTO payment(order_id, payment_method, payment_date, payment_status) VALUES($order_id, 'Credit/Debit Card', '$date', 'Successful')";
        $run_insert_payment=mysqli_query($connect, $insert_payment);
    }
    $select_cart="SELECT cart_id FROM cart WHERE customer_id=$customer_id";
    $run_select_cart=mysqli_query($connect, $select_cart);
    $row_cart=mysqli_fetch_assoc($run_select_cart);
    $cartid=$row_cart["cart_id"];
    $del_cartitems="DELETE FROM cart_item WHERE cart_id=$cartid";
    $run_del_cartitems=mysqli_query($connect, $del_cartitems);
    $del_cart="DELETE FROM cart WHERE cart_id=$cartid";
    $run_del_cart=mysqli_query($connect, $del_cart);
/*if(isset($_SESSION["pf"]))
    {
      unset($_SESSION["pf"]);
    }*/
    if(isset($_SESSION["del"]))
	 {
		unset($_SESSION["del"]);
	 }
    if(isset($_SESSION["rname"]))
    {
      unset($_SESSION["rname"]);
    }
    if(isset($_SESSION["remail"]))
    {
      unset($_SESSION["remail"]);
    }
    if(isset($_SESSION["rhp"]))
    {
      unset($_SESSION["rhp"]);
    }
    if(isset($_SESSION["padd1"]))
    {
      unset($_SESSION["padd1"]);
    }
    if(isset($_SESSION["padd2"]))
    {
      unset($_SESSION["padd2"]);
    }
    if(isset($_SESSION["pst"]))
    {
      unset($_SESSION["pst"]);
    }
    if(isset($_SESSION["ppc"]))
    {
      unset($_SESSION["ppc"]);
    }
    if(isset($_SESSION["pct"]))
    {
      unset($_SESSION["pct"]);
    }
    if(isset($_SESSION["ptype"]))
    {
      unset($_SESSION["ptype"]);
    }
    /*if(isset($_SESSION["payment_method"]))
    {
      unset($_SESSION["payment_method"]);
    }*/
    if(isset($_SESSION["cardtype"]))
    {
      unset($_SESSION["cardtype"]);
    }
    if(isset($_SESSION["holder_name"]))
    {
      unset($_SESSION["holder_name"]);
    }
    if(isset($_SESSION["cardnum"]))
    {
      unset($_SESSION["cardnum"]);
    }
    if(isset($_SESSION["cardvv"]))
    {
      unset($_SESSION["cardvv"]);
    }
    if(isset($_SESSION["carddate"]))
    {
      unset($_SESSION["carddate"]);
    }
    /*if(isset($_SESSION["ewallet_types"]))
    {
      unset($_SESSION["ewallet_types"]);
    }
    if(isset($_SESSION["transaction_no"]))
    {
      unset($_SESSION["transaction_no"]);
    }*/
    if(isset($_SESSION["address1"]))
    {
      unset($_SESSION["address1"]);
    }
    if(isset($_SESSION["address2"]))
    {
      unset($_SESSION["address2"]);
    }
    if(isset($_SESSION["city"]))
    {
      unset($_SESSION["city"]);
    }
    if(isset($_SESSION["state"]))
    {
      unset($_SESSION["state"]);
    }
    if(isset($_SESSION["postcode"]))
    {
      unset($_SESSION["postcode"]);
    }
    if($run_insert_payment && $run_del_cart && $run_del_cartitems)
    {
        echo "<script>alert('Order placed successfully...'); window.location.href='order_history.php';</script>";
    }
  }
?>
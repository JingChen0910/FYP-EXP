<?php include("dataconnection.php"); 
  session_start();
  if(!isset($_SESSION['id']) || !isset($_SESSION['name']) || !isset($_SESSION['email']) || !isset($_SESSION['vemail'])){
    echo "<script>window.location.href='clogin.php';</script>";
 }else if(isset($_SESSION['id']) &&  isset($_SESSION['name']) && isset($_SESSION['email']) && isset($_SESSION['vemail'])){
       $vemail = $_SESSION['vemail'];
       if($vemail == false){
        echo "<script>window.location.href='sentOTP.php';</script>";
        exit();
       }
       // else{
       // 	header("Location:./index.php");
       // 	exit();
       // }
 }
  if(isset($_POST["delrate"]))
  { $rating_id=$_POST["rating_id"];
    $del_rate="DELETE FROM rating WHERE rating_id=$rating_id";
    $run_del_rate=mysqli_query($connect, $del_rate);
    if($run_del_rate)
    {
        echo "<script>alert('Rating deleted successfully...'); history.go(-1);</script>";
    }
  }
?>
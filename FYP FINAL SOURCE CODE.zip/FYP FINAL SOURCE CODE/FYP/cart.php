<!DOCTYPE html>
    <?php include("dataconnection.php");
	session_start();
	if(!isset($_SESSION['id']) || !isset($_SESSION['name']) || !isset($_SESSION['email']) || !isset($_SESSION['vemail'])){
		echo "<script>window.location.href='clogin.php';</script>";
	 }else if(isset($_SESSION['id']) &&  isset($_SESSION['name']) && isset($_SESSION['email']) && isset($_SESSION['vemail'])){
		   $vemail = $_SESSION['vemail'];
		   if($vemail == false){
			echo "<script>window.location.href='sentOTP.php';</script>";
			  exit();
		   }
		   // else{
		   // 	header("Location:./index.php");
		   // 	exit();
		   // }
	 }
	 if(isset($_SESSION["del"]))
	 {
		unset($_SESSION["del"]);
	 }
    ?>
	<html lang="en">
	<head>
		<title>Book Store</title>
		<meta charset="utf-8">
	    <meta http-equiv="X-UA-Compatible" content="IE=edge">
	    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	    <meta name="format-detection" content="telephone=no">
	    <meta name="apple-mobile-web-app-capable" content="yes">
	    <meta name="author" content="">
	    <meta name="keywords" content="">
	    <meta name="description" content="">

	    <link rel="stylesheet" type="text/css" href="css/normalize.css">
	    <link rel="stylesheet" type="text/css" href="icomoon/icomoon.css">
	    <link rel="stylesheet" type="text/css" href="css/vendor.css">
	    <link rel="stylesheet" type="text/css" href="style.css">

		<!-- script
		================================================== -->
		<script src="http://translate.google.com/translate_a/element.js?cb=loadGoogleTranslate"></script>
		<script src="js/modernizr.js">
			function handle_keyup(event){
				if (event.keyCode === 13) {
                   document.getElementById('search_btn').click();
                }
			}
		</script>
		<script style="text/javascript">
			function loadGoogleTranslate() {
    const defaultLanguage = "en";

    const translateElement = new google.translate.TranslateElement({
      pageLanguage: defaultLanguage,
      includedLanguages: "en,ms,zh-CN",
      layout: google.translate.TranslateElement.InlineLayout.SIMPLE
    }, "google_element");

    // Get the language select dropdown element
    const languageSelect = document.getElementById("languageSelect");

    // Function to set a cookie
    function setCookie(name, value, days) {
      const expires = new Date();
      expires.setTime(expires.getTime() + days * 24 * 60 * 60 * 1000);
      document.cookie = `${name}=${value};expires=${expires.toUTCString()};path=/`;
    }

    // Function to get a cookie value
    function getCookie(name) {
      const cookieName = `${name}=`;
      const cookies = document.cookie.split(';');
      for (let i = 0; i < cookies.length; i++) {
        let cookie = cookies[i];
        while (cookie.charAt(0) === ' ') {
          cookie = cookie.substring(1);
        }
        if (cookie.indexOf(cookieName) === 0) {
          return cookie.substring(cookieName.length, cookie.length);
        }
      }
      return null;
    }

    // Set the initial language selection
    const storedLanguage = getCookie("selectedLanguage");
    if (storedLanguage) {
      languageSelect.value = storedLanguage;
      translateElement.update({
        includedLanguages: storedLanguage
      });
    }

    // Add event listener for change event
    languageSelect.addEventListener("change", function() {
      const selectedLanguage = this.value;
      translateElement.update({
        includedLanguages: selectedLanguage
      });
      setCookie("selectedLanguage", selectedLanguage, 30); // Set the cookie for 30 days
    });
  }
		</script>
	</head>

<body>


<div id="header-wrap">

	<div class="top-content">
		<div class="container">
			<div class="row">
				<div class="col-md-6" style="width: 25%;">

				</div>
				<div class="col-md-6" style="width: 75%;">
					<div class="right-element">

						<?php
						if(isset($_SESSION["id"]))
						{   $cust_id=$_SESSION["id"];
							$cartsql="SELECT * FROM cart WHERE customer_id=$cust_id";
							$run_cartsql=mysqli_query($connect, $cartsql);
							$num_rows_cartsql=mysqli_num_rows($run_cartsql);
							$rows_cartsql=mysqli_fetch_assoc($run_cartsql);
							if($num_rows_cartsql==0)
							{
								$cartitem_rows=0;
							}
							else
							{   $cartid=$rows_cartsql["cart_id"];
								$cartitemsql="SELECT * FROM cart_item WHERE cart_id=$cartid";
							    $run_cartitemsql=mysqli_query($connect, $cartitemsql);
							    $cartitem_rows=mysqli_num_rows($run_cartitemsql);
								$del_val=0;
								while($rows_cartitemsql=mysqli_fetch_assoc($run_cartitemsql))
								{
                                  $prodid=$rows_cartitemsql["product_id"];
								  $itemqty=$rows_cartitemsql["item_quantity"];
								  $stocksql="SELECT * FROM stock WHERE product_id='$prodid'";
                                  $run_stocksql=mysqli_query($connect, $stocksql);
                                  $stockrows=mysqli_fetch_assoc($run_stocksql);
                                  $stocklevel=$stockrows['stock_level'];
								  $prodsql="SELECT * FROM product WHERE product_id='$prodid' AND availability=0";
                                  $run_prodsql=mysqli_query($connect, $prodsql);
                                  $prodrows=mysqli_num_rows($run_prodsql);
								  if($prodrows==0)
								  {
									$del_cartitem="DELETE FROM cart_item WHERE cart_id=$cartid AND product_id='$prodid'";
									$run_del_cartitem=mysqli_query($connect, $del_cartitem);
									if($run_del_cartitem)
                                      $del_val++;
								  }
								  else if($stocklevel==0)
								  {
									$del_cartitem="DELETE FROM cart_item WHERE cart_id=$cartid AND product_id='$prodid'";
									$run_del_cartitem=mysqli_query($connect, $del_cartitem);
									if($run_del_cartitem)
                                      $del_val++;
								  }
								  else if($itemqty>$stocklevel)
								  {
									$update_cartitem="UPDATE cart_item SET item_quantity=$stocklevel WHERE cart_id=$cartid AND product_id='$prodid'";
									$run_update_cartitem=mysqli_query($connect, $update_cartitem);
								  }
								}
								if($del_val==$cartitem_rows)
								{
									$del_cart="DELETE FROM cart WHERE cart_id=$cartid";
									$run_del_cart=mysqli_query($connect, $del_cart);
								}
								$cartitem_rows-=$del_val;
							}
							$select_cust="SELECT * FROM customer WHERE customer_id=$cust_id";
							$run_select_cust=mysqli_query($connect, $select_cust);
							$row_select_cust=mysqli_fetch_assoc($run_select_cust);
							$user_profile=$row_select_cust["customer_profile_picture"];
							?>
							<!--<a href="cart.php" class="cart for-buy"><img src="images/carts.png" style="width: 50px; height: 50px; opacity: 70%; margin-bottom: 5px;"><span>Cart: <?php //echo $cartitem_rows; ?> item(s)</span></a>-->
							<a href="order_history.php" class="cart for-buy"><i class="icon icon-clipboard"></i> <span>Order History</span></a>
						<nav id="navbar" style="display: inline-block; margin-left: -40px; z-index: 3; position: relative;">
						<div class="main-menu stellarnav">
						<ul class="menu-list">
						<li class="menu-item has-sub">
						<a href="./user_profile.php" class="nav-link" data-effect="Pages"><img src="images/cus_profile/<?php echo $user_profile; ?>" style="width: 40px; height: 40px; border-radius: 50%; margin-right: 10px;" alt="user_profile" title="user_profile">Account</a>
							<ul style="font-size: 16px;">
								<li><a href="./user_profile.php">My Profile</a></li>
								<li><a href="./logoutaction.php">Logout</a></li>
							 </ul>
						</li>
						</ul>
						</div>
						</nav>
                        <?php
						}
						?>
						<div class="action-menu" style="margin-left: 10px;">

							<div class="search-bar">
								<a href="#" class="search-button search-toggle" data-selector="#header-wrap">
									<i class="icon icon-search"></i>
								</a>
								<form role="search" method="get" class="search-box" action="search_products.php">
									<input class="search-field text search-input" placeholder="Search products" type="text" name="search_keyword" onkeyup="handle_keyup(event)">
									<input type="submit" id="search_btn" style="display: none;">
								</form>
							</div>
						</div>
                        <div id="google_element" style="display: inline-block;"></div>
					</div><!--top-right-->
				</div>

			</div>
		</div>
	</div><!--top-content-->

	<header id="header" style="background-color: #f3e7be;">
		<div class="container">
			<div class="row">

			<div class="col-md-2">
					<!--<div class="main-logo">-->
						<a href="index.php"><img src="images/icon/logo.png" alt="logo" style="height: 140px; margin:-60px 0px -30px 0px;"></a>
					<!--</div>-->
			</div>

				<div class="col-md-10">

					<nav id="navbar" style="z-index: 1; position: relative;">
						<div class="main-menu stellarnav">
							<ul class="menu-list">
								<li class="menu-item active"><a href="index.php" data-effect="Home">Home</a></li>
								<li class="menu-item"><a href="about_us.php" class="nav-link" data-effect="About">About</a></li>
								<!--<li class="menu-item has-sub">
									<a href="#pages" class="nav-link" data-effect="Pages">Pages</a>

									<ul>
								        <li><a href="styles.html">Styles</a></li>
								        <li><a href="blog.html">Blog</a></li>
								        <li><a href="single-post.html">Post Single</a></li>
								        <li><a href="thank-you.html">Thank You</a></li>
								     </ul>

								</li>-->
								<li class="menu-item"><a href="shop.php" class="nav-link" data-effect="Shop">Shop</a></li>
								<li class="menu-item"><a href="contact.php" class="nav-link" data-effect="Contact">Contact Us</a></li>
							</ul>

							<div class="hamburger">
				                <span class="bar"></span>
				                <span class="bar"></span>
				                <span class="bar"></span>
				            </div>

						</div>
					</nav>

				</div>

			</div>
		</div>
	</header>

</div><!--header-wrap-->

<div>
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div class="colored">
					<!--<h1 class="page-title">Cart</h1>--><br>
					<div class="breadcum-items">
						<span class="item"><a href="index.php">Home</a> /</span>
						<span class="item colored">Cart</span>
					</div>
				</div>
			</div>
		</div>
	</div>
</div><!--site-banner-->

<section class="padding-large">
<div class="container">
	  <?php $total=0;
	  if(isset($_POST["dpladdressbtn"]))
	  {
		if(isset($_POST["paytype"]))
		{
		  $_SESSION["ptype"]=$ptype=$_POST["paytype"];
		  if($ptype=="r2")
		  {
			  $_SESSION["rname"]=$_POST["rname"]; $_SESSION["remail"]=$_POST["remail"]; $_SESSION["rhp"]=$_POST["rhp"]; $_SESSION["padd1"]=$_POST["dpaddress1"]; $_SESSION["padd2"]=$_POST["dpaddress2"]; $_SESSION["pct"]=$_POST["dpcity"]; $_SESSION["ppc"]=$_POST["dppostcode"]; $_SESSION["pst"]=$_POST["dpstate"];
		  }
		  else if($ptype=="r1")
		  {
			  $custaddress_sql="SELECT * FROM address WHERE customer_id=$cust_id";
			 $run_custaddress_sql=mysqli_query($connect, $custaddress_sql);
			 $num_rows_custaddress=mysqli_num_rows($run_custaddress_sql);
			if($num_rows_custaddress==1)
			{
			  while($rows_custaddress=mysqli_fetch_assoc($run_custaddress_sql))
			  {
				  $_SESSION["padd1"]=$address1=$rows_custaddress["address1"];
				  $_SESSION["padd2"]=$address2=$rows_custaddress["address2"];
				  $_SESSION["pst"]=$state=$rows_custaddress["state"];
				  $_SESSION["pct"]=$city=$rows_custaddress["city"];
				  $_SESSION["ppc"]=$postcode=$rows_custaddress["postalCode"];
			  }
			}
			else
			{
				unset($_SESSION["ptype"]);
			}
		  }
		}
		else
		{
		  $_SESSION["padd1"]=$_POST["dpaddress1"]; $_SESSION["padd2"]=$_POST["dpaddress2"]; $_SESSION["pct"]=$_POST["dpcity"]; $_SESSION["ppc"]=$_POST["dppostcode"]; $_SESSION["pst"]=$_POST["dpstate"];
		}
	  }
	  if(isset($_POST["preturnbtn"]))
	  {
		if(isset($_POST["pselect"]))
		{
		  $_SESSION["ptype"]=$ptype=$_POST["pselect"];
		  if($ptype=="r2")
		  {
			$_SESSION["rname"]=$_POST["rname"]; $_SESSION["remail"]=$_POST["remail"]; $_SESSION["rhp"]=$_POST["rhp"]; $_SESSION["padd1"]=$_POST["paddress1"]; $_SESSION["padd2"]=$_POST["paddress2"]; $_SESSION["pct"]=$_POST["pcity"]; $_SESSION["ppc"]=$_POST["ppostcode"]; $_SESSION["pst"]=$_POST["pstate"];
		  }
		  else if($ptype=="r1")
		  {
			  $custaddress_sql="SELECT * FROM address WHERE customer_id=$cust_id";
			 $run_custaddress_sql=mysqli_query($connect, $custaddress_sql);
			 $num_rows_custaddress=mysqli_num_rows($run_custaddress_sql);
			if($num_rows_custaddress==1)
			{
			  while($rows_custaddress=mysqli_fetch_assoc($run_custaddress_sql))
			  {
				  $_SESSION["padd1"]=$address1=$rows_custaddress["address1"];
				  $_SESSION["padd2"]=$address2=$rows_custaddress["address2"];
				  $_SESSION["pst"]=$state=$rows_custaddress["state"];
				  $_SESSION["pct"]=$city=$rows_custaddress["city"];
				  $_SESSION["ppc"]=$postcode=$rows_custaddress["postalCode"];
			  }
			}
			else
			{
				unset($_SESSION["ptype"]);
			}
		  }
		}
		else
		{   $_SESSION["ptype"]=$ptype="r1";
			$custaddress_sql="SELECT * FROM address WHERE customer_id=$cust_id";
			 $run_custaddress_sql=mysqli_query($connect, $custaddress_sql);
			 $num_rows_custaddress=mysqli_num_rows($run_custaddress_sql);
			if($num_rows_custaddress==1)
			{
			  while($rows_custaddress=mysqli_fetch_assoc($run_custaddress_sql))
			  {
				  $_SESSION["padd1"]=$address1=$rows_custaddress["address1"];
				  $_SESSION["padd2"]=$address2=$rows_custaddress["address2"];
				  $_SESSION["pst"]=$state=$rows_custaddress["state"];
				  $_SESSION["pct"]=$city=$rows_custaddress["city"];
				  $_SESSION["ppc"]=$postcode=$rows_custaddress["postalCode"];
			  }
			}
			else
			{
				unset($_SESSION["ptype"]);
			}
		}
		/*if(isset($_POST["payment_method"]))
		{   $_SESSION["payment_method"]=$_POST["payment_method"];
			if($_SESSION["payment_method"]=="Credit/Debit Card")
			{*/
				if(isset($_POST["cardtype"]))
			    {   $_SESSION["cardtype"]=$_POST["cardtype"];
				    $_SESSION["holder_name"]=$_POST["holder_name"];
				    $_SESSION["cardnum"]=$_POST["cardnum"];
				    $_SESSION["cardvv"]=$_POST["cardvv"];
				    $_SESSION["carddate"]=$_POST["carddate"];
			    }
				/*
				if(isset($_POST["ewallet_types"]))
				{   $_SESSION["ewallet_types"]="";
				}
				if(isset($_POST["transaction_no"]))
				{   $_SESSION["transaction_no"]="";
				}
			}
			else if($_SESSION["payment_method"]=="E-Wallet")
			{
				if(isset($_POST["cardtype"]))
			    {   $_SESSION["cardtype"]="";
			    }
				if(isset($_POST["holder_name"]))
				{  $_SESSION["holder_name"]="";
				}
				if(isset($_POST["cardnum"]))
				{  $_SESSION["cardnum"]="";
				}
				if(isset($_POST["cardvv"]))
				{  $_SESSION["cardvv"]="";
				}
				if(isset($_POST["carddate"]))
				{  $_SESSION["carddate"]="";
				}
				if(isset($_POST["ewallet_types"]))
				{
					$_SESSION["ewallet_types"]=$_POST["ewallet_types"];
				    $_SESSION["transaction_no"]=$_POST["transaction_no"];
				}
			}
			else if($_SESSION["payment_method"]=="0")
			{
				if(isset($_POST["cardtype"]))
			    {   $_SESSION["cardtype"]="";
			    }
				if(isset($_POST["holder_name"]))
				{  $_SESSION["holder_name"]="";
				}
				if(isset($_POST["cardnum"]))
				{  $_SESSION["cardnum"]="";
				}
				if(isset($_POST["cardvv"]))
				{  $_SESSION["cardvv"]="";
				}
				if(isset($_POST["carddate"]))
				{  $_SESSION["carddate"]="";
				}
				if(isset($_POST["ewallet_types"]))
				{   $_SESSION["ewallet_types"]="";
				}
				if(isset($_POST["transaction_no"]))
				{   $_SESSION["transaction_no"]="";
				}
			}
		}*/
	  }
	   $sqlcart="SELECT * FROM cart WHERE customer_id=$cust_id";
	   $run_sqlcart=mysqli_query($connect, $sqlcart);
	   $numrows_sqlcart=mysqli_num_rows($run_sqlcart);
	   $sqlcust="SELECT * FROM customer WHERE customer_id=$cust_id";
	   $run_sqlcust=mysqli_query($connect, $sqlcust);
	   $rows_sqlcust=mysqli_fetch_assoc($run_sqlcust);
	   $cust_name=$rows_sqlcust["customer_name"];
	   if($numrows_sqlcart!=0)
	   { $rows_sqlcart=mysqli_fetch_assoc($run_sqlcart);
		 $cart_id=$rows_sqlcart["cart_id"];
		 $sqlprod="SELECT * FROM cart_item WHERE cart_id=$cart_id";
		 $run_sqlprod=mysqli_query($connect, $sqlprod);
		 $num_rows_sqlprod=mysqli_num_rows($run_sqlprod);
		echo "<p style='margin-left: 50px;'>Dear $cust_name, you currently have $num_rows_sqlprod items in your shopping cart.</p>";
		?>
         <table width="1300px;" style="margin: auto; border-collapse: collapse;">
         <tr class="thead" style="background-color: #dbd9d9;">
		   <th style="border-bottom: 1px solid grey;"></th>
           <th style="width:600px; font-size: 20px; border-bottom: 1px solid grey; text-align: center;">Product</th>
           <th style="width:100px; font-size: 20px; border-bottom: 1px solid grey; text-align: center;">Quantity</th>
           <th style="width:200px; font-size: 20px; border-bottom: 1px solid grey; text-align: center;">Price(RM)</th>
           <th style="width:300px; font-size: 20px; border-bottom: 1px solid grey; text-align: center;">Subtotal(RM)</th>
           <th style="width:100px; font-size: 20px; border-bottom: 1px solid grey;"></th>
         </tr><form method="POST" action="update_quantity.php">
		 <?php $i=0;
		 while($rows_sqlprod=mysqli_fetch_assoc($run_sqlprod))
		 {  $prod_id=$rows_sqlprod["product_id"];
			$item_quantity=$rows_sqlprod["item_quantity"];
			$prodinfo="SELECT * FROM product WHERE product_id='$prod_id' AND availability=0";
			$run_prodinfo=mysqli_query($connect, $prodinfo);
            $rows_prodinfo=mysqli_fetch_assoc($run_prodinfo);
			$stockinfo="SELECT * FROM stock WHERE product_id='$prod_id'";
			$run_stockinfo=mysqli_query($connect, $stockinfo);
            $rows_stockinfo=mysqli_fetch_assoc($run_stockinfo);
			$prod_name=$rows_prodinfo["product_name"];
			$prod_price=$rows_prodinfo["product_price"];
			$prod_discount=$rows_prodinfo["discount"];
			$prod_img=$rows_prodinfo["product_image"];
			$stk_lvl=$rows_stockinfo["stock_level"];
		 ?>
          <tr style="background-color: white;">
		   <td style="border-bottom: 1px solid grey;"></td>
	       <td style="border-bottom: 1px solid grey;"><div style="margin-left: 100px;"><a href="single-product.php?view&id=<?php echo $prod_id; ?>&cat=0&num=1&sort_opt=-1&cart=1"><?php echo $prod_name; ?></a><br><a href="single-product.php?view&id=<?php echo $prod_id; ?>&cat=0&num=1&sort_opt=-1&cart=1"><img src="staff/product_image/<?php echo $prod_img; ?>" style="width:150px; height:200px; position: relative; margin-bottom: 20px"></a><?php echo "<span style='margin-left: 50px;'>Available Stock: $stk_lvl</span>"; ?></div></td>
           <td style="border-bottom: 1px solid grey; text-align: center;"><br><input type="hidden" id="prodid_<?php echo $i; ?>" name="prodid_<?php echo $i; ?>" value="<?php echo $prod_id; ?>"><input type="number" id="quantity_<?php echo $i; ?>" name="quantity_<?php echo $i; ?>" min="1" max="<?php echo $stk_lvl; ?>" value="<?php echo $item_quantity; ?>" onchange="document.querySelector('[name=update_qtybtn]').click();"></td>
		   <td style="border-bottom: 1px solid grey; text-align: center;">
		   <p>
			<?php
			if($prod_discount==0)
			{echo number_format($prod_price, 2);}
			else
			{ $dprice=$rows_prodinfo["discount_price"]; echo number_format($dprice, 2); }
			?>
		   </p>
		   </td>
		   <td style="border-bottom: 1px solid grey; text-align: center;">
		   <p>
			<?php
			if($prod_discount==0)
			{echo number_format($prod_price*$item_quantity, 2); }
			else
			{ echo number_format($dprice*$item_quantity, 2); }
			?>
		   </p>
		   </td>
           <td style="border-bottom: 1px solid grey;"><p><a href="del_cart.php?del&id=<?php echo $prod_id; ?>"><img src="images/icon/remove.jpg" style="width:30px; height:30px;" title="Remove"></a></p></td>
          </tr>
		  <?php
		  if($prod_discount==0)
		  {$total+=$prod_price*$item_quantity; }
		  else
		  {$total+=$dprice*$item_quantity; }
		  $i++;
		 }?>
		 <input type="submit" name="update_qtybtn" style="display: none;">
		 <input type="submit" name="update_qtybtn_all" style="display: none;">
		 </form>
		 <tr style="background-color: white;">
		   <td></td>
	       <td></td>
           <td></td>
		   <td style="font-size: 20px; text-align: center; font-weight: bold;">Total(RM):</td>
           <td style="font-size: 20px; text-align: center; font-weight: bold;"><?php echo number_format($total, 2); ?></td>
		   <td></td>
         </tr>
		 </table>
		 <button style="margin-top: 50px; margin-left: 800px; position: absolute;" onclick="window.location.href='shop.php'">Continue Shopping</button>
		 <button style="margin-top: 50px; margin-left: 1100px; position: absolute;" onclick="document.querySelector('[name=update_qtybtn_all]').click();">Proceed to Checkout</button>
		 <?php
	   }
	   else
	   {
		echo "<p style='text-align: center; font-size: 18px;'>Dear $cust_name, your current cart is empty.</p>";?>
		<button style="margin-top: 50px; margin-left: 1100px; position: absolute;" onclick="window.location.href='shop.php'">Continue Shopping</button>
		<?php
	   }
	  ?>
	  </div>
</section>


<footer id="footer" style="background-color: #f3e7be;">
	<div class="container">
		<div class="row">

			<div class="col-md-4" style="width: 40%;">

				<div class="footer-item">
					<div class="company-brand">
						<img src="images/icon/logo.png" alt="logo" class="footer-logo" style="height: 180px; width: 200px; margin-left: 70px;">
						<p>Welcome to Knowledge Bookstore, your gateway to a vast world of literary treasures, where words come alive and imagination knows no bounds.</p>
					</div>
				</div>

			</div>

			<div class="col-md-2" style="margin-top: 80px;">

				<div class="footer-menu">
					<h5><a href="about_us.php">About Us</a></h5>
					<ul class="menu-list">
						<li class="menu-item">
							Phone: 06 – 252 3253
						</li>
						<!--<li class="menu-item">
							<a href="#">articles </a>
						</li>
						<li class="menu-item">
							<a href="#">careers</a>
						</li>
						<li class="menu-item">
							<a href="#">service terms</a>
						</li>
						<li class="menu-item">
							<a href="#">donate</a>
						</li>-->
					</ul>
				</div>

			</div>
			<!--<div class="col-md-2">

				<div class="footer-menu">
					<h5>Discover</h5>
					<ul class="menu-list">
						<li class="menu-item">
							<a href="#">Home</a>
						</li>
						<li class="menu-item">
							<a href="#">Books</a>
						</li>
						<li class="menu-item">
							<a href="#">Authors</a>
						</li>
						<li class="menu-item">
							<a href="#">Subjects</a>
						</li>
						<li class="menu-item">
							<a href="#">Advanced Search</a>
						</li>
					</ul>
				</div>

			</div>-->
			<div class="col-md-2" style="padding-left: 30px; margin-top: 80px;">

				<div class="footer-menu">
					<h5>Quick Links</h5>
					<ul class="menu-list">
						<li class="menu-item">
							<a href="index.php">Home</a>
						</li>
						<li class="menu-item">
							<a href="shop.php">Shop</a>
						</li>
					</ul>
				</div>

			</div>
			<div class="col-md-2" style="padding-left: 100px; margin-top: 80px;">

				<div class="footer-menu">
					<h5>Services</h5>
					<ul class="menu-list">
						<!--<li class="menu-item">
							<a href="#">Help center</a>
						</li>
						<li class="menu-item">
							<a href="#">Report a problem</a>
						</li>
						<li class="menu-item">
							<a href="#">Suggesting edits</a>
						</li>-->
						<li class="menu-item">
							<a href="contact.php">Contact us</a>
						</li>
						<li class="menu-item">
							<a href="faq.php">FAQ</a>
						</li>
					</ul>
				</div>

			</div>

		</div>
		<!-- / row -->

	</div>
</footer>

<div id="footer-bottom">
	<div class="container">
		<div class="row">
			<div class="col-md-12">

				<div class="copyright">
					<div class="row">

						<div class="col-md-6">
							<p>© 2023 All rights reserved.</p>
						</div>

						<div class="col-md-6">

						</div>

					</div>
				</div><!--grid-->

			</div><!--footer-bottom-content-->
		</div>
	</div>
</div>


<script src="js/jquery-1.11.0.min.js"></script>
<script src="js/plugins.js"></script>
<script src="js/script.js"></script>

</body>
</html>
